import { Request, Response, NextFunction } from "express";
import { config } from "../config";

// Track attempts per IP
interface AttemptData {
  attempts: number[];    // store timestamps of requests (success + failed)
  blockedUntil: number;  // timestamp in ms
}

const attempts = new Map<string, AttemptData>();

const MAX_ATTEMPTS: number = Number(config.LOGIN_ATTEMPT.LOGIN_MAX_ATTEMPTS); // e.g. 5
const TIME_FRAME: number = Number(config.LOGIN_ATTEMPT.TIME_FRAME); // e.g. 1 minute = 60_000 ms
const BLOCK_TIME: number = Number(config.LOGIN_ATTEMPT.BLOCK_TIME); // e.g. 15 minutes = 900_000 ms

const loginAttempt = (req: Request, res: Response, next: NextFunction) => {
  const ip = (req.headers["x-real-ip"] as string) || req.ip || "unknown";
  const now = Date.now();
  let record = attempts.get(ip);

  // 1. If IP is blocked
  if (record && record.blockedUntil > now) {
    const waitSec = Math.ceil((record.blockedUntil - now) / 1000);
    return res.status(429).json({
      success: 0,
      message: `Too many requests. Try again in ${waitSec} seconds.`,
    });
  }

  // Create record if missing
  if (!record) {
    record = { attempts: [], blockedUntil: 0 };
  }

  // 2. Clean old attempts (outside the timeframe)
  record.attempts = record.attempts.filter(ts => now - ts < TIME_FRAME);

  // 3. Add current attempt
  record.attempts.push(now);

  // 4. Check if exceeds max attempts
  if (record.attempts.length > MAX_ATTEMPTS) {
    record.blockedUntil = now + BLOCK_TIME;
    record.attempts = []; // reset after blocking
    attempts.set(ip, record);

    return res.status(429).json({
      success: 0,
      message: `Too many requests. You are blocked for ${BLOCK_TIME / 60000} minutes.`,
    });
  }

  // Save record
  attempts.set(ip, record);

  // Attach IP to response locals for login controller
  res.locals.clientIp = ip;
  next();
};

// Utility: reset attempts after successful login if you want
export const resetAttempts = (ip: string) => {
  attempts.delete(ip);
};

export default loginAttempt;
