import { Request, Response, NextFunction } from "express";
import auth from "basic-auth";

export const basicAuthMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const user = auth(req);

  const USERNAME = process.env.SWAGGER_USER;
  const PASSWORD = process.env.SWAGGER_PASSWORD;

  if (!user || user.name !== USERNAME || user.pass !== PASSWORD) {
    res.setHeader("WWW-Authenticate", 'Basic realm="Swagger UI"');
    res.status(401).send("Authentication required.");
    return;
  }

  next();
};
