import mongoose from "mongoose";
import user from "../models/user";
import user_tokens from "../models/user_tokens";
import jwt, { Secret, JwtPayload } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import { config } from "../config";

const middleware = async (req: Request, res: Response, next: NextFunction) => {
    //console.log("middleware called",req,"----------",req.headers['x-forwarded-for'],"--------req.ip",req.ip,"-----------------req.socket.remoteAddress",req.socket.remoteAddress)
  try {
    //res.removeHeader("Server");
    next();
  } catch (error) {
    return res.status(500).json({
      success: 0,
      message: "Internal Server error",
    });
  }

};

export default middleware;
