import mongoose from "mongoose";
import user from "../models/user";
import user_tokens from "../models/user_tokens";
import jwt, { Secret, JwtPayload } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import { config } from "../config";


const authUser = async (req: Request, res: Response, next: NextFunction) => {
  const token = req.header("Authorization")?.replace('Bearer ', '')
  if (token) {
    jwt.verify(
      token,
      config.key.secret_key,
      async function (err:any, decoded:any) {
        if (err) {
          return res.status(401).send({
            success: 2,
            message:"Session expired"
          });
        } else {
          res.set({
            "Cache-Control": "no-store",
            "Pragma": "no-cache",
            })

          const user_login_device_check = await user_tokens.find({
            uid: decoded?.uid,
          });

          if (user_login_device_check.length == 0) {
            return res.status(401).send({
              success: 2,
              message: "Your Account Detail Has Been Updated By Admin, Please Register Again",
            });
          }

          const user_token_check = await user_tokens.findOne({
            token: token,
          });
          console.log("user midleware called")
          if (!user_token_check) {
            return res.status(401).send({
              success: 2,
              message: "Authentication failed",
            });
          }else{
            console.log("else called for user")
            let get_check_user:any = await user.findOne({
              _id:user_token_check.uid,
              is_deleted:0
            })
            if(!get_check_user){
              return res.status(402).send({
                success: 0,
                message: "Your Account is Deleted",
              });
            }
            next();
          }
        }
      }
    );
  } else {
    return res.send({
      success: 2,
      message: "Token missing",
    });
  }
};

export default authUser;



