/**
 * @swagger
 * /v1/enterprise/create:
 *   post:
 *     summary: Create an enterprise
 *     tags:
 *       - Enterprise
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               billingAddress:
 *                 type: string
 *                 example: ahemdabad
 *               enterprise_name:
 *                 type: string
 *                 example: janedoetest
 *               isHosted:
 *                 type: string
 *                 example: "1"
 *               PrimaryColor:
 *                 type: string
 *                 example: "#1B47C5"
 *               status:
 *                 type: string
 *                 example: A
 *               noOfSubscriber:
 *                 type: string
 *                 example: "1"
 *               sipDomain:
 *                 type: string
 *                 example: testp.com
 *               concurrency:
 *                 type: string
 *                 example: "1"
 *               Featurepackages:
 *                 type: string
 *                 example: default_package
 *               contactAddress:
 *                 type: string
 *                 example: ahemdabad
 *               enterprise_password:
 *                 type: string
 *                 example: "1234"
 *               phoneNumber:
 *                 type: string
 *                 example: "79909173211"
 *               enterprise_email:
 *                 type: string
 *                 example: jj@gmail.com
 *               ipAddress:
 *                 type: string
 *                 example: 192.0.2.10
 *               Port:
 *                 type: string
 *                 example: "8032"
 *               islogoAdded:
 *                 type: string
 *                 example: "0"
 *               ismohfileAdded:
 *                 type: string
 *                 example: "0"
 *               realm_primary:
 *                 type: string
 *                 example: 192.0.2.10
 *               default_domain:
 *                 type: string
 *                 example: mtc.com.na
 *     responses:
 *       200:
 *         description: Enterprise created successfully
 *       403:
 *         description: Validation error or bad request
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: integer
 *                   example: 0
 *                 message:
 *                   type: string
 *                   enum:
 *                     - "Enterprise Name is Mandatory"
 *                     - "Enterprise Name is not valid. Its length must be in range of 1-64 and only alphabets, numbers, space and underscore are allowed. It must start with either alphabet or number"
 *                     - "Enterprise Activate is Mandatory"
 *                     - "Enterprise Activate field is not valid. You should give only 'A' or 'D' as input"
 *                     - "isHosted is mandatory"
 *                     - "isHosted is invalid"
 *                     - "PrimaryColor is mandatory"
 *                     - "PrimaryColor is invalid"
 *                     - "Port is invalid"
 *                     - "SecondoryPort is invalid"
 *                     - "SecondoryipAddress is invalid"
 *                     - "Number of Subscribers is Mandatory"
 *                     - "Number of Subscribers is not valid. Its length must be in range of 1-5 and only numeric values allowed"
 *                     - "sipDomain is mandatory"
 *                     - "Sip Domain is not valid. Its length must be in range of 1-255 and only alphabets, numbers, space and underscore are allowed. It must start with either alphabet or number"
 *       404:
 *         description: File not found
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: integer
 *                   example: 0
 *                 message:
 *                   type: string
 *                   example: File not found
 *       409:
 *         description: Conflict - Duplicate resource
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: integer
 *                   example: 0
 *                 message:
 *                   type: string
 *                   example: Sip Domain already exists. Enter a unique Name for SIP Domain
 */


/**
 * @swagger
 * /v1/enterprise/detail:
 *   post:
 *     summary: Get enterprise details
 *     description: Retrieves detailed information for a specific enterprise.
 *     tags:
 *       - Enterprise
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               enterprise_id:
 *                 type: string
 *                 example: 65dca7509b10947531570b2e
 *     responses:
 *       200:
 *         description: Enterprise details retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 _id:
 *                   type: string
 *                   example: 65dca7509b10947531570b2e
 *                 enterprise_name:
 *                   type: string
 *                   example: Pbxcore
 *                 enterprise_email:
 *                   type: string
 *                   example: admin@example.com
 *                 phoneNumber:
 *                   type: string
 *                   example: 7990917321
 *                 status:
 *                   type: string
 *                   example: A
 *                 # ... other fields as per your schema
 *       400:
 *         description: Bad request - Missing or invalid enterprise_id
 *       401:
 *         description: Unauthorized - Missing or invalid token
 *       404:
 *         description: Enterprise not found
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/enterprise:
 *   post:
 *     summary: Get list of enterprises
 *     description: Retrieves a paginated list of enterprises with optional search and filter.
 *     tags:
 *       - Enterprise
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               size:
 *                 type: integer
 *                 example: 20
 *               page:
 *                 type: integer
 *                 example: 1
 *               search:
 *                 type: string
 *                 example: ""
 *               filter:
 *                 type: integer
 *                 example: 1
 *     responses:
 *       200:
 *         description: List of enterprises
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     example:
 *                       _id: 65cdf5f9ee6e6470baf71471
 *                       name: Pbxcore
 *                 total:
 *                   type: integer
 *                   example: 100
 *       401:
 *         description: Unauthorized - Missing or invalid token
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/enterprise/edit:
 *   put:
 *     summary: Edit enterprise details
 *     description: Updates an existing enterprise's details.
 *     tags:
 *       - Enterprise
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               enterprise_name:
 *                 type: string
 *                 example: janedoetest
 *               isHosted:
 *                 type: string
 *                 example: "1"
 *               PrimaryColor:
 *                 type: string
 *                 example: "#1B47C5"
 *               status:
 *                 type: string
 *                 example: A
 *               noOfSubscriber:
 *                 type: string
 *                 example: "10"
 *               sipDomain:
 *                 type: string
 *                 example: testp.com
 *               concurrency:
 *                 type: string
 *                 example: "1"
 *               Featurepackages:
 *                 type: string
 *                 example: default_package
 *               contactAddress:
 *                 type: string
 *                 example: ahemdabad
 *               enterprise_password:
 *                 type: string
 *                 example: "1234"
 *               phoneNumber:
 *                 type: string
 *                 example: "79909173211"
 *               enterprise_email:
 *                 type: string
 *                 example: jj@gmail.com
 *               ipAddress:
 *                 type: string
 *                 example: 192.0.2.10
 *               realm_primary:
 *                 type: string
 *                 example: 192.0.2.10
 *               Port:
 *                 type: string
 *                 example: "8032"
 *               eid:
 *                 type: string
 *                 example: 67af0fd674167d9202e57ea8
 *               Logo:
 *                 type: string
 *                 format: binary
 *               MOHFile:
 *                 type: string
 *                 format: binary
 *               ismohfileEdite:
 *                 type: string
 *                 example: "0"
 *               islogoEdited:
 *                 type: string
 *                 example: "0"
 *               billingAddress:
 *                 type: string
 *                 example: ahemdabad
 *               default_domain:
 *                 type: string
 *                 example: mtc.com.na
 *     responses:
 *       200:
 *         description: Enterprise updated successfully
 *       400:
 *         description: Bad request - missing or invalid fields
 *       401:
 *         description: Unauthorized - Missing or invalid token
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/enterprise/delete:
 *   put:
 *     summary: Delete an enterprise
 *     description: Deletes an enterprise by its ID (eid).
 *     tags:
 *       - Enterprise
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - eid
 *             properties:
 *               eid:
 *                 type: string
 *                 example: 67a5bb10b94312ce7bd1f7d8
 *     responses:
 *       200:
 *         description: Enterprise deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Enterprise deleted successfully
 *       400:
 *         description: Bad request - Missing or invalid eid
 *       401:
 *         description: Unauthorized - Missing or invalid token
 *       404:
 *         description: Enterprise not found
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/user/detail:
 *   post:
 *     summary: Get user detail by UID (in request body)
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               uid:
 *                 type: string
 *                 example: 65ddf109f03f2e9b190e8e73
 *     responses:
 *       200:
 *         description: User detail retrieved successfully
 *       404:
 *         description: User not found
 */
/**
 * @swagger
 * /v1/user/create:
 *   post:
 *     summary: Create a new user (subscriber)
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               eid:
 *                 type: string
 *                 example: 66b631ba099eb016aa213174
 *               subscriberActivate:
 *                 type: string
 *                 example: Y
 *               first_name:
 *                 type: string
 *                 example: jane
 *               last_name:
 *                 type: string
 *                 example: sasakiya
 *               pin:
 *                 type: string
 *                 example: 964533445
 *               password:
 *                 type: string
 *                 example: 964533445
 *               stdpassword:
 *                 type: string
 *                 example: 123
 *               packageName:
 *                 type: string
 *                 example: default_package
 *               endpointNumber:
 *                 type: string
 *                 example: 964533445
 *               callerId:
 *                 type: string
 *                 example: 964533445
 *               sipDomain:
 *                 type: string
 *                 example: pbxcoreucm.com
 *               internalCallerID:
 *                 type: string
 *                 example: 964533445
 *               emailAddress:
 *                 type: string
 *                 example: jane.doe@example.com
 *               MobileNumber:
 *                 type: string
 *                 example: 876123459913
 *               subscriberGroup:
 *                 type: string
 *                 example: mygroup
 *               isVoiceMailEnable:
 *                 type: string
 *                 example: off
 *               vmsPassword:
 *                 type: string
 *                 example: 1123
 *               units:
 *                 type: string
 *                 example: 1
 *               creditLimit:
 *                 type: string
 *                 example: 1
 *               accountType:
 *                 type: string
 *                 example: Y
 *               suspendStatus:
 *                 type: string
 *                 example: N
 *               borderAgent:
 *                 type: string
 *                 example: 1
 *     responses:
 *       200:
 *         description: User created successfully
 */

/**
 * @swagger
 * /v1/user:
 *   post:
 *     summary: Get list of users with pagination, filter, and search
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               search:
 *                 type: string
 *                 example: ""
 *               page:
 *                 type: integer
 *                 example: 1
 *               size:
 *                 type: integer
 *                 example: 10
 *               filter:
 *                 type: integer
 *                 example: 0
 *     responses:
 *       200:
 *         description: User list retrieved successfully
 */

/**
 * @swagger
 * /v1/user/edit:
 *   put:
 *     summary: Edit user details
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               uid:
 *                 type: string
 *                 example: 66b631eb099eb016aa2131ad
 *               user_image:
 *                 type: string
 *                 format: binary
 *               vmsPassword:
 *                 type: string
 *                 example: "1234"
 *               subscriberActivate:
 *                 type: string
 *                 enum: [Y, N]
 *               first_name:
 *                 type: string
 *                 example: Hitesh
 *               last_name:
 *                 type: string
 *                 example: Prajapati
 *               pin:
 *                 type: string
 *                 example: "4005"
 *               password:
 *                 type: string
 *                 example: "4005"
 *               stdpassword:
 *                 type: string
 *                 example: ""
 *               incommingDIDNumbers:
 *                 type: string
 *                 example: "[]"
 *               endpointNumber:
 *                 type: string
 *                 example: "4005"
 *               callerId:
 *                 type: string
 *                 example: "4005"
 *               sipDomain:
 *                 type: string
 *                 example: pbxcoreucm.com
 *               internalCallerID:
 *                 type: string
 *                 example: ""
 *               emailAddress:
 *                 type: string
 *                 example: hiteshbprajapati@gmail.com
 *               MobileNumber:
 *                 type: string
 *                 example: "9879539488"
 *               isVoiceMailEnable:
 *                 type: string
 *                 enum: [on, off]
 *               units:
 *                 type: number
 *                 example: 0.0
 *               creditLimit:
 *                 type: number
 *                 example: 0.0
 *               accountType:
 *                 type: string
 *                 enum: [Y, N]
 *               suspendStatus:
 *                 type: string
 *                 enum: [Y, N]
 *               packageName:
 *                 type: string
 *                 example: default_package
 *     responses:
 *       200:
 *         description: User updated successfully
 *       400:
 *         description: Bad request or invalid data
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: User not found
 */

/**
 * @swagger
 * /v1/user/delete:
 *   put:
 *     summary: Delete user by UID
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               uid:
 *                 type: string
 *                 example: 67dba52eed8d49082680c367
 *             required:
 *               - uid
 *     responses:
 *       200:
 *         description: User deleted successfully
 *       400:
 *         description: Bad request or missing UID
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: User not found
 */

/**
 * @swagger
 * /v1/user/mobile/login:
 *   post:
 *     summary: Login using mobile number and email
 *     tags:
 *       - User
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               MobileNumber:
 *                 type: integer
 *                 example: 82345666664
 *               emailAddress:
 *                 type: string
 *                 example: hardikthummar888@gmail.com
 *             required:
 *               - MobileNumber
 *               - emailAddress
 *     responses:
 *       200:
 *         description: Login successful
 *       400:
 *         description: Missing or invalid parameters
 *       401:
 *         description: Unauthorized
 */

/**
 * @swagger
 * /v1/user/verify/login:
 *   post:
 *     summary: Verify user login with OTP and device info
 *     tags:
 *       - User
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               MobileNumber:
 *                 type: integer
 *                 example: 264813335699
 *               emailAddress:
 *                 type: string
 *                 example: jane.doe@example.com
 *               otp:
 *                 type: string
 *                 example: "4046"
 *               device_id:
 *                 type: string
 *                 example: e212b161ef934594
 *               device_name:
 *                 type: string
 *                 example: realme RMX3085
 *               osversion:
 *                 type: integer
 *                 example: 2
 *               device_os_version:
 *                 type: string
 *                 example: "13"
 *               apns_push_token:
 *                 type: string
 *                 example: ""
 *             required:
 *               - MobileNumber
 *               - emailAddress
 *               - otp
 *               - device_id
 *               - device_name
 *               - osversion
 *               - device_os_version
 *     responses:
 *       200:
 *         description: User verified and logged in successfully
 *       400:
 *         description: Invalid request payload
 *       401:
 *         description: Verification failed
 */

/**
 * @swagger
 * /v1/user/restore/chat/{id}:
 *   get:
 *     summary: Restore user chat by ID
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: User ID to restore chat for
 *         example: 664dd57551c7fd47ce3c5134
 *     responses:
 *       200:
 *         description: Chat restored successfully
 *       404:
 *         description: User or chat not found
 *       401:
 *         description: Unauthorized – invalid or missing token
 */

/**
 * @swagger
 * /v1/upload:
 *   post:
 *     summary: Upload a file
 *     tags:
 *       - File
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *                 description: The file to upload
 *     responses:
 *       200:
 *         description: File uploaded successfully
 *       400:
 *         description: Bad request – file missing or invalid
 *       401:
 *         description: Unauthorized – invalid or expired token
 */

/**
 * @swagger
 * /v1/user/link/login:
 *   post:
 *     summary: Login using FQDN token and device info
 *     tags:
 *       - User
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               fqdntoken:
 *                 type: string
 *                 example: jp9Yh
 *               device_id:
 *                 type: string
 *                 example: 123456
 *               device_name:
 *                 type: string
 *                 example: test
 *               osversion:
 *                 type: string
 *                 example: android
 *     responses:
 *       200:
 *         description: Login successful
 *       400:
 *         description: Bad request – missing or invalid parameters
 *       401:
 *         description: Unauthorized – invalid token
 */

/**
 * @swagger
 * /v1/email:
 *   get:
 *     summary: Search emails
 *     tags:
 *       - Email
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         required: false
 *         description: Search query to filter email addresses
 *         example: john
 *     responses:
 *       200:
 *         description: List of matching email addresses
 *       401:
 *         description: Unauthorized – invalid or expired token
 *       500:
 *         description: Server error
 */

/**
 * @swagger
 * /v1/email/{id}:
 *   get:
 *     summary: Get email detail by ID
 *     tags:
 *       - Email
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: Unique ID of the email entry
 *         example: 65a77e77197d04e6305f298b
 *     responses:
 *       200:
 *         description: Email details retrieved successfully
 *       404:
 *         description: Email not found
 *       401:
 *         description: Unauthorized – token missing or invalid
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/email/{id}:
 *   put:
 *     summary: Update email by ID
 *     tags:
 *       - Email
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the email to update
 *         example: 65a77e77197d04e6305f298b
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               sender_name:
 *                 type: string
 *               from:
 *                 type: string
 *               replay_to:
 *                 type: string
 *               subject:
 *                 type: string
 *               message:
 *                 type: string
 *               action_url:
 *                 type: string
 *             example:
 *               sender_name: "sender"
 *               from: "mytest@gmail.com"
 *               replay_to: "No Replay"
 *               subject: "test subject11"
 *               message: "test message"
 *               action_url: "dummy url"
 *     responses:
 *       200:
 *         description: Email updated successfully
 *       400:
 *         description: Bad request
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Email not found
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/sms:
 *   get:
 *     summary: Retrieve list of SMS messages
 *     tags:
 *       - SMS
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: A list of SMS messages
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   _id:
 *                     type: string
 *                   from:
 *                     type: string
 *                   to:
 *                     type: string
 *                   message:
 *                     type: string
 *                   timestamp:
 *                     type: string
 *                     format: date-time
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/sms/{id}:
 *   get:
 *     summary: Get a specific SMS by ID
 *     tags:
 *       - SMS
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the SMS to retrieve
 *     responses:
 *       200:
 *         description: SMS data retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 _id:
 *                   type: string
 *                 from:
 *                   type: string
 *                 to:
 *                   type: string
 *                 message:
 *                   type: string
 *                 timestamp:
 *                   type: string
 *                   format: date-time
 *       404:
 *         description: SMS not found
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal Server Error
 */

/**
 * @swagger
 * /v1/sms/{id}:
 *   put:
 *     summary: Update SMS configuration by ID
 *     tags:
 *       - SMS
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the SMS configuration to update
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               sms_api_name:
 *                 type: string
 *               sms_url_method:
 *                 type: integer
 *                 description: HTTP method type (e.g. 1 = POST, 2 = GET)
 *               sms_content_type:
 *                 type: integer
 *                 description: Content type (e.g. 1 = application/x-www-form-urlencoded)
 *               sms_api_url:
 *                 type: string
 *               sms_keypair_value:
 *                 type: string
 *                 description: URL parameters or payload with dynamic values
 *               sms_key_message_maxlength:
 *                 type: string
 *               sms_api_type:
 *                 type: integer
 *               isapi_enable:
 *                 type: integer
 *                 description: 1 = enabled, 0 = disabled
 *     responses:
 *       200:
 *         description: SMS configuration updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                 data:
 *                   $ref: '#/components/schemas/Sms'
 *       400:
 *         description: Invalid request
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: SMS configuration not found
 *       500:
 *         description: Internal Server Error
 */

/**
 * @swagger
 * /v1/packages/list:
 *   post:
 *     summary: Get list of packages for a specific domain and IP address
 *     tags:
 *       - Packages
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - default_domain
 *               - ipaddress
 *             properties:
 *               default_domain:
 *                 type: string
 *                 example: mtc.com.na
 *               ipaddress:
 *                 type: string
 *                 example: 192.0.2.10
 *     responses:
 *       200:
 *         description: Successfully retrieved package list
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Packages fetched successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Package'
 *       400:
 *         description: Bad request – missing or invalid parameters
 *       401:
 *         description: Unauthorized – invalid or missing token
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/accessgroup:
 *   get:
 *     summary: Retrieve a list of access groups with pagination and filters
 *     tags:
 *       - Access Group
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *         required: false
 *         description: Page number for pagination (default is 1)
 *         example: 1
 *       - in: query
 *         name: size
 *         schema:
 *           type: integer
 *         required: false
 *         description: Number of records per page (default is 10)
 *         example: 10
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         required: false
 *         description: Keyword to search access groups by name
 *         example: jane
 *       - in: query
 *         name: filter
 *         schema:
 *           type: integer
 *         required: false
 *         description: Filter flag (e.g., 0 for all, 1 for active, etc.)
 *         example: 0
 *     responses:
 *       200:
 *         description: Successfully fetched access group list
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Access groups retrieved successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/AccessGroup'
 *       401:
 *         description: Unauthorized – invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/accessgroup/create:
 *   post:
 *     summary: Create a new access group with permissions
 *     tags:
 *       - Access Group
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - profile_type
 *             properties:
 *               name:
 *                 type: string
 *                 example: jane enterprise test jdfkf
 *               profile_type:
 *                 type: integer
 *                 description: Type of profile (e.g., 1 = admin, 2 = enterprise)
 *                 example: 2
 *               dashboard_view:
 *                 type: integer
 *                 example: 1
 *               enterprise_create:
 *                 type: integer
 *                 example: 1
 *               enterprise_update:
 *                 type: integer
 *                 example: 1
 *               enterprise_delete:
 *                 type: integer
 *                 example: 1
 *               enterprise_view:
 *                 type: integer
 *                 example: 1
 *               enterprise_download:
 *                 type: integer
 *                 example: 1
 *               subscriber_create:
 *                 type: integer
 *                 example: 1
 *               subscriber_update:
 *                 type: integer
 *                 example: 1
 *               subscriber_delete:
 *                 type: integer
 *                 example: 1
 *               subscriber_view:
 *                 type: integer
 *                 example: 1
 *               subscriber_download:
 *                 type: integer
 *                 example: 1
 *               email_update:
 *                 type: integer
 *                 example: 1
 *               email_view:
 *                 type: integer
 *                 example: 1
 *               sms_update:
 *                 type: integer
 *                 example: 1
 *               sms_view:
 *                 type: integer
 *                 example: 1
 *               add_admin_create:
 *                 type: integer
 *                 example: 1
 *               add_admin_update:
 *                 type: integer
 *                 example: 1
 *               add_admin_delete:
 *                 type: integer
 *                 example: 1
 *               add_admin_view:
 *                 type: integer
 *                 example: 1
 *               add_role_create:
 *                 type: integer
 *                 example: 1
 *               add_role_update:
 *                 type: integer
 *                 example: 1
 *               add_role_delete:
 *                 type: integer
 *                 example: 1
 *               add_role_view:
 *                 type: integer
 *                 example: 1
 *               cdr_view:
 *                 type: integer
 *                 example: 0
 *               subscriber_import:
 *                 type: integer
 *                 example: 0
 *               config_smtp:
 *                 type: integer
 *                 example: 0
 *               cdr_download:
 *                 type: integer
 *                 example: 0
 *               provising_logs_view:
 *                 type: integer
 *                 example: 0
 *               provising_logs_download:
 *                 type: integer
 *                 example: 0
 *               token_regenrate:
 *                 type: integer
 *                 example: 0
 *     responses:
 *       200:
 *         description: Access group created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Access group created successfully
 *                 data:
 *                   $ref: '#/components/schemas/AccessGroup'
 *       400:
 *         description: Bad request
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */

/**
 * @swagger
 * /v1/accessgroup/{id}:
 *   get:
 *     summary: Get Access Group by ID
 *     description: Retrieves a specific access group using its unique identifier.
 *     tags:
 *       - AccessGroup
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: MongoDB ObjectId of the access group.
 *         schema:
 *           type: string
 *           example: 65aa4a742ec8d871bdd4f940
 *     responses:
 *       200:
 *         description: Successful response with access group details.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               example:
 *                 _id: 65aa4a742ec8d871bdd4f940
 *                 name: admin access group
 *                 profile_type: 2
 *                 enterprise_create: 1
 *                 sms_view: 1
 *                 # ... other permissions
 *       401:
 *         description: Unauthorized - Missing or invalid token.
 *       404:
 *         description: Access group not found.
 *     security:
 *       - bearerAuth: []
 */

/**
 * @swagger
 * /v1/accessgroup/edit/{id}:
 *   put:
 *     summary: Update an access group
 *     description: Edits an existing access group by ID with updated permissions and details.
 *     tags:
 *       - AccessGroup
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: MongoDB ObjectId of the access group to update
 *         schema:
 *           type: string
 *           example: 65d2ed6f2a31b0b9f22a31e7
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               profile_type:
 *                 type: integer
 *               dashboard_view:
 *                 type: integer
 *               enterprise_create:
 *                 type: integer
 *               enterprise_update:
 *                 type: integer
 *               enterprise_delete:
 *                 type: integer
 *               enterprise_view:
 *                 type: integer
 *               enterprise_download:
 *                 type: integer
 *               subscriber_create:
 *                 type: integer
 *               subscriber_update:
 *                 type: integer
 *               subscriber_delete:
 *                 type: integer
 *               subscriber_view:
 *                 type: integer
 *               subscriber_download:
 *                 type: integer
 *               email_update:
 *                 type: integer
 *               email_view:
 *                 type: integer
 *               sms_update:
 *                 type: integer
 *               sms_view:
 *                 type: integer
 *               add_admin_create:
 *                 type: integer
 *               add_admin_update:
 *                 type: integer
 *               add_admin_delete:
 *                 type: integer
 *               add_admin_view:
 *                 type: integer
 *               add_role_create:
 *                 type: integer
 *               add_role_update:
 *                 type: integer
 *               add_role_delete:
 *                 type: integer
 *               add_role_view:
 *                 type: integer
 *               cdr_view:
 *                 type: integer
 *               subscriber_import:
 *                 type: integer
 *               config_smtp:
 *                 type: integer
 *               cdr_download:
 *                 type: integer
 *               provising_logs_view:
 *                 type: integer
 *               provising_logs_download:
 *                 type: integer
 *               token_regenrate:
 *                 type: integer
 *             example:
 *               name: jane
 *               profile_type: 1
 *               dashboard_view: 1
 *               enterprise_create: 1
 *               enterprise_update: 1
 *               enterprise_delete: 1
 *               enterprise_view: 1
 *               enterprise_download: 1
 *               subscriber_create: 1
 *               subscriber_update: 1
 *               subscriber_delete: 1
 *               subscriber_view: 1
 *               subscriber_download: 1
 *               email_update: 1
 *               email_view: 1
 *               sms_update: 1
 *               sms_view: 1
 *               add_admin_create: 1
 *               add_admin_update: 1
 *               add_admin_delete: 1
 *               add_admin_view: 1
 *               add_role_create: 1
 *               add_role_update: 1
 *               add_role_delete: 1
 *               add_role_view: 1
 *               cdr_view: 1
 *               subscriber_import: 0
 *               config_smtp: 0
 *               cdr_download: 0
 *               provising_logs_view: 0
 *               provising_logs_download: 0
 *               token_regenrate: 0
 *     responses:
 *       200:
 *         description: Access group updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               example:
 *                 message: Access group updated successfully
 *       400:
 *         description: Bad request
 *       401:
 *         description: Unauthorized - missing or invalid token
 *       404:
 *         description: Access group not found
 *     security:
 *       - bearerAuth: []
 */

/**
 * @swagger
 * /v1/subadmin:
 *   get:
 *     summary: Get list of sub-admins
 *     description: Retrieves a paginated list of sub-admin users with optional search.
 *     tags:
 *       - SubAdmin
 *     parameters:
 *       - in: query
 *         name: page
 *         required: false
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Page number for pagination
 *       - in: query
 *         name: size
 *         required: false
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Number of items per page
 *       - in: query
 *         name: search
 *         required: false
 *         schema:
 *           type: string
 *           example: john
 *         description: Search keyword to filter sub-admins
 *     responses:
 *       200:
 *         description: A list of sub-admins
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 total:
 *                   type: integer
 *                 page:
 *                   type: integer
 *                 size:
 *                   type: integer
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                       name:
 *                         type: string
 *                       email:
 *                         type: string
 *                       role:
 *                         type: string
 *               example:
 *                 total: 25
 *                 page: 1
 *                 size: 10
 *                 data:
 *                   - _id: "65cb1b10d07297abe4025a61"
 *                     name: "Jane"
 *                     email: "jane.doe@example.com"
 *                     role: "admin"
 *       401:
 *         description: Unauthorized - missing or invalid token
 *     security:
 *       - bearerAuth: []
 */
/**
 * @swagger
 * /v1/subadmin/create:
 *   post:
 *     summary: Create a new subadmin
 *     description: Creates a new subadmin user with personal details, access group, and optional file upload.
 *     tags:
 *       - SubAdmin
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               user_name:
 *                 type: string
 *                 example: hajdhasjkd
 *               name:
 *                 type: string
 *                 example: jane
 *               user_email:
 *                 type: string
 *                 format: email
 *                 example: jane.doe@example.com
 *               user_password:
 *                 type: string
 *                 format: password
 *                 example: 12345678
 *               confirm_password:
 *                 type: string
 *                 format: password
 *                 example: 12345678
 *               user_status:
 *                 type: string
 *                 enum: [0, 1]
 *                 example: "1"
 *               user_mobileNumber:
 *                 type: string
 *                 example: "8913456778"
 *               user_address:
 *                 type: string
 *                 example: hcbzxbcnmzbjdakahdkjahdskjh
 *               accessgroup:
 *                 type: string
 *                 example: 65f1506ab909ab54279d54e7
 *               selected_Enterprise:
 *                 type: string
 *                 example: "[\"660e45224f23d55f9dcffa18\"]"
 *               access_profile_type:
 *                 type: string
 *                 example: "2"
 *               file:
 *                 type: string
 *                 format: binary
 *     responses:
 *       200:
 *         description: Subadmin created successfully
 *       400:
 *         description: Bad request or missing fields
 *       401:
 *         description: Unauthorized
 *     security:
 *       - bearerAuth: []
 */
/**
 * @swagger
 * /v1/subadmin/edit/{id}:
 *   put:
 *     summary: Update a subadmin
 *     description: Updates an existing subadmin's profile with the provided details and optional image upload.
 *     tags:
 *       - SubAdmin
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Subadmin ID
 *         schema:
 *           type: string
 *           example: 660ea819ef3d7c6cbe1d0f70
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             properties:
 *               user_name:
 *                 type: string
 *                 example: janedoe
 *               name:
 *                 type: string
 *                 example: jane
 *               user_email:
 *                 type: string
 *                 format: email
 *                 example: jane.doe@example.com
 *               user_password:
 *                 type: string
 *                 format: password
 *                 example: 12345678
 *               confirm_password:
 *                 type: string
 *                 format: password
 *                 example: 12345678
 *               user_status:
 *                 type: string
 *                 enum: [0, 1]
 *                 example: "1"
 *               user_mobileNumber:
 *                 type: string
 *                 example: "8913456778"
 *               user_address:
 *                 type: string
 *                 example: hcbzxbcnmzbjdakahdkjahdskjh
 *               accessgroup:
 *                 type: string
 *                 example: 65f1506ab909ab54279d54e7
 *               selected_Enterprise:
 *                 type: string
 *                 example: "[\"660e45224f23d55f9dcffa18\"]"
 *               user_image:
 *                 type: string
 *                 example: ""
 *               access_profile_type:
 *                 type: string
 *                 example: "2"
 *               file:
 *                 type: string
 *                 format: binary
 *     responses:
 *       200:
 *         description: Subadmin updated successfully
 *       400:
 *         description: Bad request or validation failed
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: Subadmin not found
 *     security:
 *       - bearerAuth: []
 */

/**
 * @swagger
 * /v1/subadmin/{id}:
 *   get:
 *     summary: Get subadmin by ID
 *     description: Retrieves a subadmin's details using their unique ID.
 *     tags:
 *       - SubAdmin
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         description: Subadmin ID
 *         schema:
 *           type: string
 *           example: 65cc9d8a82b3b6239f8a2fdd
 *     responses:
 *       200:
 *         description: Subadmin details retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 data:
 *                   type: object
 *                   description: Subadmin details
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       404:
 *         description: Subadmin not found
 *     security:
 *       - bearerAuth: []
 */

/**
 * @swagger
 * /v1/smtp:
 *   get:
 *     summary: Get SMTP configuration
 *     description: Retrieves the current SMTP configuration settings.
 *     tags:
 *       - SMTP
 *     responses:
 *       200:
 *         description: SMTP configuration retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   description: SMTP configuration details
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *     security:
 *       - bearerAuth: []
 */
/**
 * @swagger
 * /v1/smtp:
 *   put:
 *     summary: Update SMTP configuration
 *     description: Updates the SMTP settings used for sending emails.
 *     tags:
 *       - SMTP
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - mail_host
 *               - is_auth
 *               - auth_user
 *               - auth_password
 *               - auth_method
 *             properties:
 *               mail_host:
 *                 type: string
 *                 example: mail.example.com:465
 *               is_auth:
 *                 type: integer
 *                 enum: [0, 1]
 *                 description: Whether authentication is required (1 = yes, 0 = no)
 *               auth_user:
 *                 type: string
 *                 example: jane.doe@example.com
 *               auth_password:
 *                 type: string
 *                 example: Pr@d1P@C3l10Ip
 *               auth_method:
 *                 type: integer
 *                 enum: [0, 1]
 *                 description: Authentication method (1 = LOGIN, 0 = PLAIN, etc.)
 *     responses:
 *       200:
 *         description: SMTP configuration updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: SMTP settings updated
 *       400:
 *         description: Invalid request body
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *     security:
 *       - bearerAuth: []
 */
/**
 * @swagger
 * /v1/accessgroup/list:
 *   get:
 *     summary: Get list of access groups
 *     description: Retrieves a list of all available access groups.
 *     tags:
 *       - Access Group
 *     responses:
 *       200:
 *         description: Successfully retrieved list of access groups
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                         example: 65f1506ab909ab54279d54e7
 *                       name:
 *                         type: string
 *                         example: Admin Access Group
 *                       profile_type:
 *                         type: integer
 *                         example: 1
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *     security:
 *       - bearerAuth: []
 */
/**
 * @swagger
 * /v1/packages/list:
 *   get:
 *     summary: Get list of packages
 *     description: Retrieves a list of all available packages.
 *     tags:
 *       - Packages
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved list of packages
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                         example: 660e1234abcd5678efgh9012
 *                       package_name:
 *                         type: string
 *                         example: Gold Plan
 *                       price:
 *                         type: number
 *                         format: float
 *                         example: 49.99
 *                       validity_days:
 *                         type: integer
 *                         example: 30
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *       401:
 *         description: Unauthorized - Invalid or missing token
 */
/**
 * @swagger
 * /v1/incomingdid/list:
 *   get:
 *     summary: Get list of incoming DIDs
 *     description: Retrieves a list of all incoming DIDs associated with a specific domain.
 *     tags:
 *       - Incoming DID
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: domainName
 *         in: query
 *         description: Domain name to filter the DIDs
 *         required: true
 *         schema:
 *           type: string
 *           example: example.com
 *     responses:
 *       200:
 *         description: Successfully retrieved list of incoming DIDs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                         example: 6613c14276597d002a5ccaaa
 *                       number:
 *                         type: string
 *                         example: +1234567890
 *                       domainName:
 *                         type: string
 *                         example: example.com
 *                       assigned_to:
 *                         type: string
 *                         example: extension_1001
 *                       status:
 *                         type: string
 *                         example: active
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *       401:
 *         description: Unauthorized - Invalid or missing token
 */
/**
 * @swagger
 * /v1/featurespackage/list:
 *   get:
 *     summary: Get list of feature packages
 *     description: Retrieves a list of all available feature packages.
 *     tags:
 *       - Feature Package
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved list of feature packages
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                         example: 660e5d21a2e72c34f1db4473
 *                       name:
 *                         type: string
 *                         example: Basic Feature Package
 *                       description:
 *                         type: string
 *                         example: Includes basic VoIP features
 *                       features:
 *                         type: array
 *                         items:
 *                           type: string
 *                           example: call_forwarding
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *       401:
 *         description: Unauthorized - Invalid or missing token
 */
/**
 * @swagger
 * /v1/group/message/info/{id}:
 *   get:
 *     summary: Get group message info
 *     description: Retrieves detailed information about a specific group message by its ID.
 *     tags:
 *       - Group Message
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the group message
 *     responses:
 *       200:
 *         description: Successfully retrieved group message information
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     _id:
 *                       type: string
 *                       example: 65a8e96109b1126bb901903e
 *                     group_name:
 *                       type: string
 *                       example: Sales Team
 *                     message:
 *                       type: string
 *                       example: Meeting at 3 PM
 *                     sender:
 *                       type: string
 *                       example: admin@company.com
 *                     createdAt:
 *                       type: string
 *                       format: date-time
 *                     updatedAt:
 *                       type: string
 *                       format: date-time
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       404:
 *         description: Group message not found
 */

/**
 * @swagger
 * /v1/user/push/send:
 *   post:
 *     summary: Send push notification to user
 *     description: Sends a push notification to a user with SIP and caller details.
 *     tags:
 *       - Push Notification
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               caller_id:
 *                 type: string
 *                 example: "1410022024-14AC8C6A0000000080171906332@0.0.0.0"
 *               sip_username:
 *                 type: string
 *                 example: "sip:888@example.com"
 *               sip_domain:
 *                 type: string
 *                 example: "192.0.2.20"
 *               caller_number:
 *                 type: string
 *                 example: "3002"
 *     responses:
 *       200:
 *         description: Push notification sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Push notification sent
 *       400:
 *         description: Bad Request - Missing or invalid parameters
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/contact/list:
 *   get:
 *     summary: Get list of user contacts
 *     description: Retrieves a list of contacts associated with the authenticated user.
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of contacts retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 contacts:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       contact_id:
 *                         type: string
 *                         example: "661cc5f9b07eb883a44ef7e0"
 *                       name:
 *                         type: string
 *                         example: "John Doe"
 *                       number:
 *                         type: string
 *                         example: "3001"
 *                       email:
 *                         type: string
 *                         example: "john@example.com"
 *       401:
 *         description: Unauthorized - Invalid or expired token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/block/list:
 *   get:
 *     summary: Get list of blocked users
 *     description: Retrieves a list of users who have been blocked by the authenticated user.
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved blocked user list
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       user_id:
 *                         type: string
 *                         example: "65a8e96109b1126bb901903e"
 *                       number:
 *                         type: string
 *                         example: "3004"
 *                       name:
 *                         type: string
 *                         example: "Jane Smith"
 *                       blockedAt:
 *                         type: string
 *                         format: date-time
 *                         example: "2024-01-17T10:23:45.123Z"
 *       401:
 *         description: Unauthorized - Invalid or expired token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/pakage/list:
 *   get:
 *     summary: Get list of enterprise packages
 *     description: Retrieves a list of all available enterprise packages.
 *     tags:
 *       - Enterprise
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved list of enterprise packages
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                         example: 65f243f209bf03487d256a91
 *                       name:
 *                         type: string
 *                         example: Basic Enterprise Package
 *                       price:
 *                         type: number
 *                         example: 49.99
 *                       duration:
 *                         type: string
 *                         example: "Monthly"
 *                       features:
 *                         type: array
 *                         items:
 *                           type: string
 *                         example: ["Call Recording", "IVR", "Voicemail"]
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                       updatedAt:
 *                         type: string
 *                         format: date-time
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/group/info/{groupId}:
 *   get:
 *     summary: Get group info
 *     description: Retrieves detailed information about a specific group using its ID.
 *     tags:
 *       - Group
 *     parameters:
 *       - in: path
 *         name: groupId
 *         required: true
 *         schema:
 *           type: string
 *         description: The ID of the group to retrieve
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved group information
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     _id:
 *                       type: string
 *                       example: 65c1df2eace63d260852c3ce
 *                     name:
 *                       type: string
 *                       example: Support Team
 *                     description:
 *                       type: string
 *                       example: Group for all support agents
 *                     members:
 *                       type: array
 *                       items:
 *                         type: string
 *                         example: 65bdfd21ce5aa16a93c01c3b
 *                     createdAt:
 *                       type: string
 *                       format: date-time
 *                     updatedAt:
 *                       type: string
 *                       format: date-time
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       404:
 *         description: Group not found
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/logout:
 *   post:
 *     summary: User logout
 *     description: Logs the currently authenticated user out of the system by invalidating their token/session.
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully logged out
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Logged out successfully
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/subadmin/delete/{id}:
 *   delete:
 *     summary: Delete a subadmin
 *     description: Deletes a subadmin user by their ID.
 *     tags:
 *       - Subadmin
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: ID of the subadmin to delete
 *         schema:
 *           type: string
 *           example: 65aa6d66e5b2e893a339e3ae
 *     responses:
 *       200:
 *         description: Successfully deleted subadmin
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Subadmin deleted successfully
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       404:
 *         description: Subadmin not found
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/delete/login/session/{id}:
 *   delete:
 *     summary: Delete user login session
 *     description: Deletes a specific user login session using its ID.
 *     tags:
 *       - User Session
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         description: ID of the login session to delete
 *         schema:
 *           type: string
 *           example: 65c2215118e41631fefe3021
 *     responses:
 *       200:
 *         description: Successfully deleted login session
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Login session deleted successfully
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       404:
 *         description: Login session not found
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/dashboard:
 *   post:
 *     summary: Get Enterprise Dashboard Data
 *     description: Returns dashboard metrics for a given date range.
 *     tags:
 *       - Enterprise Dashboard
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - startDate
 *               - endDate
 *             properties:
 *               startDate:
 *                 type: string
 *                 format: date
 *                 example: "2024-10-11"
 *               endDate:
 *                 type: string
 *                 format: date
 *                 example: "2024-10-11"
 *     responses:
 *       200:
 *         description: Dashboard data fetched successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   description: Contains dashboard metrics
 *       400:
 *         description: Invalid input data
 *       401:
 *         description: Unauthorized - Invalid or expired token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/token/refresh:
 *   post:
 *     summary: Refresh User Token
 *     description: Refreshes the authentication token using a valid existing token.
 *     tags:
 *       - Authentication
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - token
 *             properties:
 *               token:
 *                 type: string
 *                 example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
 *     responses:
 *       200:
 *         description: Token refreshed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 newToken:
 *                   type: string
 *                   description: The new refreshed token
 *                   example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
 *       400:
 *         description: Invalid request - token missing or malformed
 *       401:
 *         description: Unauthorized - token expired or invalid
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/push/send:
 *   post:
 *     summary: Send Push Notification
 *     description: Sends a push notification to a specific SIP user for an incoming call.
 *     tags:
 *       - Push Notification
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - sip_username
 *               - caller_number
 *               - caller_id
 *               - sip_domain
 *               - call_type
 *             properties:
 *               sip_username:
 *                 type: string
 *                 example: "7474"
 *               caller_number:
 *                 type: string
 *                 example: "5002"
 *               caller_id:
 *                 type: string
 *                 example: "9519ge233tb9fu4st0k934"
 *               sip_domain:
 *                 type: string
 *                 example: "example.com"
 *               call_type:
 *                 type: integer
 *                 description: Type of call (e.g., 0 for voice, 1 for video)
 *                 example: 0
 *     responses:
 *       200:
 *         description: Push notification sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Push notification sent
 *       400:
 *         description: Bad Request - Missing or invalid parameters
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/link/login:
 *   post:
 *     summary: Login via link
 *     description: Authenticates a user using a FQDN token and device info.
 *     tags:
 *       - Authentication
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - fqdntoken
 *               - device_id
 *               - device_name
 *               - osversion
 *               - device_os_version
 *               - push_token
 *               - apns_push_token
 *               - countryCode
 *             properties:
 *               fqdntoken:
 *                 type: string
 *                 example: w6BmN
 *               device_id:
 *                 type: string
 *                 example: 23ab38458134f6dcqwwdcas
 *               device_name:
 *                 type: string
 *                 example: testing SM-T505
 *               osversion:
 *                 type: integer
 *                 example: 1
 *               device_os_version:
 *                 type: integer
 *                 example: 12
 *               push_token:
 *                 type: string
 *                 example: cZmRyZvqQzm1HPYO0WJzcT:APA91bE4FbrO83...
 *               apns_push_token:
 *                 type: string
 *                 example: cZmRyZvqQzm1HPYO0WJzcT:APA91bE4FbrO83...
 *               countryCode:
 *                 type: string
 *                 example: GB
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 token:
 *                   type: string
 *                   example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
 *       400:
 *         description: Invalid login parameters
 *       401:
 *         description: Unauthorized - Invalid token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/contacts:
 *   put:
 *     summary: Update user's contacts
 *     description: Allows a user to update their list of contacts.
 *     tags:
 *       - Contacts
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - contacts
 *             properties:
 *               contacts:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     name:
 *                       type: string
 *                       example: "409080151"
 *                     givenName:
 *                       type: string
 *                       nullable: true
 *                       example: null
 *                     number:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           label:
 *                             type: string
 *                             example: mobile
 *                           value:
 *                             type: string
 *                             example: "409080151"
 *     responses:
 *       200:
 *         description: Contacts updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Contacts updated
 *       400:
 *         description: Invalid request payload
 *       401:
 *         description: Unauthorized - Missing or invalid token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/contact/list:
 *   get:
 *     summary: Get user's contact list
 *     description: Retrieves the list of contacts associated with the authenticated user.
 *     tags:
 *       - Contacts
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of contacts retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 contacts:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       name:
 *                         type: string
 *                         example: "John Doe"
 *                       number:
 *                         type: array
 *                         items:
 *                           type: object
 *                           properties:
 *                             label:
 *                               type: string
 *                               example: mobile
 *                             value:
 *                               type: string
 *                               example: "1234567890"
 *       401:
 *         description: Unauthorized - Missing or invalid token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/cdr/add/call:
 *   post:
 *     summary: Add Call Detail Record (CDR)
 *     description: Adds a new Call Detail Record (CDR) for a specific call.
 *     tags:
 *       - Call Records
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               call_id:
 *                 type: string
 *                 example: "837112024-14AC8C6A00000000469260738@0.0.0.07"
 *               to:
 *                 type: string
 *                 example: "sip:3001@example.com:5060"
 *               from:
 *                 type: string
 *                 example: "sip:819500039@192.0.2.20:5060;user=phone"
 *               call_type:
 *                 type: string
 *                 example: ""
 *     responses:
 *       200:
 *         description: Call record added successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Call record added successfully
 *       400:
 *         description: Bad Request - Missing or invalid parameters
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/call/list:
 *   post:
 *     summary: Get list of user calls
 *     description: Retrieves a paginated list of calls made or received by the user.
 *     tags:
 *       - User Calls
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               page:
 *                 type: integer
 *                 example: 1
 *               size:
 *                 type: integer
 *                 example: 50
 *     responses:
 *       200:
 *         description: List of user calls retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       call_id:
 *                         type: string
 *                       from:
 *                         type: string
 *                       to:
 *                         type: string
 *                       timestamp:
 *                         type: string
 *                         format: date-time
 *                       duration:
 *                         type: integer
 *                         description: Duration of the call in seconds
 *                 total:
 *                   type: integer
 *                   example: 150
 *                 page:
 *                   type: integer
 *                   example: 1
 *                 size:
 *                   type: integer
 *                   example: 50
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/cdr/list:
 *   post:
 *     summary: Get Call Detail Records (CDRs)
 *     description: Retrieves a paginated list of CDRs filtered by date range, endpoint number, and call type.
 *     tags:
 *       - CDR (Call Detail Records)
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               page:
 *                 type: integer
 *                 example: 1
 *               size:
 *                 type: integer
 *                 example: 20
 *               eid:
 *                 type: string
 *                 nullable: true
 *                 example: null
 *               endpointnumber:
 *                 type: string
 *                 nullable: true
 *                 example: null
 *               startDate:
 *                 type: string
 *                 format: date-time
 *                 example: "2024-10-07T00:00:00.000Z"
 *               endDate:
 *                 type: string
 *                 format: date-time
 *                 example: "2024-10-07T23:59:59.000Z"
 *               internal_calls:
 *                 type: integer
 *                 enum: [0, 1]
 *                 description: 0 for external calls, 1 for internal calls
 *                 example: 0
 *     responses:
 *       200:
 *         description: Paginated list of CDRs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       call_id:
 *                         type: string
 *                       from:
 *                         type: string
 *                       to:
 *                         type: string
 *                       duration:
 *                         type: integer
 *                       timestamp:
 *                         type: string
 *                         format: date-time
 *                 total:
 *                   type: integer
 *                   example: 100
 *                 page:
 *                   type: integer
 *                   example: 1
 *                 size:
 *                   type: integer
 *                   example: 20
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/provisioninglog:
 *   post:
 *     summary: Get Provisioning Logs
 *     description: Retrieves a paginated list of provisioning logs for a specified user ID.
 *     tags:
 *       - Provisioning
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               uid:
 *                 type: string
 *                 description: User ID whose provisioning logs are to be fetched
 *                 example: "65f156fdb909ab54279d5631"
 *               page:
 *                 type: integer
 *                 description: Page number for pagination
 *                 example: 1
 *               size:
 *                 type: integer
 *                 description: Number of records per page
 *                 example: 10
 *     responses:
 *       200:
 *         description: List of provisioning logs
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       timestamp:
 *                         type: string
 *                         format: date-time
 *                       action:
 *                         type: string
 *                       status:
 *                         type: string
 *                       message:
 *                         type: string
 *                 page:
 *                   type: integer
 *                 size:
 *                   type: integer
 *                 total:
 *                   type: integer
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/filter/list:
 *   post:
 *     summary: Get Call Filter List
 *     description: Retrieves the list of call filters applied to the specified extension/user.
 *     tags:
 *       - Call Filters
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               eid:
 *                 type: string
 *                 description: Extension or user ID for which to retrieve filters
 *                 example: "65f0096f301cbad3951a54a7"
 *     responses:
 *       200:
 *         description: Successfully retrieved call filter list
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 filters:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       type:
 *                         type: string
 *                         description: Type of filter (e.g. blacklist, whitelist)
 *                       value:
 *                         type: string
 *                         description: Filtered number or pattern
 *                       direction:
 *                         type: string
 *                         description: Direction of call (e.g. inbound, outbound)
 *                 total:
 *                   type: integer
 *                   description: Total number of filters
 *       401:
 *         description: Unauthorized - Token missing or invalid
 *       500:
 *         description: Server error
 */
/**
 * @swagger
 * /v1/user/generate/fqdn:
 *   post:
 *     summary: Generate FQDN Token
 *     description: Generates an FQDN token for the specified user.
 *     tags:
 *       - User
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               uid:
 *                 type: string
 *                 description: The unique ID of the user
 *                 example: "673b412059caca1ea9902890"
 *     responses:
 *       200:
 *         description: Successfully generated FQDN token
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 token:
 *                   type: string
 *                   description: Generated FQDN token
 *                 expiresIn:
 *                   type: integer
 *                   description: Token expiry time in seconds
 *       400:
 *         description: Invalid UID or missing parameters
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/sms/config:
 *   get:
 *     summary: Get SMS Configuration
 *     description: Retrieves the current SMS configuration for the authenticated user.
 *     tags:
 *       - SMS
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved SMS configuration
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 provider:
 *                   type: string
 *                   description: SMS provider name
 *                   example: "twilio"
 *                 sender_id:
 *                   type: string
 *                   description: Sender ID used for SMS
 *                   example: "MyCompany"
 *                 api_key:
 *                   type: string
 *                   description: API key (may be masked)
 *                   example: "******"
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/sms/config/update:
 *   put:
 *     summary: Update SMS Configuration
 *     description: Updates the SMS API configuration for the authenticated user.
 *     tags:
 *       - SMS
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               sms_api_name:
 *                 type: string
 *                 example: "Sms Apis"
 *               sms_url_method:
 *                 type: integer
 *                 enum: [0, 1]
 *                 description: 0 for GET, 1 for POST
 *                 example: 1
 *               sms_count_type:
 *                 type: integer
 *                 description: Message counting type (e.g., per message or per character)
 *                 example: 1
 *               sms_api_url:
 *                 type: string
 *                 format: uri
 *                 example: "http://203.0.113.10:8080/bulksms/bulksms"
 *               sms_keypair_value:
 *                 type: string
 *                 description: Key-value pair used for sending the SMS
 *                 example: "username=0418-stltest&password=stl@2024&type=0&dlr=1&destination=7990917321&source=STPBXCORE&message="
 *               sms_key_receiver:
 *                 type: string
 *                 description: Key for the receiver in the API
 *                 example: "destination"
 *               sms_key_message:
 *                 type: string
 *                 description: Key for the message content in the API
 *                 example: "message"
 *               sms_key_message_maxlength:
 *                 type: string
 *                 description: Max length of the message
 *                 example: "1000"
 *               isapi_enable:
 *                 type: integer
 *                 enum: [0, 1]
 *                 description: 1 to enable API, 0 to disable
 *                 example: 1
 *     responses:
 *       200:
 *         description: SMS configuration updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "SMS configuration updated"
 *       400:
 *         description: Invalid input
 *       401:
 *         description: Unauthorized
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/info:
 *   get:
 *     summary: Get Enterprise Info
 *     description: Fetches detailed information about the authenticated enterprise.
 *     tags:
 *       - Enterprise
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved enterprise info
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     enterprise_id:
 *                       type: string
 *                       example: "65f0096f301cbad3951a54a7"
 *                     name:
 *                       type: string
 *                       example: "ExampleCorp Technologies"
 *                     domain:
 *                       type: string
 *                       example: "callnevox.com"
 *                     sip_domain:
 *                       type: string
 *                       example: "callnevox.com"
 *                     sip_port:
 *                       type: string
 *                       example: "9090"
 *                     created_at:
 *                       type: string
 *                       format: date-time
 *                       example: "2024-10-07T10:45:00.000Z"
 *                     ...:
 *                       description: Additional enterprise metadata
 *       401:
 *         description: Unauthorized (Invalid or missing token)
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/resetPassowrd:
 *   post:
 *     summary: Request password reset for enterprise
 *     description: Sends a password reset link or instructions to the provided enterprise email.
 *     tags:
 *       - Enterprise
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               enterprise_email:
 *                 type: string
 *                 format: email
 *                 example: john.smith@example.com
 *     responses:
 *       200:
 *         description: Password reset instructions sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Reset link has been sent to your email
 *       400:
 *         description: Invalid request (e.g., email not found)
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/confirmResetPassword:
 *   post:
 *     summary: Confirm and set a new password for enterprise account
 *     description: Validates the token and sets a new password for the enterprise user.
 *     tags:
 *       - Enterprise
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - password
 *               - confirm_password
 *               - token
 *             properties:
 *               password:
 *                 type: string
 *                 format: password
 *                 example: new123sadgfx2
 *               confirm_password:
 *                 type: string
 *                 format: password
 *                 example: new123sadgfx2
 *               token:
 *                 type: string
 *                 example: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlaWQiOiI2NWY5ODFkZDU2MDNjNWQ1MDRiNzdkZWMiLCJpYXQiOjE3MTE5NjUwMzAsImV4cCI6MTcxMTk2NTkzMH0.SB_9Df-sjPR-ukgrLO-fwxushve42yZg6BUMV6MG4Ik
 *     responses:
 *       200:
 *         description: Password reset successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Password has been successfully reset
 *       400:
 *         description: Validation error or mismatched passwords
 *       401:
 *         description: Invalid or expired token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/settings/callhandling:
 *   get:
 *     summary: Get user call handling settings
 *     description: Retrieves call handling settings for the authenticated user.
 *     tags:
 *       - User Settings
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved call handling settings
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 call_forwarding:
 *                   type: boolean
 *                   example: true
 *                 voicemail_enabled:
 *                   type: boolean
 *                   example: false
 *                 ring_timeout:
 *                   type: number
 *                   example: 30
 *                 forwarding_number:
 *                   type: string
 *                   example: "+911234567890"
 *       401:
 *         description: Unauthorized - invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/settings/callhandling/featuredetail:
 *   post:
 *     summary: Get detailed feature information for call handling
 *     description: Retrieves detailed settings for a specific call handling feature based on the featureId.
 *     tags:
 *       - User Settings
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               featureId:
 *                 type: integer
 *                 example: 1
 *     responses:
 *       200:
 *         description: Successfully retrieved feature details
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               example:
 *                 featureName: "Call Forwarding"
 *                 enabled: true
 *                 config:
 *                   timeout: 30
 *                   forwardTo: "+911234567890"
 *       400:
 *         description: Bad request - invalid or missing input
 *       401:
 *         description: Unauthorized - invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/settings/callhandling/featuredetail/update:
 *   put:
 *     summary: Update specific feature detail for call handling
 *     description: Updates the configuration of a specific call handling feature such as call forwarding.
 *     tags:
 *       - User Settings
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - focalNumber
 *               - state
 *               - featureId
 *             properties:
 *               focalNumber:
 *                 type: string
 *                 description: The phone number to be used for the feature
 *                 example: "917949135770"
 *               state:
 *                 type: string
 *                 enum: [A, I]
 *                 description: 'A' for Active, 'I' for Inactive
 *                 example: "I"
 *               featureId:
 *                 type: integer
 *                 description: The ID of the feature to update
 *                 example: 1
 *     responses:
 *       200:
 *         description: Feature configuration updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               example:
 *                 message: "Feature detail updated successfully"
 *       400:
 *         description: Bad request - invalid input
 *       401:
 *         description: Unauthorized - invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/dashboard/ent:
 *   post:
 *     summary: Get enterprise dashboard data
 *     description: Retrieves enterprise dashboard metrics for the specified enterprise ID and date range.
 *     tags:
 *       - Enterprise Dashboard
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - eid
 *               - startDate
 *               - endDate
 *             properties:
 *               eid:
 *                 type: string
 *                 description: Enterprise ID
 *                 example: "65f0096f301cbad3951a54a7"
 *               startDate:
 *                 type: string
 *                 format: date
 *                 description: Start date in YYYY-MM-DD format
 *                 example: "2024-01-01"
 *               endDate:
 *                 type: string
 *                 format: date
 *                 description: End date in YYYY-MM-DD format
 *                 example: "2024-12-31"
 *     responses:
 *       200:
 *         description: Successfully retrieved dashboard data
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               example:
 *                 totalCalls: 1200
 *                 answeredCalls: 950
 *                 missedCalls: 250
 *                 averageCallDuration: "00:02:35"
 *       400:
 *         description: Bad request - missing or invalid parameters
 *       401:
 *         description: Unauthorized - missing or invalid token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/livekit/gettoken:
 *   post:
 *     summary: Get LiveKit access token
 *     description: Generates a LiveKit access token for the authenticated user.
 *     tags:
 *       - LiveKit
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully generated LiveKit token
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 token:
 *                   type: string
 *                   description: JWT token for accessing LiveKit services
 *                   example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *       401:
 *         description: Unauthorized - invalid or expired token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/favorite/contacts/add:
 *   post:
 *     summary: Add a contact to user's favorites
 *     description: Allows an authenticated user to add a contact to their favorite list or remove from it using `contact_unfavorite` flag.
 *     tags:
 *       - Favorite Contacts
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - contact_number
 *               - contact_unfavorite
 *             properties:
 *               contact_name:
 *                 type: string
 *                 description: Name of the contact (optional)
 *                 example: "John Doe"
 *               contact_number:
 *                 type: string
 *                 description: Phone number of the contact
 *                 example: "+917990915600"
 *               contact_unfavorite:
 *                 type: integer
 *                 description: Flag to unfavorite (1) or favorite (0)
 *                 example: 1
 *     responses:
 *       200:
 *         description: Contact successfully added/updated in favorites
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Contact added to favorites."
 *       400:
 *         description: Bad request - missing or invalid fields
 *       401:
 *         description: Unauthorized - invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/favorite/contacts/list:
 *   get:
 *     summary: Get favorite contacts
 *     description: Retrieves the list of favorite contacts for the authenticated user.
 *     tags:
 *       - Favorite Contacts
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Successfully retrieved favorite contacts list
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 contacts:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       contact_name:
 *                         type: string
 *                         example: "Jane Smith"
 *                       contact_number:
 *                         type: string
 *                         example: "+917990915600"
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Favorite contacts fetched successfully."
 *       401:
 *         description: Unauthorized - invalid or missing token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/admin/password/update:
 *   put:
 *     summary: Update admin password
 *     description: Allows an enterprise admin to update their password by providing current and new credentials.
 *     tags:
 *       - Admin
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - user_email
 *               - user_password
 *               - user_newPassword
 *               - user_newPassword_conform
 *             properties:
 *               user_email:
 *                 type: string
 *                 example: admin@example.com
 *               user_password:
 *                 type: string
 *                 example: Admin@123
 *               user_newPassword:
 *                 type: string
 *                 example: Admin@123
 *               user_newPassword_conform:
 *                 type: string
 *                 example: Admin@123
 *     responses:
 *       200:
 *         description: Password updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Password updated successfully
 *       400:
 *         description: Bad Request - Passwords do not match or invalid input
 *       401:
 *         description: Unauthorized - Invalid or expired token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/enterprise/cdr/list/download:
 *   post:
 *     summary: Download Enterprise CDR List
 *     description: Allows downloading the Call Detail Records (CDR) for an enterprise based on filters like date range and call type.
 *     tags:
 *       - CDR
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - startDate
 *               - endDate
 *               - internal_calls
 *             properties:
 *               eid:
 *                 type: string
 *                 nullable: true
 *                 example: null
 *               endpointnumber:
 *                 type: string
 *                 nullable: true
 *                 example: null
 *               startDate:
 *                 type: string
 *                 format: date-time
 *                 example: 2024-05-14T00:00:00.000Z
 *               endDate:
 *                 type: string
 *                 format: date-time
 *                 example: 2024-05-14T23:59:59.000Z
 *               internal_calls:
 *                 type: integer
 *                 enum: [0, 1]
 *                 description: 0 for external calls, 1 for internal calls
 *     responses:
 *       200:
 *         description: CDR file download started successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 downloadLink:
 *                   type: string
 *                   example: https://example.com/files/cdr-report.csv
 *                 message:
 *                   type: string
 *                   example: CDR file generated and ready for download
 *       400:
 *         description: Bad Request - Invalid input
 *       401:
 *         description: Unauthorized - Invalid or expired token
 *       500:
 *         description: Internal server error
 */
/**
 * @swagger
 * /v1/user/cdr/end/call:
 *   post:
 *     summary: End a call and store CDR
 *     description: Marks the end of a call and logs the Call Detail Record (CDR) for tracking and billing purposes.
 *     tags:
 *       - CDR
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - call_id
 *               - to
 *               - from
 *               - call_type
 *             properties:
 *               call_id:
 *                 type: string
 *                 description: Unique identifier for the call
 *                 example: 1208222024-14AC8C6A0000000019282210981@0.0.0.0
 *               to:
 *                 type: string
 *                 description: SIP URI of the call recipient
 *                 example: sip:1212@example.com
 *               from:
 *                 type: string
 *                 description: SIP URI of the caller
 *                 example: sip:1211@example.com
 *               call_type:
 *                 type: string
 *                 enum: ["0", "1"]
 *                 description: Type of call (0 = outgoing, 1 = incoming)
 *                 example: "0"
 *     responses:
 *       200:
 *         description: Call ended and CDR recorded successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Call ended and recorded successfully
 *       400:
 *         description: Bad Request - Missing or invalid parameters
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/favorite/contacts/delete:
 *   post:
 *     summary: Delete a favorite contact
 *     description: Removes a contact from the user's list of favorite contacts.
 *     tags:
 *       - Favorite Contacts
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - favorite_id
 *             properties:
 *               favorite_id:
 *                 type: string
 *                 description: The unique identifier of the favorite contact to delete
 *                 example: 66430ce9717aec8f40307280
 *     responses:
 *       200:
 *         description: Contact removed from favorites successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Favorite contact deleted successfully
 *       400:
 *         description: Bad Request - Missing or invalid parameters
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/call/time/update:
 *   put:
 *     summary: Update call time
 *     description: Updates the time or timestamp associated with a specific call using the call ID.
 *     tags:
 *       - Call Management
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - call_id
 *             properties:
 *               call_id:
 *                 type: string
 *                 description: Unique identifier of the call
 *                 example: 49ftd11iw3y1290jxuiz
 *     responses:
 *       200:
 *         description: Call time updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Call time updated
 *       400:
 *         description: Bad Request - Missing or invalid call_id
 *       500:
 *         description: Internal Server Error
 */
/**
 * @swagger
 * /v1/user/remove/call/logs:
 *   put:
 *     summary: Remove call logs
 *     description: Soft deletes or removes call logs for the specified call IDs.
 *     tags:
 *       - Call Management
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - call_ids
 *             properties:
 *               call_ids:
 *                 type: array
 *                 description: List of call IDs to be removed
 *                 items:
 *                   type: string
 *                 example: ["6756e675b23ff3562122a004"]
 *     responses:
 *       200:
 *         description: Call logs removed successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Call logs removed
 *       400:
 *         description: Bad Request - Missing or invalid call_ids
 *       401:
 *         description: Unauthorized - Invalid token
 *       500:
 *         description: Internal Server Error
 */



