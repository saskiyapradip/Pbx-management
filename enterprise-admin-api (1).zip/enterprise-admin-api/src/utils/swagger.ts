// src/utils/swagger.ts
import swaggerJSDoc from 'swagger-jsdoc';

const options: swaggerJSDoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Enterprise Admin API',
      version: '1.0.0',
      description: 'Swagger docs',
    },
    servers: [{ url: 'https://api.example.com/' }],
  },
  apis: ['./src/utils/swaggerDocs.ts'], // adjust path to your project
};

export const swaggerSpec = swaggerJSDoc(options);
