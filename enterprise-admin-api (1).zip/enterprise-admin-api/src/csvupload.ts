import multer from 'multer';
var maxSize = 1 * 1024 * 1024; //1mb
import fs from 'fs';


const csvupload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, "./");
    },
    filename: function (req, file, cb) {
      console.log("file mimetype", file)
      var mimeType = file.mimetype.split("/");
      var myType = "/" + mimeType[0] + "/";
      const dir = "../uploads" + myType;
     
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, {
          recursive: true,
        });
      }
      var fileUrl = dir + file.originalname;
      // let file_extantion_tmp: any = file.originalname.split(".");
      // let file_extantion: any = file_extantion_tmp[file_extantion_tmp.length - 1];
      // let fileUrl: any = dir + file_type_nm + "__" + Date.now() + "." + file_extantion;
      cb(null, fileUrl);
    },
  }),
  fileFilter:function (req, file, cb) {
    console.log("file",file)
    file.fieldname
    if(file.fieldname === "file" && file.mimetype == "text/csv"){
      cb(null,true)
    }else{
      let file_field_name:any = file.fieldname
      let error_message:any = file_field_name +" "+"file Format not Allowed";
      let new_error:any =new Error(error_message)
       cb(new_error)
    }
    // if(file.mimetype == "image/jpeg" || file.mimetype == "image/png" || file.mimetype == "audio/mpeg" || file.mimetype == "video/mp4" 
    // || file.mimetype ==  "application/pdf" || file.mimetype == "audio/aac" || file.mimetype == "application/msword"){
    //   cb(null,true)
    // }else{
    //   let file_field_name:any = file.fieldname
    //   let error_message:any = file_field_name +" "+"file Format not Allowed";
    //   let new_error:any =new Error(error_message)
    //    cb(new_error)
    // }
  },
  limits: { fileSize: maxSize },
}).single("file");


export default csvupload;