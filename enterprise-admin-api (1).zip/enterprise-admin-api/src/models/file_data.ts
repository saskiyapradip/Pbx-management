import mongoose, { Schema, Document } from "mongoose";

export interface fileData {
    file_name: String;
    file_manage_name: String;
    size: String;
    mimetype: String;
}

export interface FileDataModel extends fileData, Document { }

const prepSchema: Schema = new Schema({
    file_name: {
        type: String,
        reauired: "file_name is required"
    },
    file_manage_name: {
        type: String,
        reauired: "file_manage_username is required"
    },
    size: {
        type: String,
        required: "size_password is required"
    },
    mimetype: {
        type: String,
    },
}, {
    timestamps: true
})

// prepSchema.index({enterprise_name:1, is_deleted:1,emailAddress:1,status:1})

export default mongoose.model<FileDataModel>("file_data", prepSchema);