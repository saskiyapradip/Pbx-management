// import multer from 'multer';
// var maxSize = 100 * 1024 * 1024; //100mb
// import fs from 'fs';
// import path from 'path';


// const upload = multer({
//   storage: multer.diskStorage({
//     destination: function (req, file, cb) {
//       cb(null, "./");
//     },
//     filename: function (req, file, cb) {
//       //console.log("file mimetype", file)
//       var mimeType = file.mimetype.split("/");
//       var myType = "/" + mimeType[0] + "/";
//       // const dir = "../uploads" + myType;
//       const dir =path.join(__dirname, "..", "..", "uploads");
//       console.log("Directory check passed 1:", dir);
//       // const dir ='../uploads';
//       let file_type_nm = mimeType[0]
//       let file_format = mimeType[1]
//       if (!fs.existsSync(dir)) {
//         fs.mkdirSync(dir, {
//           recursive: true,
//         });
//       }
//       // var fileUrl = dir + file.originalname;
//       let file_extantion_tmp: any = file.originalname.split(".");
//       let file_extantion: any = file_extantion_tmp[file_extantion_tmp.length - 1];
//       let fileUrl: any = Date.now() + "." + file_extantion;
//       cb(null, fileUrl);
//     },
//   }),
//   // fileFilter:function (req, file, cb) {
//   //   if(file.mimetype == "image/jpeg" || file.mimetype == "image/png" || file.mimetype == "audio/mpeg" || file.mimetype == "video/mp4" 
//   //   || file.mimetype ==  "application/pdf" || file.mimetype == "audio/aac" || file.mimetype == "application/msword"){
//   //     cb(null,true)
//   //   }else{
//   //     let new_error:any =new Error('file is not allowed')
//   //      cb(new_error)
//   //   }
//   // },
//   limits: { fileSize: maxSize },
// }).single("file");


// export default upload;


import multer from 'multer';
var maxSize = 100 * 1024 * 1024;
import fs from 'fs';
import path from 'path';

const uploadDir = path.join(__dirname, '..', '..', 'uploads');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // ensure uploads dir exists
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    console.log("Media Directory check passed:", uploadDir);
    cb(null, uploadDir); 
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const fileName = Date.now() + ext;
    cb(null, fileName);  
  },
});

const upload = multer({
  storage,
  fileFilter: function (req, file, cb) {
    if (
          // Images
    file.mimetype === "image/jpeg" ||
    file.mimetype === "image/jpg" ||
    file.mimetype === "image/png" ||
    file.mimetype === "image/gif" ||
    file.mimetype === "image/bmp" ||
    file.mimetype === "image/webp" ||
    file.mimetype === "image/svg+xml" ||

    // Audio
    file.mimetype === "audio/mpeg" ||   // mp3
    file.mimetype === "audio/wav" ||
    file.mimetype === "audio/aac" ||
    file.mimetype === "audio/ogg" ||
    file.mimetype === "audio/flac" ||
    file.mimetype === "audio/mp4" ||    // m4a (sometimes seen as audio/mp4)

    // Video
    file.mimetype === "video/mp4" ||
    file.mimetype === "video/x-msvideo" || // avi
    file.mimetype === "video/quicktime" || // mov
    file.mimetype === "video/x-ms-wmv" ||  // wmv
    file.mimetype === "video/x-flv" ||
    file.mimetype === "video/webm" ||
    file.mimetype === "video/x-matroska" || // mkv

    // Documents
    file.mimetype === "application/pdf" ||
    file.mimetype === "application/msword" ||  // .doc
    file.mimetype === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || // .docx
    file.mimetype === "application/vnd.ms-excel" || // .xls
    file.mimetype === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || // .xlsx
    file.mimetype === "application/vnd.ms-powerpoint" || // .ppt
    file.mimetype === "application/vnd.openxmlformats-officedocument.presentationml.presentation" || // .pptx
    file.mimetype === "text/plain" || // .txt
    file.mimetype === "application/rtf" || // .rtf
    file.mimetype === "text/csv" ||

    // Archives
    file.mimetype === "application/zip" ||
    file.mimetype === "application/x-rar-compressed" ||
    file.mimetype === "application/x-7z-compressed"
    ) {
      cb(null, true);
    } else {
      let new_error: any = new Error("File type is not allowed");
      cb(new_error);
    }
  },
  limits: { fileSize: maxSize },
}).single("file");

export default upload;
