import { Request, Response, NextFunction } from "express";
import user_admin from "../../models/user_admin";
import mongoose from "mongoose";
import upload from "../../upload";
import admin_token from "../../helper/admin"
import get_token from "../../helper/userHeader";
import enterprise from "../../models/enterprise";
import User_token_admin from "../../helper/helper_admin";
import accessgroup from "../../models/accessgroup";
import REGEXP from "../../regexp";
import multer from "multer";
import { config } from "../../config";
const AllSubAdminList = async (req: Request, res: Response, next: NextFunction) => {
    try {
    let page: any = req.query.page
    let size: any = req.query.size
    if (!page) page = 1
    if (!size) size = 50

    let limit: any = parseInt(size)
    let skip: any = (page - 1) * size;

    let search: any = req.query.search?.toString()
    let find_query: any;
    if (search) {
      find_query = {
        user_name: {
            $regex: search,
            $options:"i"
          },
        user_type:2,
        is_deleted:0,
      }
    } else {
      find_query = {
        user_type:2,
        is_deleted:0,
      }
    }

    let SubAdminAggregate: any = await user_admin.aggregate([
      {
        $match: find_query,
      },
      {
        $lookup: {
          from: "enterprises",
          localField: "selected_Enterprise",
          foreignField: "_id",
          as: "selected_Enterprise",
        },
      },
      {
        $addFields: {
          enterprise_name: {
            $cond: [
              { $eq: ["$access_profile_type", 1] },
              "root",
              {
                $cond: [
                  { $gt: [{ $size: "$selected_Enterprise" }, 0] },
                  { $arrayElemAt: ["$selected_Enterprise.enterprise_name", 0] },
                  "Enterprise Not Found",
                ],
              },
            ],
          },
        },
      },
      {
        $project: {
          user_name: 1,
          sipDomain: 1,
          access_profile_type: 1,
          is_online: 1,
          user_status: 1,
          user_image: 1,
          last_login_time: 1,
          updatedAt: 1,
          createdAt: 1,
          enterprise_name: 1,
        },
      },
      {
        $facet: {
          data: [
            { $sort: { createdAt: -1 } },
            { $skip: skip },
            { $limit: limit },
          ],
          totalCount: [{ $count: "count" }],
        },
      },
    ]);
    const SubAdminList = SubAdminAggregate[0]?.data || [];
    const get_total_count = SubAdminAggregate[0]?.totalCount[0]?.count || 0;
    const total_page_count = Math.ceil(get_total_count / size);

        return res.status(200).send({
            success: 1,
            message: "Sub AdminList List",
            SubAdminList: SubAdminList,
            total_page_count:total_page_count,
            total_subadmin_count:get_total_count
        });
    } catch (error) {
      console.log(error)
         res.status(500).send({
            success: 0,
            messsage: "Internal Server Error"
        })
    }
}
const createSubAdmin = async (req: Request, res: Response, next: NextFunction) => {
    try {  
      upload(req, res, async (error) => {
        if (!req?.files) {
          res.status(404).send({
            success: 0,
            message: "File not found",
          });
          return;
        }
        if (error) {
          if (error instanceof multer.MulterError) {
            let create_message:any = error.field+" "+ error.message
            res.status(500).send({
              success: 0,
              message: create_message,
            });
          } else {
            res.status(500).send({
              success: 0,
              message: error.message,
            });
          }
          return;
        }
        const token = await get_token(req);
        const user_detail = await User_token_admin(token);
        let eid: any = user_detail?.eid;

        let data: any = req.body;
        let user_name = data.user_name;
        let name = data.name;
        let user_email = data.user_email;
        let user_password = data.user_password;
        let confirm_password = data.confirm_password;
        let user_status = data.user_status;
        let user_mobileNumber = data.user_mobileNumber;
        let user_address = data.user_address;
        let accessgroup_id = data.accessgroup;
        let access_profile_type = data.access_profile_type;
        let selected_Enterprise = data.selected_Enterprise;
        selected_Enterprise = JSON.parse(selected_Enterprise);

        if(access_profile_type == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "access_profile_type is Mandatory",
          });
        }

        if (!REGEXP.SUB_ADMIN.access_profile_type.test(access_profile_type)) {
          return res.status(403).send({
            success: 0,
            message:
              "SubAdmin access_profile_type validation failed: It should be 1 or 2",
          });
        }

        if(accessgroup_id == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "accessgroup is Mandatory",
          });
        }

        let get_accecgroup:any = await accessgroup.findById({
          _id:accessgroup_id
        })

        if (accessgroup_id !== undefined && get_accecgroup == null) {
          res.status(403).send({
            success: 0,
            message:
              "SubAdmin accessgroup validation failed: It should be Exists on Database",
          });
        }

        if(user_status == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "user_status is Mandatory",
          });
        }
        
        if (!REGEXP.SUB_ADMIN.user_status.test(user_status)) {
          return res.status(403).send({
            success: 0,
            message:  
              "SubAdmin user_status validation failed:It should be 0 or 1",
          });
        }

        if(user_name == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "user_name is Mandatory",
          });
        }

        if (!REGEXP.COMMON.LENGTH50.test(user_name)) {
          res.status(403).send({
            success: 0,
            message:
              "SubAdmin userName validation failed: Length should be between 1-50",
          });
        }

        if(name == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "name is Mandatory",
          });
        }
        
        if (!REGEXP.COMMON.LENGTH50.test(name)) {
            res.status(403).send({
              success: 0,
              message:
                "SubAdmin name validation failed: Length should be between 1-50",
            });
        }

        if(user_password == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "user_password is Mandatory",
          });
        }

        if(confirm_password == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "confirm_password is Mandatory",
          });
        }

        if(selected_Enterprise == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "selected_Enterprise is Mandatory",
          });
        }
        

        if (selected_Enterprise.length == 0) {
          return res.status(403).send({
              success: 0,
              message:
                "selected_Enterprise validation failed: selected_Enterprise Is Empty.",
            });
        }

        if(user_email == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "user_email is Mandatory",
          });
        }

        // if (!REGEXP.COMMON.EMAIL.test(user_email)) {
        //     res.status(403).send({
        //       success: 0,
        //       message: "user_email Validation Failed: user_email is require and it should be valid. Max char length is 254",
        //     });
        // }

        if(user_mobileNumber == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "user_mobileNumber is Mandatory",
          });
        }

        // if (!REGEXP.SUB_ADMIN.PHONENUMBER.test(user_mobileNumber)) {
        //     res.status(403).send({
        //       success: 0,
        //       message: "user_mobileNumber Validation Failed: phoneNumber is require and it should be valid. Length range: [3,16]",
        //     });
        // }

        if(user_address == undefined){
          return res.status(403).send({
            success: 0,
            message:
              "user_address is Mandatory",
          });
        }

        if (!REGEXP.SUB_ADMIN.user_address.test(user_address)) {
          res.status(403).send({
            success: 0,
            message: "user_address Validation Failed: phoneNumber is require and it should be valid. Length range: 1-350",
          });
         }

          let check_user_exists: any = await user_admin.findOne({
            name: name,
            user_type: { $ne: 1 },
            is_deleted:0
          });
  
          if (check_user_exists) {
            return res.status(409).send({
              success: 0,
              message: "Sub Admin Already Exists With This " + name + " Name",
            });
          }
  
          let check_user_exists_email: any = await user_admin.findOne({
            user_email: user_email,
            user_type: { $ne: 1 },
            is_deleted: 0,
          });
  
          if (check_user_exists_email) {
            return res.status(409).send({
              success: 0,
              message: "Sub Admin Already Exists With This " + user_email + " Email",
            });
          }
  
          let files_detail:any= req?.files;
          let image_url:any = "";
          
          if(files_detail !== undefined &&files_detail.file && files_detail.file[0]?.path){
            let  myUrl = files_detail.file[0]?.path 
            myUrl = myUrl.replace("../uploads", "uploads");
            image_url =  myUrl
            }


          let sipDomain: any = "";
          if (access_profile_type == 1) {
            sipDomain = `${config.app_configs.DEFAULT_DOMAIN}`;
          } else {
            if (!mongoose.Types.ObjectId.isValid(selected_Enterprise[0])) {
              return res.status(400).send({ success: 0, message: "Invalid ObjectId" });
            }
            let enterprise_id: any = new mongoose.Types.ObjectId(selected_Enterprise[0]);
  
            let enterprise_detail: any = await enterprise.findById({
              _id: enterprise_id,
            });
            sipDomain = `${config.app_configs.DEFAULT_DOMAIN}`;
          }
  
          let create_enterprise_nm: String = user_name + sipDomain.toString();
  
          let add_subadmin: any = new user_admin();
          add_subadmin.user_name = user_name;
          add_subadmin.userName = create_enterprise_nm;
          add_subadmin.name = name;
          add_subadmin.user_email = user_email;
          add_subadmin.user_password = user_password;
          add_subadmin.user_status = user_status;
          add_subadmin.user_mobileNumber = user_mobileNumber;
          add_subadmin.user_address = user_address;
          add_subadmin.user_type = 2;
          add_subadmin.accessgroup = accessgroup_id;
          add_subadmin.selected_Enterprise = selected_Enterprise;
          add_subadmin.user_image = image_url;
          add_subadmin.sipDomain = sipDomain;
          add_subadmin.is_deleted = 0
          add_subadmin.access_profile_type = access_profile_type;
          add_subadmin.eid = eid;
          await add_subadmin.save();
  
          return res.status(201).send({
            success: 1,
            message: "SubAdmin Created Successfully",
            SubAdmin_Detail: add_subadmin,
          });
        } 
      );
    } catch (error) {
      res.status(500).send({
        success: 0,
        message: "Internal Server Error",
      });
    }
};
const getSubAdminDetailByID = async (req: Request, res: Response, next: NextFunction) => {
    try {
        let subAdmin_id: any = req.params.subAdmin_id
        if (!mongoose.Types.ObjectId.isValid(subAdmin_id)) {
            return res.status(400).send({ 
                success:0,
                message: "Invalid ObjectId"
             });
        }

        let get_group_detail: any = await user_admin.findOne({
            _id: subAdmin_id,
            is_deleted:0
        })

        return res.status(201).send({
            success: 1,
            message: "SubAdmin Detail",
            SubAdmin_Detail: get_group_detail
        })

    } catch (error) {
        res.status(500).send({
            success: 0,
            message: "Internal Server Error"
        })
    }
}
const EditAdminDetailByID = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    upload(req, res, async (error) => {
      if (!req?.files) {
        res.status(404).send({
          success: 0,
          message: "File not found",
        });
        return;
      }
      if (error) {
        if (error instanceof multer.MulterError) {
          let create_message:any = error.field+" "+ error.message
          res.status(500).send({
            success: 0,
            message: create_message,
          });
        } else {
          res.status(500).send({
            success: 0,
            message: error.message,
          });
        }
        return;
      }
      let subAdmin_id: any = req.params.subAdmin_id;
      if (!mongoose.Types.ObjectId.isValid(subAdmin_id)) {
        return res.status(400).send({
          success: 0,
          message: "Invalid ObjectId",
        });
      }
      const token: any = await get_token(req);
      const user_detail: any = await admin_token(token);
      let data: any = req.body;
      let user_name = data.user_name;
      let name = data.name;
      let user_email = data.user_email;
      let user_password = data.user_password;
      let confirm_password = data.confirm_password;
      let user_status = data.user_status;
      let user_mobileNumber = data.user_mobileNumber;
      let user_address = data.user_address;
      let accessgroup_id = data.accessgroup;
      let access_profile_type = data.access_profile_type;
      let selected_Enterprise = data.selected_Enterprise;
      selected_Enterprise = JSON.parse(selected_Enterprise);
      let user_image = data.user_image;

      if (access_profile_type == undefined) {
        return res.status(403).send({
          success: 0,
          message: "access_profile_type is Mandatory",
        });
      }

      if (!REGEXP.SUB_ADMIN.access_profile_type.test(access_profile_type)) {
        res.status(403).send({
          success: 0,
          message:
            "SubAdmin access_profile_type validation failed: It should be 1 or 2",
        });
      }

      if (accessgroup_id == undefined) {
        return res.status(403).send({
          success: 0,
          message: "accessgroup is Mandatory",
        });
      }

      let get_accecgroup: any = await accessgroup.findById({
        _id: accessgroup_id,
      });

      if (accessgroup_id !== undefined && get_accecgroup == null) {
        res.status(403).send({
          success: 0,
          message:
            "SubAdmin accessgroup validation failed: It should be Exists on Database",
        });
      }

      if (user_status == undefined) {
        return res.status(403).send({
          success: 0,
          message: "user_status is Mandatory",
        });
      }

      if (!REGEXP.SUB_ADMIN.user_status.test(user_status)) {
        return res.status(403).send({
          success: 0,
          message: "SubAdmin user_status validation failed:It should be 0 or 1",
        });
      }

      if (user_name == undefined) {
        return res.status(403).send({
          success: 0,
          message: "user_name is Mandatory",
        });
      }

      if (!REGEXP.COMMON.LENGTH50.test(user_name)) {
        res.status(403).send({
          success: 0,
          message:
            "SubAdmin userName validation failed: Length should be between 1-50",
        });
      }

      if (name == undefined) {
        return res.status(403).send({
          success: 0,
          message: "name is Mandatory",
        });
      }

      if (!REGEXP.COMMON.LENGTH50.test(name)) {
        res.status(403).send({
          success: 0,
          message:
            "SubAdmin name validation failed: Length should be between 1-50",
        });
      }

      if (selected_Enterprise == undefined) {
        return res.status(403).send({
          success: 0,
          message: "selected_Enterprise is Mandatory",
        });
      }

      if (selected_Enterprise.length == 0) {
        return res.status(403).send({
          success: 0,
          message:
            "selected_Enterprise validation failed: selected_Enterprise Is Empty.",
        });
      }

      if (user_email == undefined) {
        return res.status(403).send({
          success: 0,
          message: "confirm_password is Mandatory",
        });
      }

      // if (!REGEXP.COMMON.EMAIL.test(user_email)) {
      //   res.status(403).send({
      //     success: 0,
      //     message:
      //       "user_email Validation Failed: user_email is require and it should be valid. Max char length is 254",
      //   });
      // }

      if (user_mobileNumber == undefined) {
        return res.status(403).send({
          success: 0,
          message: "confirm_password is Mandatory",
        });
      }

      // if (!REGEXP.SUB_ADMIN.PHONENUMBER.test(user_mobileNumber)) {
      //   res.status(403).send({
      //     success: 0,
      //     message:
      //       "user_mobileNumber Validation Failed: phoneNumber is require and it should be valid. Length range: [3,16]",
      //   });
      // }

      if (user_address == undefined) {
        return res.status(403).send({
          success: 0,
          message: "user_address is Mandatory",
        });
      }

      if (!REGEXP.SUB_ADMIN.user_address.test(user_address)) {
        res.status(403).send({
          success: 0,
          message:
            "user_address Validation Failed: phoneNumber is require and it should be valid. Length range: 1-350",
        });
      }

      let check_user_exists: any = await user_admin.findOne({
        name: name,
        user_type: 2,
        _id: { $ne: subAdmin_id },
        is_deleted:0
      });

      if (check_user_exists) {
        return res.status(409).send({
          success: 0,
          message:
            "Sub Admin Already Exists With This " + name + " User Name",
        });
      }

      let check_user_exists_email: any = await user_admin.findOne({
        user_email: user_email,
        user_type: { $ne: 1 },
        _id: { $ne: subAdmin_id },
        is_deleted:0
      });

      if (check_user_exists_email) {
        return res.status(409).send({
          success: 0,
          message: "Sub Admin Already Exists With This " + user_email + " Email",
        });
      }

      let files_detail:any= req?.files;
      let image_url:any = user_image;
      
      if(files_detail !== undefined &&files_detail.file && files_detail.file[0]?.path){
        let  myUrl = files_detail.file[0]?.path 
        myUrl = myUrl.replace("../uploads", "uploads");
        image_url =  myUrl
        }
      let sipDomain: any = "";

      let create_enterprise_nm: String = user_name + sipDomain.toString();

      let Subadmin_detail: any = await user_admin.findOneAndUpdate(
        {
          _id: subAdmin_id,
          is_deleted:0
        },
        {
          name: name,
          user_name: user_name,
          user_email: user_email,
          user_status: user_status,
          user_address: user_address,
          selected_Enterprise: selected_Enterprise,
          user_mobileNumber: user_mobileNumber,
          user_image: image_url,
          accessgroup: accessgroup_id,
          access_profile_type: access_profile_type,
          sipDomain: sipDomain,
          userName: create_enterprise_nm,
        },
        {
          new: true,
          runValidators: true,
        }
      );

      return res.status(201).send({
        success: 1,
        message: "SubAdmin Updated Successfully",
        SubAdmin_Detail: Subadmin_detail,
      });
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};
const removeSubAdminById = async (req: Request, res: Response, next: NextFunction) => {
    try {
        let subAdmin_id: any = req.params.subAdmin_id
        if (!mongoose.Types.ObjectId.isValid(subAdmin_id)) {
            return res.status(400).send({
                success:0,
                message: "Invalid ObjectId" 
            });
        }

        let get_group_detail: any = await user_admin.findOneAndUpdate({
            _id: subAdmin_id,
            is_deleted:0
        },{
          is_deleted:1
        })
        
        return res.status(201).send({
            success: 1,
            message: "Admin Deleted Successfully"
        })

    } catch (error) {
        res.status(500).send({
            success: 0,
            message: "Internal Server Error"
        })
    }
}

const updatePassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = req.body;
    console.log(data)
    const uid = data.uid;
    const user_password = data.user_password;

    console.log(uid,"uid")
    if(!mongoose.Types.ObjectId.isValid(uid)){
      return res.status(404).send({
        success: 0,
        message: "uid is Invalid",
      });
    }

    const companyDetail: any = await user_admin.findOne(
      {
        _id: uid,
        is_deleted: 0
      }
    );

    if (!companyDetail == null || companyDetail == undefined) {
      return res.status(404).send({
        success: 0,
        message: "user admin Not Found",
      });
    }

    await user_admin.findByIdAndUpdate({
      _id: companyDetail._id
    }, {
      user_password:user_password
    }
    )

   return res.status(200).send({
      success: 1,
      message: "Sub-admin Password Updated successfully",
    });

  } catch (error) {
    console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};

export default {
    AllSubAdminList,
    createSubAdmin,
    getSubAdminDetailByID,
    EditAdminDetailByID,
    removeSubAdminById,
    updatePassword
}
