import { NextFunction, Request, Response } from "express";
import get_token from "../../helper/userHeader";
import User_token from "../../helper/helper";
import call_history from "../../models/call_history";
import mongoose from "mongoose";
import { emitHandler } from "../../socket";
import User_token_admin from "../../helper/helper_admin";
import user_admin from "../../models/user_admin";

const getCallHistory = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    const uid: any = user_detail?.uid;
    const eid: any = user_detail?.eid;
    const struid = uid.toString();
    const uid_object: any = new mongoose.Types.ObjectId(uid);

    // Pagination setup
    const body = req.body;
    let page: number = parseInt(body.page) || 1;
    let size: number = parseInt(body.size) || 50;
    const skip = (page - 1) * size;
    let search: any = body.search?.toString();

    // Total count of matching records
    const countResult = await call_history.aggregate([
      {
        $match: {
          $or: [{ reciver_id: { $in: [uid] } }, { caller_id: uid_object }],
        },
      },
      { $count: "total_count" },
    ]);
    const total_count = countResult[0]?.total_count || 0;
    const total_page_count = Math.ceil(total_count / size);

    // Data with aggregation and pagination
    const callHistory = await call_history.aggregate([
      {
        $match: {
          $or: [{ reciver_id: { $in: [uid] } }, { caller_id: uid_object }],
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "caller_id",
          foreignField: "_id",
          as: "caller_details",
        },
      },
      {
        $unwind: {
          path: "$caller_details",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "reciver_id",
          foreignField: "_id",
          as: "reciver_detail",
        },
      },
      // {
      //   $lookup: {
      //     from: "users",
      //     localField: "joined_users.participant_id",
      //     foreignField: "_id",
      //     as: "joined_user_data",
      //   },
      // },
      // {
      //   $unwind: {
      //     path: "$joined_user_data",
      //     preserveNullAndEmptyArrays: true,
      //   },
      // },
      {
        $lookup: {
          from: "users",
          localField: "joined_users.participant_id",
          foreignField: "_id",
          as: "joined_user_data",
        },
      },
      {
        $addFields: {
          joined_users: {
            $map: {
              input: "$joined_users",
              as: "ju",
              in: {
                $mergeObjects: [
                  "$$ju",
                  {
                    $let: {
                      vars: {
                        matchedUser: {
                          $arrayElemAt: [
                            {
                              $filter: {
                                input: "$joined_user_data",
                                as: "ud",
                                cond: {
                                  $eq: [
                                    "$$ud._id",
                                    {
                                      $toObjectId: "$$ju.participant_id",
                                    },
                                  ],
                                },
                              },
                            },
                            0,
                          ],
                        },
                      },
                      in: {
                        name: {
                          $concat: [
                            { $ifNull: ["$$matchedUser.first_name", ""] },
                            " ",
                            { $ifNull: ["$$matchedUser.last_name", ""] },
                          ],
                        },
                        user_image: "$$matchedUser.user_image",
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      },
      {
        $lookup: {
          from: "groups",
          localField: "group_id",
          foreignField: "_id",
          as: "group_details",
        },
      },
      {
        $unwind: {
          path: "$group_details",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $addFields: {
          reciver_details: {
            $map: {
              input: "$reciver_detail",
              as: "u",
              in: {
                _id: "$$u._id",
                user_name: "$$u.user_name",
                user_profile: "$$u.user_image",
                first_name: "$$u.first_name",
                last_name: "$$u.last_name",
              },
            },
          },
          caller_detail: {
            _id: "$caller_details._id",
            user_name: "$caller_details.user_name",
            user_profile: "$caller_details.user_image",
            first_name: "$caller_details.first_name",
            last_name: "$caller_details.last_name",
          },
          group_detail: {
            _id: "$group_details._id",
            group_name: "$group_details.group_name",
            description: "$group_details.description",
            group_image:"$group_details.group_image"
          },
        },
      },
      {
        $addFields: {
          call_direction: {
            $cond: {
              if: { $eq: ["$caller_id", uid] },
              then: "Outgoing",
              else: {
                $cond: {
                  if: {
                    $in: [uid, "$joined_users.participant_id"],
                  },
                  then: "Incoming",
                  else: "Missed",
                },
              },
            },
          },
          join_time: {
            $arrayElemAt: [
              {
                $map: {
                  input: {
                    $filter: {
                      input: "$joined_users",
                      as: "ju",
                      cond: { $eq: ["$$ju.participant_id", struid] },
                    },
                  },
                  as: "filtered",
                  in: "$$filtered.date-time",
                },
              },
              0,
            ],
          },
          leave_time: {
            $arrayElemAt: [
              {
                $map: {
                  input: {
                    $filter: {
                      input: "$leave_users",
                      as: "lu",
                      cond: { $eq: ["$$lu.participant_id", struid] },
                    },
                  },
                  as: "filtered",
                  in: "$$filtered.date-time",
                },
              },
              0,
            ],
          },
        },
      },
      {
        $addFields: {
          duration_in_sec: {
            $dateDiff: {
              startDate: { $toDate: "$join_time" },
              endDate: { $toDate: "$leave_time" },
              unit: "second",
            },
          },
        },
      },
      {
        $addFields: {
          duration: "$call_Duration",
        },
      },
      {
        $addFields: {
          duration: {
            $cond: {
              if: { $eq: ["$call_direction", "Missed"] },
              then: "00:00:00",
              else: "$call_Duration",
            },
          },
        },
      },

      //  {
      //   $addFields: {
      //     "joined_users.name": {
      //       $concat: [
      //         { $ifNull: ["$joined_user_data.first_name", ""] },
      //         " ",
      //         { $ifNull: ["$joined_user_data.last_name", ""] },
      //       ],
      //     },
      //     "joined_users.user_image": "$joined_user_data.user_image",
      //   },
      // },
      {
        $match: {
          $or: [
            {
              "reciver_details.first_name": {
                $regex: search,
                $options: "i",
              },
            },
            {
              "reciver_details.last_name": {
                $regex: search,
                $options: "i",
              },
            },
            {
              "caller_detail.first_name": {
                $regex: search,
                $options: "i",
              },
            },
            {
              $or: [
                {
                  "group_detail.group_name": {
                    $regex: search,
                    $options: "i",
                  },
                },
                {
                  group_detail: { $exists: false },
                },
              ],
            },
            {
              "caller_detail.last_name": {
                $regex: search,
                $options: "i",
              },
            },
            {
              "enterprise_details.enterprise_name": {
                $regex: search,
                $options: "i",
              },
            },
          ],
        },
      },
      {
        $facet: {
          meta: [
            { $count: "total" },
            {
              $addFields: {
                page: page,
                size: size,
                totalPages: {
                  $ceil: {
                    $divide: ["$total", size],
                  },
                },
              },
            },
          ],
          data: [
            {
              $project: {
                caller_details: 0,
                reciver_detail: 0,
                join_time: 0,
                leave_time: 0,
                duration_in_sec: 0,
                joined_user_data: 0,
                leave_users: 0,
                ongoing_users: 0,
                isCallEnded: 0,
                call_Duration: 0,
                call_deleted_users: 0,
                call_start_time: 0,
                call_end_time: 0,
                group_details: 0,
              },
            },
            { $sort: { createdAt: -1 } },
            { $skip: skip },
            { $limit: size },
          ],
        },
      },
      {
        $unwind: "$meta",
      },
      {
        $project: {
          data: 1,
          total: "$meta.total",
          page: "$meta.page",
          size: "$meta.size",
          totalPages: "$meta.totalPages",
        },
      },
    ]);

    res.status(200).send({
      success: 1,
      message: "Call history fetched successfully",
      page: callHistory.length > 0 ? callHistory[0].page : page,
      size: callHistory.length > 0 ? callHistory[0].size : size,
      total_count: callHistory.length > 0 ? callHistory[0].total : 0,
      total_page_count: callHistory.length > 0 ? callHistory[0].totalPages : 0,
      data: callHistory.length > 0 ? callHistory[0].data : [],
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};

const getCallHistoryAll = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token_admin(token);

    const body = req.body;
    const page: number = parseInt(body.page) || 1;
    const size: number = parseInt(body.size) || 10;
    const skip = (page - 1) * size;
    const search = body.search?.trim();
    const startDate = body.startDate ? new Date(body.startDate) : null;
    const endDate = body.endDate ? new Date(body.endDate) : null;
    let eid = body.eid;
    if(eid == null || eid == undefined){
      eid = user_detail?.eid
      if(eid == null || eid == undefined){
        const user_token_data:any = await user_admin.findOne({
          _id : user_detail?.uid
        })
        eid = user_token_data?.eid
      } 
    }
    const matchFilter: any = {};
    if (startDate && endDate) {
      matchFilter.createdAt = { $gte: startDate, $lte: endDate };
    }
    if (eid) {
      matchFilter.cid = new mongoose.Types.ObjectId(eid);
    }

    const baseAggregation: any[] = [
      { $match: matchFilter },

      // Lookup caller
      {
        $lookup: {
          from: "users",
          localField: "caller_id",
          foreignField: "_id",
          as: "caller_details",
        },
      },
      {
        $unwind: { path: "$caller_details", preserveNullAndEmptyArrays: true },
      },

      // Lookup receiver
      {
        $lookup: {
          from: "users",
          localField: "reciver_id",
          foreignField: "_id",
          as: "reciver_detail",
        },
      },

      // Lookup enterprise
      {
        $lookup: {
          from: "enterprises",
          localField: "cid",
          foreignField: "_id",
          as: "enterprise_detail",
        },
      },
      {
        $unwind: {
          path: "$enterprise_detail",
          preserveNullAndEmptyArrays: true,
        },
      },

      // Lookup group
      {
        $lookup: {
          from: "groups",
          localField: "group_id",
          foreignField: "_id",
          as: "group_details",
        },
      },
      { $unwind: { path: "$group_details", preserveNullAndEmptyArrays: true } },

      // Flatten joined_users, lookup names and images, then group back
      { $unwind: { path: "$joined_users", preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: "users",
          localField: "joined_users.participant_id",
          foreignField: "_id",
          as: "joined_user_data",
        },
      },
      {
        $unwind: {
          path: "$joined_user_data",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $addFields: {
          "joined_users.name": {
            $concat: [
              { $ifNull: ["$joined_user_data.first_name", ""] },
              " ",
              { $ifNull: ["$joined_user_data.last_name", ""] },
            ],
          },
          "joined_users.user_image": "$joined_user_data.user_image",
        },
      },
      {
        $group: {
          _id: "$_id",
          doc: { $first: "$$ROOT" },
          joined_users: { $push: "$joined_users" },
        },
      },
      {
        $replaceRoot: {
          newRoot: {
            $mergeObjects: ["$doc", { joined_users: "$joined_users" }],
          },
        },
      },

      // Format
      {
        $addFields: {
          reciver_details: {
            $map: {
              input: "$reciver_detail",
              as: "u",
              in: {
                _id: "$$u._id",
                user_name: "$$u.user_name",
                user_profile: "$$u.user_image",
                first_name: "$$u.first_name",
                last_name: "$$u.last_name",
              },
            },
          },
          caller_detail: {
            _id: "$caller_details._id",
            user_name: "$caller_details.user_name",
            user_profile: "$caller_details.user_image",
            first_name: "$caller_details.first_name",
            last_name: "$caller_details.last_name",
          },
          group_detail: {
            _id: "$group_details._id",
            group_name: "$group_details.group_name",
            description: "$group_details.description",
          },
          enterprise_details: {
            _id: "$enterprise_detail._id",
            enterprise_name: "$enterprise_detail.enterprise_name",
            Logo: "$enterprise_detail.Logo",
          },
          duration: "$call_Duration",
        },
      },
    ];

    if (search) {
      baseAggregation.push({
        $match: {
          $or: [
            { "caller_detail.first_name": { $regex: search, $options: "i" } },
            { "caller_detail.last_name": { $regex: search, $options: "i" } },
            { "joined_users.name": { $regex: search, $options: "i" } },
            { "group_details.group_name": { $regex: search, $options: "i" } },
            {
              "enterprise_details.enterprise_name": {
                $regex: search,
                $options: "i",
              },
            },
          ],
        },
      });
    }

    const countAggregation = [...baseAggregation, { $count: "total_count" }];
    const countResult = await call_history.aggregate(countAggregation);
    const total_count = countResult[0]?.total_count || 0;
    const total_page_count = Math.ceil(total_count / size);

    baseAggregation.push(
      { $sort: { createdAt: -1 } },
      { $skip: skip },
      { $limit: size }
    );

    baseAggregation.push({
      $project: {
        caller_details: 0,
        reciver_detail: 0,
        enterprise_detail: 0,
        joined_user_data: 0,
        leave_users: 0,
        ongoing_users: 0,
        isCallEnded: 0,
        call_Duration: 0,
        call_deleted_users: 0,
        call_end_time: 0,
        reciver_id: 0,
        group_id: 0,
        cid: 0,
        caller_id: 0,
        group_details: 0,
      },
    });

    const callHistory = await call_history.aggregate(baseAggregation);

    res.status(200).send({
      success: 1,
      message: "Call history fetched successfully",
      page,
      size,
      total_count,
      total_page_count,
      data: callHistory,
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};

const callRejectByUser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    const uid: any = user_detail?.uid;

    let data: any = req.body;
    let room_id: any = data.room_id;

    let updated_call_detail: any = await call_history.findOne({
      room_id: room_id,
    });

    let total_call_users: any = updated_call_detail.reciver_id;
    let reject_call_users: any = updated_call_detail.reject_users;
    let not_rejected_users = total_call_users.filter(
      (user: any) => !reject_call_users.includes(user)
    );
    let not_rejected_count = not_rejected_users.length;

    if (not_rejected_count == 1) {
      await emitHandler("incoming_call_reject", {
        uid: updated_call_detail.caller_id,
        room_id: room_id,
      });
    }
    await call_history.findOneAndUpdate(
      {
        room_id: room_id,
      },
      {
        $push: { reject_users: uid },
      },
      {
        new: true,
      }
    );
    return res.status(200).send({
      success: 1,
      message: "Call history fetched successfully",
    });
  } catch (error) {
    console.log("error", error);
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};

export default { getCallHistory, getCallHistoryAll, callRejectByUser };
