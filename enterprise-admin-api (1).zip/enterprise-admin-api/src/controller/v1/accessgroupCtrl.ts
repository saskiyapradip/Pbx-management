import { Request, Response, NextFunction } from "express";
import accessgroup from "../../models/accessgroup";
import mongoose from "mongoose";
import user_admin from "../../models/user_admin";
import User_token_admin from "../../helper/helper_admin";
import get_token from "../../helper/userHeader";
import REGEXP from "../../regexp";

const AllAccessGroupList = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let page: any = req.query.page;
    let size: any = req.query.size;
    if (!page) page = 1;
    if (!size) size = 50;

    let search: any = req.query.search?.toString();
    let tmp_filter: any = req.query.filter;
    let filter: any = parseInt(tmp_filter);
    let find_query: any;
    if (search) {
      find_query = {
        $or: [
          {
            name: {
              $regex: search,
              $options: "i",
            },
          },
        ],
        is_deleted: 0,
      };
    } else {
      find_query = {
        is_deleted: 0,
      };
    }

    if (filter == 1) {
      find_query.profile_type = 1;
    }
    if (filter == 2) {
      find_query.profile_type = 2;
    }

    let limit: any = parseInt(size);
    let skip: any = (page - 1) * size;

    let accessgroup_detail: any[] = await accessgroup
      .aggregate([
        {
          $match: find_query,
        },
        {
          $sort: {
            createdAt: -1,
          },
        },
        {
          $project: {
            _id: 1,
            name: 1,
            profile_type: 1,
          },
        },
      ])
      .skip(skip)
      .limit(limit);

    let accessgroup_detail_count: any = await accessgroup.find(find_query).countDocuments();

    let total_page_count: any = Math.ceil(accessgroup_detail_count / size);

    res.status(200).send({
      success: 1,
      message: "Accessgroup List",
      Accecssgroup_list: accessgroup_detail,
      total_groups_count: accessgroup_detail_count,
      total_page_count,
    });
  } catch (error: any) {
    res.status(500).send({
      success: 0,
      message:"Internal Server Error" 
    });
  }
};
const AccessGroupList = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let accessgroup_list: any = await accessgroup
      .find({
        is_deleted: 0,
      })
      .select("name profile_type");

    return res.status(200).send({
      success: 1,
      message: "Group List",
      Accessgroup_detail: accessgroup_list,
    });
  } catch (error:any) {
    res.status(500).send({
      success: 0,
      messsage: "Internal Server Error" 
    })

  }
};
const createAccessGroup = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token_admin(token);

    let eid: any = user_detail?.eid;
    let data: any = req.body;
    let name: any = data.name;
    let profile_type: any = data.profile_type;
    let dashboard_view: any = data.dashboard_view;
    let enterprise_create: any = data.enterprise_create;
    let enterprise_update: any = data.enterprise_update;
    let enterprise_delete: any = data.enterprise_delete;
    let enterprise_view: any = data.enterprise_view;
    let subscriber_create: any = data.subscriber_create;
    let subscriber_update: any = data.subscriber_update;
    let subscriber_delete: any = data.subscriber_delete;
    let subscriber_view: any = data.subscriber_view;
    let add_admin_create: any = data.add_admin_create;
    let add_admin_update: any = data.add_admin_update;
    let add_admin_delete: any = data.add_admin_delete;
    let add_admin_view: any = data.add_admin_view;
    let add_role_create: any = data.add_role_create;
    let add_role_update: any = data.add_role_update;
    let add_role_delete: any = data.add_role_delete;
    let add_role_view: any = data.add_role_view;
    let cdr_view: any = data.cdr_view;

    if (!name && !REGEXP.ACCESSGROUP.NAME.test(name)) {
      return res.status(403).send({
        success: 0,
        message: "name Validation Failed: name is require and it should be valid",
      });
    }

    if (profile_type === undefined || !REGEXP.ACCESSGROUP.PROFILE_TYPE.test(profile_type)) {
      return res.status(403).send({
        success: 0,
        message: "profile_type Validation Failed: profile_type is require and it should be 1 or 2",
      });
    }

    if (dashboard_view === undefined || !REGEXP.COMMON.BOOLEAN.test(dashboard_view)) {
      return res.status(403).send({
        success: 0,
        message:
          "dashboard_view Validation Failed: dashboard_view is require and it should be 0 or 1",
      });
    }


    if (enterprise_create === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_create)) {
      return res.status(403).send({
        success: 0,
        message:
          "enterprise_create Validation Failed: enterprise_create is require and it should be 0 or 1",
      });
    }

    if (enterprise_update === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_update)) {
      return res.status(403).send({
        success: 0,
        message:
          "enterprise_update Validation Failed: enterprise_update is require and it should be 0 or 1",
      });
    }

    if (enterprise_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_delete)) {
      return res.status(403).send({
        success: 0,
        message:
          "enterprise_delete Validation Failed: enterprise_delete is require and it should be 0 or 1",
      });
    }
    if (enterprise_view === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_view)) {
      return res.status(403).send({
        success: 0,
        message:
          "enterprise_view Validation Failed: enterprise_view is require and it should be 0 or 1",
      });
    }
    if (subscriber_create === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_create)) {
      res.status(403).send({
        success: 0,
        message:
          "subscriber_create Validation Failed: subscriber_create is require and it should be 0 or 1",
      });
    }
    if (subscriber_update === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_update)) {
      return res.status(403).send({
        success: 0,
        message:
          "subscriber_update Validation Failed: subscriber_update is require and it should be 0 or 1",
      });
    }
    if (subscriber_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_delete)) {
      return res.status(403).send({
        success: 0,
        message:
          "subscriber_delete Validation Failed: subscriber_delete is require and it should be 0 or 1",
      });
    }
    if (subscriber_view === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_view)) {
      return res.status(403).send({
        success: 0,
        message:
          "subscriber_view Validation Failed: subscriber_view is require and it should be 0 or 1",
      });
    }
    if (add_admin_create === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_create)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_create Validation Failed: add_admin_create is require and it should be 0 or 1",
      });
    }
    if (add_admin_update === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_update)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_update Validation Failed: add_admin_update is require and it should be 0 or 1",
      });
    }
    if (add_admin_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_delete)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_delete Validation Failed: add_admin_delete is require and it should be 0 or 1",
      });
    }
    if (add_admin_view === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_view)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_view Validation Failed: add_admin_view is require and it should be 0 or 1",
      });
    }
    if (add_role_create === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_create)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_create Validation Failed: add_role_create is require and it should be 0 or 1",
      });
    }
    if (add_role_update === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_update)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_update Validation Failed: add_role_update is require and it should be 0 or 1",
      });
    }
    if (add_role_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_delete)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_delete Validation Failed: add_role_delete is require and it should be 0 or 1",
      });
    }
    if (add_role_view === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_view)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_view Validation Failed: add_role_view is require and it should be 0 or 1",
      });
    }
    if (cdr_view === undefined || !REGEXP.COMMON.BOOLEAN.test(cdr_view)) {
     return res.status(403).send({
        success: 0,
        message: "cdr_view Validation Failed: cdr_view is require and it should be 0 or 1",
      });
    }
    
    

    let check_hroup_detail: any = await accessgroup.findOne({
      name: name,
      is_deleted: 0,
    });

    if (check_hroup_detail) {
     return res.status(402).send({
        success: 0,
        message: "Access Group " + name + " Already Exists",
      });
    }

    let add_accessgroup: any = new accessgroup();
    add_accessgroup.eid = eid;
    add_accessgroup.name = name;
    add_accessgroup.profile_type = profile_type;
    add_accessgroup.dashboard_view = dashboard_view;
    add_accessgroup.enterprise_create = enterprise_create;
    add_accessgroup.enterprise_update = enterprise_update;
    add_accessgroup.enterprise_delete = enterprise_delete;
    add_accessgroup.enterprise_view = enterprise_view;
    add_accessgroup.subscriber_create = subscriber_create;
    add_accessgroup.subscriber_update = subscriber_update;
    add_accessgroup.subscriber_delete = subscriber_delete;
    add_accessgroup.subscriber_view = subscriber_view;
    add_accessgroup.add_admin_create = add_admin_create;
    add_accessgroup.add_admin_update = add_admin_update;
    add_accessgroup.add_admin_delete = add_admin_delete;
    add_accessgroup.add_admin_view = add_admin_view;
    add_accessgroup.add_role_create = add_role_create;
    add_accessgroup.add_role_update = add_role_update;
    add_accessgroup.add_role_delete = add_role_delete;
    add_accessgroup.add_role_view = add_role_view;
    add_accessgroup.cdr_view = cdr_view;
    await add_accessgroup.save();

    return res.status(201).send({
      success: 1,
      message: "Group Created Successfully",
      Group_detail: add_accessgroup,
    });
  } catch (error) {
    //console.log("error",error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error" 
    })
  }
 
};
const getGroupDetailByID = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let group_id: any = req.params.group_id;
    if (!mongoose.Types.ObjectId.isValid(group_id)) {
      return res.status(400).send({
        success: 0,
        message: "Invalid ObjectId",
      });
    }

    let get_group_detail: any = await accessgroup.findById({
      _id: group_id,
    });

    return res.status(201).send({
      success:1,
      message:"Group Detail",
      Group_detail:get_group_detail
    })

  } catch (error:any) {
   return res.status(500).send({
      success: 0,
      message: "Internal Server Error" 
    })
  }
};
const EditGroupDetailByID = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let group_id: any = req.params.group_id;
    if (!mongoose.Types.ObjectId.isValid(group_id)) {
      return res.status(400).send({
        success: 0,
        message: "Invalid ObjectId",
      });
    }

    let get_group_details: any = await accessgroup.findById({
      _id: group_id,
    });

    if (!get_group_details) {
      return res.status(404).send({
        success: 0,
        message: "Group Not Exists",
      });
    }

    let data: any = req.body;
    let name: any = data.name;
    let profile_type: any = data.profile_type;
    let dashboard_view: any = data.dashboard_view;
    let enterprise_create: any = data.enterprise_create;
    let enterprise_update: any = data.enterprise_update;
    let enterprise_delete: any = data.enterprise_delete;
    let enterprise_view: any = data.enterprise_view;
    let subscriber_create: any = data.subscriber_create;
    let subscriber_update: any = data.subscriber_update;
    let subscriber_delete: any = data.subscriber_delete;
    let subscriber_view: any = data.subscriber_view;
    let add_admin_create: any = data.add_admin_create;
    let add_admin_update: any = data.add_admin_update;
    let add_admin_delete: any = data.add_admin_delete;
    let add_admin_view: any = data.add_admin_view;
    let add_role_create: any = data.add_role_create;
    let add_role_update: any = data.add_role_update;
    let add_role_delete: any = data.add_role_delete;
    let add_role_view: any = data.add_role_view;
    let cdr_view: any = data.cdr_view;

    if (!name && !REGEXP.ACCESSGROUP.NAME.test(name)) {
     return res.status(403).send({
        success: 0,
        message: "name Validation Failed: name is require and it should be valid",
      });
    }

    if (profile_type === undefined || !REGEXP.ACCESSGROUP.PROFILE_TYPE.test(profile_type)) {
     return res.status(403).send({
        success: 0,
        message: "profile_type Validation Failed: profile_type is require and it should be 1 or 2",
      });
    }

    if (dashboard_view === undefined || !REGEXP.COMMON.BOOLEAN.test(dashboard_view)) {
     return res.status(403).send({
        success: 0,
        message:
          "dashboard_view Validation Failed: dashboard_view is require and it should be 0 or 1",
      });
    }

    if (enterprise_create === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_create)) {
     return res.status(403).send({
        success: 0,
        message:
          "enterprise_create Validation Failed: enterprise_create is require and it should be 0 or 1",
      });
    }

    if (enterprise_update === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_update)) {
     return res.status(403).send({
        success: 0,
        message:
          "enterprise_update Validation Failed: enterprise_update is require and it should be 0 or 1",
      });
    }

    if (enterprise_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_delete)) {
     return res.status(403).send({
        success: 0,
        message:
          "enterprise_delete Validation Failed: enterprise_delete is require and it should be 0 or 1",
      });
    }
    if (enterprise_view === undefined || !REGEXP.COMMON.BOOLEAN.test(enterprise_view)) {
     return res.status(403).send({
        success: 0,
        message:
          "enterprise_view Validation Failed: enterprise_view is require and it should be 0 or 1",
      });
    }
    if (subscriber_create === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_create)) {
     return res.status(403).send({
        success: 0,
        message:
          "subscriber_create Validation Failed: subscriber_create is require and it should be 0 or 1",
      });
    }
    if (subscriber_update === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_update)) {
     return res.status(403).send({
        success: 0,
        message:
          "subscriber_update Validation Failed: subscriber_update is require and it should be 0 or 1",
      });
    }
    if (subscriber_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_delete)) {
     return res.status(403).send({
        success: 0,
        message:
          "subscriber_delete Validation Failed: subscriber_delete is require and it should be 0 or 1",
      });
    }
    if (subscriber_view === undefined || !REGEXP.COMMON.BOOLEAN.test(subscriber_view)) {
     return res.status(403).send({
        success: 0,
        message:
          "subscriber_view Validation Failed: subscriber_view is require and it should be 0 or 1",
      });
    }
    if (add_admin_create === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_create)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_create Validation Failed: add_admin_create is require and it should be 0 or 1",
      });
    }
    if (add_admin_update === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_update)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_update Validation Failed: add_admin_update is require and it should be 0 or 1",
      });
    }
    if (add_admin_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_delete)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_delete Validation Failed: add_admin_delete is require and it should be 0 or 1",
      });
    }
    if (add_admin_view === undefined || !REGEXP.COMMON.BOOLEAN.test(add_admin_view)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_admin_view Validation Failed: add_admin_view is require and it should be 0 or 1",
      });
    }
    if (add_role_create === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_create)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_create Validation Failed: add_role_create is require and it should be 0 or 1",
      });
    }
    if (add_role_update === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_update)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_update Validation Failed: add_role_update is require and it should be 0 or 1",
      });
    }
    if (add_role_delete === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_delete)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_delete Validation Failed: add_role_delete is require and it should be 0 or 1",
      });
    }
    if (add_role_view === undefined || !REGEXP.COMMON.BOOLEAN.test(add_role_view)) {
     return res.status(403).send({
        success: 0,
        message:
          "add_role_view Validation Failed: add_role_view is require and it should be 0 or 1",
      });
    }
    if (cdr_view === undefined || !REGEXP.COMMON.BOOLEAN.test(cdr_view)) {
     return res.status(403).send({
        success: 0,
        message: "cdr_view Validation Failed: cdr_view is require and it should be 0 or 1",
      });
    }
   
      let check_hroup_detail: any = await accessgroup.findOne({
        name: name,
        is_deleted: 0,
        _id: { $ne: group_id },
      });

      if (check_hroup_detail) {
        return res.status(402).send({
          success: 0,
          message: "Access Group " + name + " Already Exists",
        });
      }

      let get_group_detail: any = await accessgroup.findByIdAndUpdate(
        {
          _id: group_id,
        },
        {
          name: name,
          profile_type: profile_type,
          dashboard_view: dashboard_view,
          enterprise_create: enterprise_create,
          enterprise_update: enterprise_update,
          enterprise_delete: enterprise_delete,
          enterprise_view: enterprise_view,
          subscriber_create: subscriber_create,
          subscriber_update: subscriber_update,
          subscriber_delete: subscriber_delete,
          subscriber_view: subscriber_view,
          add_admin_create: add_admin_create,
          add_admin_update: add_admin_update,
          add_admin_delete: add_admin_delete,
          add_admin_view: add_admin_view,
          add_role_create: add_role_create,
          add_role_update: add_role_update,
          add_role_delete: add_role_delete,
          add_role_view: add_role_view,
          cdr_view: cdr_view
        },
        {
          new: true,
          runValidators: true,
        }
      );

      return res.status(201).send({
        success: 1,
        message: "Group Detail Updated Successfully",
        Group_detail: get_group_detail,
      });
    
  } catch (error) {
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });

  }
};
const removeGroupById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let group_id: any = req.params.group_id;
    if (!mongoose.Types.ObjectId.isValid(group_id)) {
      return res.status(400).send({
        success: 0,
        message: "Invalid ObjectId",
      });
    }

    let getgroup_details: any = await accessgroup.findOne({
      _id: group_id,
      is_deleted: 0,
    });

    if (!getgroup_details) {
      return res.status(402).send({
        success: 0,
        message: "Access Group Not Exists",
      });
    }

    let check_group_admins: any = await user_admin.findOne({
      accessgroup: group_id,
      is_deleted: 0,
    });
    if (check_group_admins) {
      return res.status(402).send({
        success: 0,
        message:
          "Access Group " +
          getgroup_details.name +
          " cannot be deleted because it is associated with one of the staff",
      });
    }
    let get_group_detail: any = await accessgroup.findByIdAndUpdate(
      {
        _id: group_id,
      },
      {
        is_deleted: 1,
      },
      {
        new: true,
      }
    );

    return res.status(201).send({
      success: 1,
      message: "Group Deleted Successfully",
      Group_detail: get_group_detail,
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};
export default {
  AllAccessGroupList,
  AccessGroupList,
  createAccessGroup,
  getGroupDetailByID,
  EditGroupDetailByID,
  removeGroupById,
};
