import { MESSAGE } from "../../constant";
import { Request, Response, NextFunction } from "express";
import sharp from "sharp";
import Ffmpeg from "fluent-ffmpeg";
import ffmpegPath from "@ffmpeg-installer/ffmpeg";
import upload from "../../newUploadApp";
import multer from 'multer';
import path from 'path'
import fs from 'fs'
import file_data from "../../models/file_data";
import User_token from "../../helper/helper";
import { config } from "../../config";
import jwt, { JwtPayload } from "jsonwebtoken";
import { fileURLToPath } from "url";
import user from "../../models/user";
import user_tokens from "../../models/user_tokens";
import { fileTypeFromFile, FileTypeResult } from "file-type";
import mongoose from "mongoose";

let new_fs_path: any = ffmpegPath.path;
Ffmpeg.setFfmpegPath(new_fs_path)

interface Media {
  id: string;
  filename: string;
}
const mediaDB: Media[] = []; // replace with real DB

const UPLOAD_DIR = path.join(__dirname, "..", "uploads");

// Extend JWT Payload type for file
interface FileJwtPayload extends JwtPayload {
  file: string;
}

const ALLOWED: Record<string, string[]> = {
  "image/jpeg": ["jpg", "jpeg", "jfif"],
  "image/png": ["png"],
  "audio/mpeg": ["mp3", "mpeg"],
  "video/mp4": ["mp4"],
  "application/pdf": ["pdf"],
  "audio/aac": ["aac"],
  "application/msword": ["doc"],
};


const NewuploadFile = async (req: Request, res: Response) => {
  try {
    upload(req, res, async (error:any) => {
            if (error) {
                console.log("error",error)
                if(error instanceof multer.MulterError){
                    res.status(500).send({
                        message: error.message
                    })
                }else{
                    res.status(500).send({
                        message: "file Format not Allowed"
                    })
                }
            } else {
            if (req?.file) {

              const filePath = req.file.path;
              const detectedType: FileTypeResult | undefined =
                await fileTypeFromFile(filePath);
              if (!detectedType) {
                fs.unlinkSync(filePath);
                return res.status(400).send({
                  success: 0,
                  message: "File extension does not match content",
                });
              }

                console.log("req.file", req.file)
                let myUrl = req.file.path
                let get_file_name: any = req.file.filename
                let fileuplodaddata:any
        let mimetype:any = req.file.mimetype


                // let name: any = get_file_name[3]
                let name_split: any = get_file_name.split(".")
                // let name_split: any = name.split(".")
                let final_name: any = name_split[0]
                // let folder_nm: any = get_file_name[2]
                // let thumbnail_nm = path.join(__dirname,'..','..','..','..','uploads', folder_nm, 'thumbnails__' + final_name + '.png');
                console.log(final_name,"finalname")
                let thumbnail_nm = path.join(__dirname,'..','..','..','..','uploads', 'thumbnails__' + final_name + '.png');
                try {
          const fileDoc = new file_data({
            file_name: req.file.originalname,
            file_manage_name: req.file.filename,
            size: req.file.size,
            mimetype: req.file.mimetype,
          });
          fileuplodaddata = await fileDoc.save();
          const dir = path.dirname(thumbnail_nm);
          if (!fs.existsSync(dir)) {
            console.log("file path not found");
          }
          console.log("Directory check passed:", dir);
        } catch (err) {
          console.error("Error creating directory:", err);
        }
                if (req.file.mimetype.includes("image/")) {
                    sharp.cache({ files: 0 })
                    const data = await sharp(myUrl)
                    data.rotate() 
                    data.metadata()
                        .then(function (metadata: any) {
                            return data
                                .toFormat('png', { palette: true })
                                .resize(Math.round(metadata?.width / (metadata?.width * 0.01)))
                                .toFile(thumbnail_nm)
                        }).catch(function (err:any) {
                            console.error('Error processing image:', err);
                          });
                }
                if (req.file.mimetype.includes("video/")) {
                    let viedio_file_nm: any = 'thumbnails__' + final_name + '.png';
                    let foleder_path: any = '../uploads/';
                    console.log("viedio upoaded", viedio_file_nm)
                    console.log("myUrl", myUrl)
                    console.log("foleder_path", foleder_path)
                    Ffmpeg(myUrl).screenshots({
                        timestamps: [0],
                        filename: viedio_file_nm,
                        folder: foleder_path,
                        size: '100x100'
                    }).on("progress", function (progress: any) {
                        console.log("Processing: " + progress.percent + "% done");
                    })
                        .on("error", function (err) {
                            console.log("An error occurred: " + err.message);
                        })
                        .on("end", function () {
                            console.log("Processing finished !");
                        })
                }
                // myUrl = myUrl.replace("../uploads", "uploads");
                // var mimetype = req.file.mimetype.includes("image/") ? MESSAGE.MESSAGE_MEDIA_TYPES.IMAGE :
                // 	req.file.mimetype.includes("video/") ? MESSAGE.MESSAGE_MEDIA_TYPES.VIDEO :
                // 		req.file.mimetype.includes("audio/") ? MESSAGE.MESSAGE_MEDIA_TYPES.AUDIO :
                // 			MESSAGE.MESSAGE_MEDIA_TYPES.DOCUMENTS

                const ResFileName = fileuplodaddata._id + "." + name_split[1];
                thumbnail_nm = thumbnail_nm.replace("../uploads", "uploads");
                res.send({
                    success: 1,
                    message: "Upload File Successfully",
                    // id:fileuplodaddata._id
                    originalName:req.file.originalname,
                    filename:ResFileName
                })
            }else {
                res.send({
                    success: 0,
                    message: "File not found"
                })
            }
            } 
    })
  } catch (error) {
    res.status(500).json({ success: 0, message: "Internal server error" });
  }
}

const getBlobFile = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data: any = req.query;
    let token = req.headers["authorization"] as string | undefined;

    // Token handling
    if (!token && req.query.token) {
      token = String(req.query.token);
    }

    if (!token) {
      return res.status(401).json({
        success: 0,
        message: "Token is missing",
      });
    }

    // Authentication and authorization
    let decoded: any;
    try {
      decoded = jwt.verify(token, config.key.secret_key);
    } catch (err) {
      return res.status(401).json({
        success: 2,
        message: "Session expired",
      });
    }

    const [userLoginDeviceCheck, userTokenCheck] = await Promise.all([
      user_tokens.find({ uid: decoded?.uid }),
      user_tokens.findOne({ token: token })
    ]);

    if (userLoginDeviceCheck.length === 0) {
      return res.status(401).json({
        success: 2,
        message: "Your Account Detail Has Been Updated By Admin, Please Register Again",
      });
    }

    if (!userTokenCheck) {
      return res.status(401).json({
        success: 2,
        message: "Authentication failed",
      });
    }

    // User validation
    const getCheckUser: any = await user.findOne({
      _id: userTokenCheck.uid,
      is_deleted: 0,
    });

    if (!getCheckUser) {
      return res.status(401).json({
        success: 0,
        message: "Your Account is Deleted",
      });
    }

    // File ID validation
    if (!data.id) {
      return res.status(400).json({
        success: 1,
        message: "id required",
      });
    }
    let dataname = data.id.split("==||File||==")
    let fileID = data.id.split(".")[0];
    if(dataname.length == 2){
      fileID = dataname[1].split(".")[0]
    }
    let dataname1 = data.id.split("==File==")
    if(dataname1.length == 2){
      fileID = dataname1[1].split(".")[0]
    }
    if(!mongoose.Types.ObjectId.isValid(fileID)){
      return res.status(404).json({
        success: 0,
        message: "Id is Invalid",
      });
    }
    const fileNameData: any = await file_data.findOne({ _id: fileID });

    if (!fileNameData) {
      return res.status(404).json({
        success: 0,
        message: "File not found",
      });
    }

    const fileName = fileNameData.file_manage_name;
    const isThumb = data.isthumb === "true";
    
    let targetFileName: string;
    
    if (isThumb) {
      // Remove extension and add .png for thumbnails
      const fileNameWithoutExt = fileName.split('.').slice(0, -1).join('.');
      targetFileName = `thumbnails__${fileNameWithoutExt}.png`;
    } else {
      targetFileName = fileName;
    }

    // All files are in the uploads directory
    const filePath = path.join(__dirname, '../../../../uploads', targetFileName);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        success: 0,
        message: "File not found",
      });
    }

    // Send the file
    res.sendFile(filePath, (err) => {
      if (err) {
        console.error("File send error:", err);
        res.status(500).json({ success: 0, message: "Error serving file" });
      }
    });

  } catch (error) {
    console.error("getBlobFile error:", error);
    res.status(500).json({ success: 0, message: "Something went wrong" });
  }
};

export default {
  NewuploadFile,
  getBlobFile,
};


