import  { Request, Response, NextFunction } from "express";
import enterprise from "../../models/enterprise";
import user_tokens from "../../models/user_tokens";
import user from "../../models/user";
import EmailValidation from "../../helper/emailvalidation";
import jwt, { Secret, JwtPayload } from "jsonwebtoken";
import { config } from "../../config";
import upload from "../../upload";
import user_admin from "../../models/user_admin";
import accessgroup from "../../models/accessgroup";
import REGEXP from "../../regexp";
import mongoose from "mongoose";
import multer from 'multer';
import get_token from "../../helper/userHeader";
import User_token from "../../helper/helper";
import call_history from "../../models/call_history";
import User_token_admin from "../../helper/helper_admin";
import moment from "moment";
const addNewRecord = async (req: Request, res: Response, next: NextFunction) => {
  try {
    upload(req, res, async (error) => {
      try {
        if (!req?.files) {
          res.status(404).send({
            success: 0,
            message: "File not found",
          });
          return;
        }
        if (error) {
          if (error instanceof multer.MulterError) {
            let create_message: any = error.field + " " + error.message
            res.status(500).send({
              success: 0,
              message: create_message,
            });
          } else {
            res.status(500).send({
              success: 0,
              message: error.message,
            });
          }
          return;
        }
        let data = req.body;

        if (!data?.enterprise_name) {
          res.status(403).send({
            success: 0,
            message: "Enterprise Name is Mandatory",
          });
          return;
        }
        if (!REGEXP.ENTERPRISE.NAME.test(data.enterprise_name)) {
          res.status(403).send({
            success: 0,
            message: "Enterprise Name is not valid. Its length must be in range of 1-64 and only alphabets, numbers, space and underscore are allowed. It must start with either alphabet or number",
          });
          return;
        }

        // if (!("status" in data)) {
        //   res.status(403).send({
        //     success: 0,
        //     message: "Enterprise Activate is Mandatory",
        //   });
        //   return;
        // }
       
        if (("status" in data)&&!REGEXP.ENTERPRISE.STATUS.test(data.status)) {
          res.status(403).send({
            success: 0,
            message: "Enterprise Activate is invalid",
          });
          return;
        }

        if (!REGEXP.ENTERPRISE.contactAddress.test(data?.contactAddress)) {
          res.status(403).send({
            success: 0,
            message: "Contact Address is not valid. Its length must be in range of 1-350 ",
          });
          return;
        }

        if (!("enterprise_password" in data)) {
          res.status(403).send({
            success: 0,
            message: "enterprise_password  is mandatory",
          });
          return;
        }

        if (
          typeof data?.enterprise_password !== "string" ||
          data?.enterprise_password.length === 0
        ) {
          res.status(403).send({
            success: 0,
            message: "enterprise_password is invalid.",
          });
          return;
        }

        if (!("enterprise_email" in data)) {
          res.status(403).send({
            success: 0,
            message: "Email Address is Mandatory",
          });
          return;
        }

        // if (!REGEXP.COMMON.EMAIL.test(data?.enterprise_email)) {
        //   res.status(403).send({
        //     success: 0,
        //     message: "Email Address is not valid",
        //   });
        //   return;
        // }

        // if (!("phoneNumber" in data)) {
        //   res.status(403).send({
        //     success: 0,
        //     message: "Phone Number is Mandatory",
        //   });
        //   return;
        // }

        // if (("phoneNumber" in data) && !REGEXP.COMMON.PHONENUMBER.test(data?.phoneNumber)) {
        //   res.status(403).send({
        //     success: 0,
        //     message: "Phone Number is not valid. Its length must be in range of 3-20 and only numeric values allowed",
        //   });
        //   return;
        // }

        if (("islogoAdded" in data) && !REGEXP.COMMON.BOOLEAN.test(data?.islogoAdded)) {
          res.status(403).send({
            success: 0,
            message: "islogoAdded is invalid",
          });
          return;
        }

        data = req.body;

        let files_detail: any = req?.files;

        const ifCompanyExists = await enterprise.findOne({
          enterprise_name: data.enterprise_name,
          is_deleted:0
        });

        if (ifCompanyExists) {
          res.status(409).send({
            success: 0,
            message: "Company Name already exists. Enter a unique Name for Company",
          });
          return;
        }

        if (ifCompanyExists) {
          res.status(409).send({
            success: 0,
            message: "Company Name already exists. Enter a unique Name for Company",
          });
          return;
        }

        if (!data.enterprise_email) {
          res.status(404).send({
            success: 0,
            message: "Company_email is missing",
          });
          return;
        }

        // let check_email: any = await EmailValidation(data.enterprise_email);
        // if (!check_email) {
        //   res.status(400).send({
        //     success: 0,
        //     message: "Please Enter Valid Email",
        //   });
        //   return;
        // }
        let check_enterprise_email: any = await enterprise.findOne({
          emailAddress: data.enterprise_email,
          is_deleted:0
        });
        let check_user_exists_email: any = await user_admin.findOne({
          user_email: data.enterprise_email,
          user_type: { $ne: 1 },
          is_deleted:0
        });
        if (check_enterprise_email || check_user_exists_email) {
          res.status(409).send({
            success: 0,
            message: "Company Email Already Exists",
          });
          return;
        }
        let image_url_logo: any = "";
        let islogoAdded: any = data.islogoAdded;
        if (islogoAdded == 1 && files_detail.logo_file == undefined) {
          res.status(403).send({
            success: 0,
            message: "logo_file is Not Selected",
          });
          return;
        }
        if (
          islogoAdded !== undefined &&
          islogoAdded == 1 &&
          files_detail !== undefined &&
          files_detail.logo_file !== undefined &&
          files_detail.logo_file[0]?.path
        ) {
          let myUrl = files_detail.logo_file[0]?.path;
          myUrl = myUrl.replace("../uploads", "uploads");
          image_url_logo = myUrl;
        }

          const post = new enterprise();
          post.enterprise_name = data.enterprise_name;
          post.Logo = image_url_logo;
          post.contactAddress = data.contactAddress;
          post.enterprise_password = data.enterprise_password;
          post.is_deleted = 0
          post.emailAddress = data.enterprise_email;
          post.phoneNumber = data.phoneNumber;
          await post.save();


          let create_enterprise_nm: String = post.enterprise_name;

          let add_enterprise_admin: any = new user_admin();
          add_enterprise_admin.user_name = post.enterprise_name;
          add_enterprise_admin.userName = create_enterprise_nm;
          add_enterprise_admin.name = post.enterprise_name;
          add_enterprise_admin.user_email = post.emailAddress;
          add_enterprise_admin.user_password = post.enterprise_password;
          add_enterprise_admin.user_mobileNumber = post.phoneNumber;
          add_enterprise_admin.is_deleted = 0;
          add_enterprise_admin.user_image = post.Logo;
          add_enterprise_admin.eid = post._id;
          add_enterprise_admin.user_type = 3;
          await add_enterprise_admin.save();

         return res.status(200).send({
            success: 1,
            message: "New Company added successfully",
            post,
          });
        
      } catch (error) {
        console.log("Error in addNewRecord: createEnterPrise", error);
        res.status(500).send({
          success: 0,
          message: "Internal Server Error",
        });
      }
    });
  } catch (error: any) {
    //console.log("Error in addNewRecord: createEnterPrise", error);
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};
const editRecord = async (req: Request, res: Response, next: NextFunction) => {
  try {
    upload(req, res, async (error) => {
      if (!req?.files) {
        res.status(404).send({
          success: 0,
          message: "File not found",
        });
        return;
      }
      if (error) {
        if (error instanceof multer.MulterError) {
          let create_message: any = error.field + " " + error.message
          res.status(500).send({
            success: 0,
            message: create_message,
          });
        } else {
          res.status(500).send({
            success: 0,
            message: error.message,
          });
        }
        return;
      }
      let data = req.body;
      if (!data.eid) {
        res.status(403).send({
          success: 0,
          message: "eid is mandatory",
        });
        return;
      }

      if (!mongoose.Types.ObjectId.isValid(data.eid)) {
        res.status(403).send({
          success: 0,
          message: "eid is isvalid",
        });
        return;
      }

      if (!data?.enterprise_name) {
        res.status(403).send({
          success: 0,
          message: "Enterprise Name is Mandatory",
        });
        return;
      }

      if (!REGEXP.ENTERPRISE.NAME.test(data.enterprise_name)) {
        res.status(403).send({
          success: 0,
          message: "Enterprise Name is not valid. Its length must be in range of 1-64 and only alphabets, numbers, space and underscore are allowed. It must start with either alphabet or number",
        });
        return;
      }

      if (!("status" in data)) {
        res.status(403).send({
          success: 0,
          message: "Enterprise Activate is Mandatory",
        });
        return;
      }

      if (!REGEXP.ENTERPRISE.STATUS.test(data.status)) {
        res.status(403).send({
          success: 0,
          message: "Enterprise Activate is invalid",
        });
        return;
      }

      if (!("contactAddress" in data)) {
        res.status(403).send({
          success: 0,
          message: "Contact Address is Mandatory",
        });
        return;
      }

      if (!REGEXP.ENTERPRISE.contactAddress.test(data?.contactAddress)) {
        res.status(403).send({
          success: 0,
          message: "Contact Address is not valid. Its length must be in range of 1-350 ",
        });
        return;
      }

      if (!("enterprise_email" in data)) {
        res.status(403).send({
          success: 0,
          message: "Email Address is Mandatory",
        });
        return;
      }

      // if (!REGEXP.COMMON.EMAIL.test(data?.enterprise_email)) {
      //   res.status(403).send({
      //     success: 0,
      //     message: "Email Address is not valid",
      //   });
      //   return;
      // }

      if (!("phoneNumber" in data)) {
        res.status(403).send({
          success: 0,
          message: "Phone Number is Mandatory",
        });
        return;
      }

      // if (!REGEXP.COMMON.PHONENUMBER.test(data?.phoneNumber)) {
      //   res.status(403).send({
      //     success: 0,
      //     message: "Phone Number is not valid. Its length must be in range of 3-20 and only numeric values allowed",
      //   });
      //   return;
      // }

      if (("islogoEdited" in data) && !REGEXP.COMMON.BOOLEAN.test(data?.islogoEdited)) {
        res.status(403).send({
          success: 0,
          message: "islogoEdited is invalid",
        });
        return;
      }

      let files_detail: any = req?.files;

      const ifCompanyExists = await enterprise.findOne({
        _id: data.eid,
        is_deleted:0
      });
      if (!ifCompanyExists) {
        res.status(404).send({
          success: 0,
          message: "Enterprise is Not exists",
        });
        return;
      }
      let check_enterprise_email: any = await enterprise.findOne({
        emailAddress: data.enterprise_email,
        _id: { $ne: data.eid },
        is_deleted:0
      });
      let check_user_exists_email: any = await user_admin.findOne({
        user_email: data.enterprise_email,
        user_type: { $ne: 1 },
        eid: { $ne: data.eid },
        is_deleted:0
      });

      if (check_enterprise_email || check_user_exists_email) {
        res.status(409).send({
          success: 0,
          message: "User Email Already Exists",
        });
        return;
      }
      let islogoEdited: any = data.islogoEdited;
      let logo_tmp: any = data.Logo;

      if (islogoEdited == 1 && files_detail.logo_file == undefined) {
        res.status(403).send({
          success: 0,
          message: "logo_file is Not Selected",
        });
        return;
      }

      if (
        islogoEdited !== undefined &&
        islogoEdited == 1 &&
        files_detail !== undefined &&
        files_detail.logo_file[0]?.path
      ) {
        let myUrl = files_detail.logo_file[0]?.path;
        myUrl = myUrl.replace("../uploads", "uploads");
        logo_tmp = myUrl;
      }

      const ifCompanyExists_name = await enterprise.findOne({
        enterprise_name: data.enterprise_name,
        _id: { $ne: data.eid },
        is_deleted: 0
      });

      if (ifCompanyExists_name) {
        res.status(409).send({
          success: 0,
          message: "Enterprise Name already exists. Enter a unique Name for Enterprise",
        });
        return;
      }

      let get_old_detail_enterprise: any = await enterprise.findOne({
        _id: data.eid,
        is_deleted:0
      });

        let enterprise_detail: any = await enterprise.findOneAndUpdate(
          {
            _id: data.eid,
            is_deleted:0
          },
          {
            enterprise_name: data.enterprise_name,
            status: data.status,
            contactAddress: data.contactAddress,
            phoneNumber: data.phoneNumber,
            emailAddress: data.enterprise_email,
            Logo: logo_tmp
          },
          {
            new: true,
          }
        );
        let create_enterprise_nm: String =
          enterprise_detail.enterprise_name;

        await user_admin.findOneAndUpdate(
          {
            eid: get_old_detail_enterprise._id,
            user_type: 3,
            is_deleted:0
          },
          {
            user_email: enterprise_detail.emailAddress,
            user_name: enterprise_detail.enterprise_name,
            name: enterprise_detail.enterprise_name,
            user_image: enterprise_detail.Logo,
            userName: create_enterprise_nm,
            user_mobileNumber: enterprise_detail.phoneNumber
          }
        );

        res.status(200).send({
          success: 1,
          message: "Company Detail Updated successfully",
          enterprise_detail,
        });
      
    });
  } catch (error: any) {
    // //console.log("Error in Edit Enterprise: ",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};
const removeRecord = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let eid: any = req.body.eid;
    if (eid) {
      let check_enterprise: any = await enterprise.findOne({
        _id: eid,
        is_deleted:0
      });
      // //console.log(check_enterprise,"dkg")
      if (check_enterprise) {
        let check_ent_users: any = await user.find({
          eid: eid,
          is_deleted:0
        });
        if (check_ent_users.length > 0) {
          res.status(402).send({
            success: 0,
            message:
              "Please delete all subscribers or inactive subscribers before deleting Enterprise " +
              check_enterprise.enterprise_name +
              ".",
          });
        } else {
            // //console.log("is hosted else clled")
            let deleted_enterprise: any = await enterprise.findOneAndUpdate(
              {
                _id: eid,
                is_deleted:0
              },{
                is_deleted:1
              }
            );
            await user_admin.findOneAndUpdate(
              {
                eid: eid,
                user_type: 3,
                is_deleted:0
              },
              {is_deleted:1}
            );
            res.status(200).send({
              success: 1,
              message: "company Deleted Successfully",
              EnterpriseDetail: deleted_enterprise,
            });
        }
      } else {
        res.status(404).send({
          success: 0,
          message: "Enterprise is not Found",
        });
      }
    } else {
      res.status(404).send({
        success: 0,
        message: "Enterprise_id is missing",
      });
    }
  } catch (error: any) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};
const GetAllRecord = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let data: any = req.body
    let page: any = data.page;
    let size: any = data.size;
    if (!page) page = 1;
    if (!size) size = 50;

    let search: any = data.search?.toString();
    let tmp_filter: any = data.filter;
    let filter: any = parseInt(tmp_filter);
    let find_query: any;
    if (search) {
      find_query = {
        $or: [
          {
            enterprise_name: {
              $regex: search,
              $options: "i",
            },
          },
          {
            emailAddress: {
              $regex: search,
            },
          },
        ],
        is_deleted:0
      };
    } else {
      find_query = {
        is_deleted:0
      };
    }

    if (filter == 1) {
      find_query.status = "A";
    }
    if (filter == 2) {
      find_query.status = "N";
    }

    let limit: any = parseInt(size);
    let skip: any = (page - 1) * size;

    let enterprise_detail: any[] = await enterprise
      .aggregate([
        {
          $match: find_query,
        },
        {
          $lookup: {
            from: "users",
            localField: "_id",
            foreignField: "eid",
            as: "enterprise_users",
          },
        },
        {
          $addFields: {
            active_users: {
              $filter: {
                input: "$enterprise_users",
                as: "item",
                cond: { $eq: ["$$item.subscriberActivate", "Y"] },
              },
            },
          },
        },
        {
          $project: {
            _id: 1,
            enterprise_name: 1,
            enterprise_username: 1,
            emailAddress: 1,
            Logo: 1,
            status: 1,
            total_users: {
              $size: "$enterprise_users",
            },
            active_users: {
              $size: "$active_users",
            },
            createdAt: 1,
          },
        },
      ])
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    let total_enterprise_count: any = await enterprise.find(find_query).countDocuments();

    let active_enterprise_count: any = await enterprise
      .find({
        status: "A",
        is_deleted:0
      })
      .countDocuments();

    let inactive_enterprise_count: any = await enterprise
      .find({
        status: "N",
        is_deleted:0
      })
      .countDocuments();

    let all_enterprise_count: any = await enterprise
      .find({is_deleted:0})
      .countDocuments();

    let total_page_count: any = Math.ceil(total_enterprise_count / size);

    res.status(200).send({
      success: 1,
      message: "Enterprise List",
      Enterprise_list: enterprise_detail,
      total_enterprise_count,
      total_page_count,
      active_enterprise_count,
      inactive_enterprise_count,
      all_enterprise_count,
    });
  } catch (error: any) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const GetRecordByID = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let enterprise_id: any = req.body.enterprise_id;
    if (enterprise_id) {
      let check_enterprise: any = await enterprise.findOne({
        _id: enterprise_id,
        is_deleted:0
      }).select("status contactAddress phoneNumber emailAddress billingAddress Logo is_deleted enterprise_name")
      if (check_enterprise) {
        res.status(200).send({
          success: 1,
          message: "Enterprise Detail",
          Enterprise_detail: check_enterprise,
        });
      } else {
        res.status(404).send({
          success: 0,
          message: "Enterprise is not Exists",
        });
      }
    } else {
      res.status(404).send({
        success: 0,
        message: "Enterprise_id is missing",
      });
    }
  } catch (error: any) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const Enterpriselogin = async (req: Request, res: Response, next: NextFunction) => {
  try {
    var data = req.body;
    let message: any = "";
    let status: any;

    if (!("enterprise_email" in data)) {
      res.status(403).send({
        success: 0,
        message: "enterprise_email is mandatory",
      });
      return;
    }


    if (!("password" in data)) {
      res.status(403).send({
        success: 0,
        message: "password is mandatory",
      });
      return;
    }

    const results = await user_admin.findOne({
      user_email: data.enterprise_email,
      is_deleted:0
    });
    if (results == null) {
      return res.status(404).send({
        success: 0,
        message: "Email is Incorrect"
      });
    }

    const results_user = await user_admin.findOne({
      user_email: data.enterprise_email,
      user_password: data.password,
      user_type: { $ne: 4 },
      is_deleted:0
    });
    // //console.log("results_user", results_user);
    if (results_user == null) {
      return res.status(401).send({
        success: 0,
        message: "Password is Incorrect"
      });
    }

    let updated_admin_time: any = await user_admin.findOneAndUpdate({
      user_email: data.enterprise_email,
      user_password: data.password,
      user_type: { $ne: 4 },
      is_deleted:0
    }, {
      last_login_time: new Date()
    }, {
      new: true
    })

    //console.log("updated_admin_time",updated_admin_time)
    const token = jwt.sign(
      {
        uid: results?._id,
        eid: results?.eid,
        //udid: results.user_did
      },
      config.key.secret_key,
      { expiresIn: "1d" }
    );

    const refresh_token = jwt.sign(
      {
        uid: results?._id,
        eid: results?.eid,
        //udid: results.user_did
      },
      config.key.secret_key,
      { expiresIn: "1d" }
    );

    const token_post = new user_tokens();
    token_post.uid = results?._id;
    token_post.token = token;
    token_post.refresh_token = refresh_token;
    token_post.push_token = "";
    //token_post.push_type = results.push_type ? results.push_type : 0;
    await token_post.save();


    const userData = await user_admin
      .findOne({
        _id: results?._id,
        is_deleted:0
      })
      .select("user_name user_email eid user_type user_image");

    let check_user_detail: any = await user_admin
      .findOne({
        _id: results?._id,
        is_deleted:0
      })
      .select(
        "user_name userName name user_email eid user_image user_status user_mobileNumber user_address is_deleted user_type accessgroup selected_Enterprise"
      );

    let permission_obj: any = {
      dashboard_view: 0,
      enterprise_create: 0,
      enterprise_update: 0,
      enterprise_delete: 0,
      enterprise_view: 0,
      subscriber_create: 0,
      subscriber_update: 0,
      subscriber_delete: 0,
      subscriber_view: 0,
      add_admin_create: 0,
      add_admin_update: 0,
      add_admin_delete: 0,
      add_admin_view: 0,
      add_role_create: 0,
      add_role_update: 0,
      add_role_delete: 0,
      add_role_view: 0,
      cdr_view: 0,
      cdr_download: 0,
    };

    if (userData?.user_type === 1) {
      permission_obj.dashboard_view = 1;
      permission_obj.enterprise_create = 1;
      permission_obj.enterprise_update = 1;
      permission_obj.enterprise_delete = 1;
      permission_obj.enterprise_view = 1;
      permission_obj.subscriber_create = 1;
      permission_obj.subscriber_update = 1;
      permission_obj.subscriber_delete = 1;
      permission_obj.subscriber_view = 1;
      permission_obj.add_admin_create = 1;
      permission_obj.add_admin_update = 1;
      permission_obj.add_admin_delete = 1;
      permission_obj.add_admin_view = 1;
      permission_obj.add_role_create = 1;
      permission_obj.add_role_update = 1;
      permission_obj.add_role_delete = 1;
      permission_obj.add_role_view = 1;
      permission_obj.cdr_view = 1;
      permission_obj.cdr_download = 1;
    } else if (userData?.user_type === 2) {
      let get_subadmin_detail: any = await accessgroup.findOne({
        _id: check_user_detail.accessgroup,
      });
      // //console.log("dashboard_view", get_subadmin_detail);
      if (get_subadmin_detail) {
        permission_obj.dashboard_view = get_subadmin_detail.dashboard_view;
        permission_obj.enterprise_create = get_subadmin_detail.enterprise_create;
        permission_obj.enterprise_update = get_subadmin_detail.enterprise_update;
        permission_obj.enterprise_delete = get_subadmin_detail.enterprise_delete;
        permission_obj.enterprise_view = get_subadmin_detail.enterprise_view;
        permission_obj.subscriber_create = get_subadmin_detail.subscriber_create;
        permission_obj.subscriber_update = get_subadmin_detail.subscriber_update;
        permission_obj.subscriber_delete = get_subadmin_detail.subscriber_delete;
        permission_obj.subscriber_view = get_subadmin_detail.subscriber_view;
        permission_obj.add_admin_create = get_subadmin_detail.add_admin_create;
        permission_obj.add_admin_update = get_subadmin_detail.add_admin_update;
        permission_obj.add_admin_delete = get_subadmin_detail.add_admin_delete;
        permission_obj.add_admin_view = get_subadmin_detail.add_admin_view;
        permission_obj.add_role_create = get_subadmin_detail.add_role_create;
        permission_obj.add_role_update = get_subadmin_detail.add_role_update;
        permission_obj.add_role_delete = get_subadmin_detail.add_role_delete;
        permission_obj.add_role_view = get_subadmin_detail.add_role_view;
        permission_obj.cdr_view = get_subadmin_detail.cdr_view;
        permission_obj.cdr_download = get_subadmin_detail.cdr_download;
      }

    } else if (userData?.user_type === 3) {
      permission_obj.dashboard_view = 1;
      permission_obj.enterprise_create = 0;
      permission_obj.enterprise_update = 0;
      permission_obj.enterprise_delete = 0;
      permission_obj.enterprise_view = 0;
      permission_obj.subscriber_create = 1;
      permission_obj.subscriber_update = 1;
      permission_obj.subscriber_delete = 1;
      permission_obj.subscriber_view = 1;
      permission_obj.add_admin_create = 0;
      permission_obj.add_admin_update = 0;
      permission_obj.add_admin_delete = 0;
      permission_obj.add_admin_view = 0;
      permission_obj.add_role_create = 0;
      permission_obj.add_role_update = 0;
      permission_obj.add_role_delete = 0;
      permission_obj.add_role_view = 0;
      permission_obj.cdr_view = 1;
      permission_obj.cdr_download = 1;
    } else {
      permission_obj = permission_obj;
    }
    if (userData?.accessgroup) {
      let get_accecgroup_detail: any = await accessgroup.findById({
        _id: userData?.accessgroup,
      });
    }

    let enterprise_detail_tmp: any = await enterprise
      .findOne({
        _id: check_user_detail.eid,
        is_deleted:0
      })
      .select(
        "enterprise_name enterprise_username noOfSubscriber status createdByStaffId sipDomain contactAddress phoneNumber emailAddress billingAddress isRatingEnable isInternalFreeCalls entStatus isTPREnable concurrency MOHFile Featurepackages ipAddress Port Logo PrimaryColor SecondaryColor isHosted"
      );

    let profile_detail: any = null;
    let enterprise_detail: any = null;
    if (
      check_user_detail !== undefined &&
      check_user_detail !== null &&
      check_user_detail.user_type === 3 &&
      enterprise_detail_tmp
    ) {
      enterprise_detail = enterprise_detail_tmp;
    } else if (
      check_user_detail !== undefined &&
      check_user_detail !== null &&
      check_user_detail.user_type === 2
    ) {
      profile_detail = check_user_detail;
    } else if (
      check_user_detail !== undefined &&
      check_user_detail !== null &&
      check_user_detail.user_type === 1
    ) {
      profile_detail = check_user_detail;
    }

    let get_Lince_detail: any = {};    
    return res.status(200).send({
      success: 1,
      message: "Your Token and Details",
      Token: token,
      RefreshToken: refresh_token,
      UserDetails: userData,
      Permissions_detail: permission_obj,
      Enterprise_detail: enterprise_detail,
      Profile_Detail: profile_detail,
      licence_detail: get_Lince_detail
    });
  } catch (error) {
    // //console.log("error catch called",error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const EnterpriseList = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let check_enterprise: any = await enterprise
      .find({
        is_deleted: 0,
      })
      .select("enterprise_name Featurepackages sipDomain");

    res.status(200).send({
      success: 1,
      message: "Company List",
      Enterprise_detail: check_enterprise,
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }

};
const EnterpriseListdropdown = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let check_enterprise: any = await enterprise
      .find(
        {is_deleted:0}
      )
      .select("enterprise_name _id");

    res.status(200).send({
      success: 1,
      message: "Company List",
      Enterprise_detail: check_enterprise,
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }

};
const EnterpriseInfo = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let eid: any = user_detail?.eid
    let enterpriseData: any = await enterprise
      .findOne({_id:eid, is_deleted:0})
      .select("PrimaryColor Logo updatedAt");

    res.status(200).send({
      success: 1,
      message: "Enterprise Details",
      data: enterpriseData,
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const ResetPassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = req.body;
    const emailAddress = data.enterprise_email;

    const enterpriseData: any = await enterprise.findOne(
      {
        emailAddress: emailAddress,
        is_deleted: 0
      }
    );

    if (!enterpriseData) {
      return res.status(404).send({
        success: 0,
        message: "Email Not Found",
      });
    }
    const resetToken = jwt.sign(
      {
        eid: enterpriseData._id,
      },
      config.key.secret_key,
      { expiresIn: "15m" }
    );

    const UpdatedenterpriseData: any = await enterprise.findOneAndUpdate(
      {
        _id:enterpriseData._id,
        is_deleted:0
      },
      {
        resetToken: resetToken,
      }
    )
    res.status(200).send({
      success: 1,
      message: "Reset password link sent to your email successfully",
    });

  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};
const ConfirmResetPassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = req.body;
    const token = data.token;
    const newPassword = data.password;
    const confirmPassword = data.confirm_password;

    if (token == undefined) {
      return res.status(404).send({
        success: 0,
        message: "token is mandatory for reset password",
      });
    }
    if (newPassword == undefined) {
      return res.status(404).send({
        success: 0,
        message: "password is mandatory for reset password",
      });
    }
    if (confirmPassword == undefined) {
      return res.status(404).send({
        success: 0,
        message: "confirmPassword is mandatory for reset password",
      });
    }

    if (newPassword !== confirmPassword) {
      return res.status(404).send({
        success: 0,
        message: "Password and Confirm Password are not same",
      });
    }

    if (newPassword.length === 0) {
      return res.status(404).send({
        success: 0,
        message: "Password is mandatory for reset password",
      });
    }
    try {
      jwt.verify(token, config.key.secret_key, async (err: any, decoded: any) => {
        if (err) {
          return res.status(404).send({
            success: 0,
            message: "Link has been expired",
          });
        }
        const eid = decoded.eid;
        //console.log(decoded,eid,"eid")
        const enterpriseData: any = await enterprise.findOneAndUpdate(
          {
            _id: eid,
            is_deleted: 0
          },
          {
            enterprise_password: newPassword,
          },
          {
            new: true,
          }
        );


        if (enterpriseData == null) {
          return res.status(404).send({
            success: 0,
            message: "Enterprise not found",
          });
        }

        const enterprise_admin: any = await user_admin.findOneAndUpdate(
          {
            user_email: enterpriseData.emailAddress,
            eid: eid,
            is_deleted: 0,
            user_type: 3
          },
          {
            user_password: newPassword,
          },
          {
            new: true,
          });
        if (enterprise_admin == null) {
          return res.status(404).send({
            success: 0,
            message: "Company Admin not found",
          });
        }

        return res.status(200).send({
          success: 1,
          message: "Company Password Reset Successfully",
        });
      });
    } catch (error) {
      res.status(500).send({
        success: 0,
        message: "Internal Server Error,",
      });
    }
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};
const getDashboardDEtail = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token_admin(token);

    let uid: any = user_detail?.uid

    let data: any = req.body
    let startDate: any = data.startDate
    let endDate: any = data.endDate

    startDate = moment(startDate, "YYYY-MM-DD").format("YYYY-MM-DD")
    var start = new Date(startDate);
    start.setUTCHours(0, 0, 0, 0);

    //console.log("start",start)
    endDate = moment(endDate, "YYYY-MM-DD").format("YYYY-MM-DD")
    console.log("endDate", endDate)
    var end = new Date(endDate);
    end.setUTCHours(23, 59, 59, 999);

    console.log("start", start)
    console.log("end", end)

    let get_user_type: any = await user_admin.findOne({
      _id: uid,
      is_deleted:0
    })

    if (!get_user_type) {
      return res.status(404).send({
        success: 0,
        message: "User Not Exists"
      })
    }

    let user_type: Number = get_user_type.user_type;

    let respons_obj: { [key: string]: any } = {};

    if (user_type === 1) {
      let get_enterprise: any = await enterprise.find({
        is_deleted: 0
      }).countDocuments();

      respons_obj.total_enterprise = get_enterprise

      let get_enterprise_active: any = await enterprise.find({
        is_deleted: 0,
        status: "A",
      }).countDocuments();

      respons_obj.total_active_enterprise = get_enterprise_active

      let get_user_detail: any = await user.find({
        is_deleted: 0
      }).countDocuments();

      respons_obj.total_subscriber = get_user_detail

      let get_user_detail_active: any = await user.find({
        is_deleted: 0,
        subscriberActivate: "Y"
      }).countDocuments();

      respons_obj.total_active_subscriber = get_user_detail_active

      let get_user_admins: any = await user_admin.find({
        is_deleted: 0,
        user_type: 2,
      }).countDocuments();

      let get_user_admins_active: any = await user_admin.find({
        is_deleted: 0,
        user_type: 2,
        user_status: 1,
      }).countDocuments();

      respons_obj.total_user = get_user_admins

      respons_obj.total_active_user = get_user_admins_active

      let get_live_call_count = await call_history.find({
        call_time: { $gte: start, $lte: end },
        iscallEnded: 0
      }).countDocuments();

      respons_obj.live_total_call = get_live_call_count

      let get_enterprisecalls_today: any = await call_history.find({
        call_time: { $gte: start, $lte: end }
      }).countDocuments();

      respons_obj.todays_total_call = get_enterprisecalls_today

      let get_enterprise_call_detail: any = await call_history.aggregate([
        {
          $match: {
            call_time: { $gte: start, $lte: end }
          }
        },
        {
          $sort: {
            createdAt: -1
          }
        },
        {
          $group: {
            _id: "$eid",
            enterprise_call: {
              $push: "$$ROOT"
            }
          }
        },
        {
          $lookup: {
            from: "enterprises",
            localField: "_id",
            foreignField: "_id",
            pipeline: [
              {
                $match:{
                  is_deleted:0
                }
              },
              {
                $project: {
                  _id: 1,
                  enterprise_name: 1,
                  Logo: 1
                }
              }],
            as: "enterprise_detail"
          }
        },
        {
          $unwind: "$enterprise_detail"
        },
        {
          $project: {
            enterprise_calls: {
              $size: "$enterprise_call"
            },
            enterprise_name: "$enterprise_detail.enterprise_name",
            enterprise_image: "$enterprise_detail.Logo"
          }
        },
        {
          $sort: {
            enterprise_calls: -1
          }
        },
        {
          $limit: 5
        }
      ], { allowDiskUse: true })

      let total_calls_tmp: any = 0
      if (get_enterprise_call_detail.length > 0) {
        await Promise.all(get_enterprise_call_detail.map(async (items: any) => {
          total_calls_tmp = total_calls_tmp + items.enterprise_calls
        }))
      }
      let top_enterprise_calls_obj: { [key: string]: any } = {};
      top_enterprise_calls_obj.total_calls = total_calls_tmp

      let enterprise_list_arr: any[] = [];
      enterprise_list_arr = get_enterprise_call_detail

      top_enterprise_calls_obj.Enterprise_list = enterprise_list_arr

      respons_obj.top_enterprise_calls = top_enterprise_calls_obj

      let get_enterprise_call_detail_duration: any = await call_history.aggregate([
        {
          $match: {
            call_time: { $gte: start, $lte: end }
          }
        },
        {
          $sort: {
            duration: -1
          }
        },
        {
          $group: {
            _id: "$eid",
            eid: { $first: "$eid" },
            internalDurations: {
              $push: {
                $cond: [
                  {
                    $and: [
                      { $eq: ["$isinternal_call", 1] },
                      { $not: [{ $regexMatch: { input: "$call_id", regex: /@/ } }] }
                    ]
                  },
                  "$duration",
                  null
                ]
              }
            },
            externalDurations: {
              $push: {
                $cond: [
                  { $eq: ["$isinternal_call", 0] },
                  "$duration",
                  null
                ]
              }
            }
          }
        },
        {
          $addFields: {
            internalTotalSeconds: {
              $reduce: {
                input: {
                  $filter: { input: "$internalDurations", as: "dur", cond: { $ne: ["$$dur", null] } }
                },
                initialValue: 0,
                in: {
                  $let: {
                    vars: {
                      parts: { $split: ["$$this", ":"] }
                    },
                    in: {
                      $add: [
                        "$$value",
                        { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 0] } }, 3600] },
                        { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 1] } }, 60] },
                        { $toInt: { $arrayElemAt: ["$$parts", 2] } }
                      ]
                    }
                  }
                }
              }
            },
            externalTotalSeconds: {
              $reduce: {
                input: {
                  $filter: { input: "$externalDurations", as: "dur", cond: { $ne: ["$$dur", null] } }
                },
                initialValue: 0,
                in: {
                  $let: {
                    vars: {
                      parts: { $split: ["$$this", ":"] }
                    },
                    in: {
                      $add: [
                        "$$value",
                        { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 0] } }, 3600] },
                        { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 1] } }, 60] },
                        { $toInt: { $arrayElemAt: ["$$parts", 2] } }
                      ]
                    }
                  }
                }
              }
            }
          }
        },
        {
          $addFields: {
            internalHours: { $toInt: { $divide: ["$internalTotalSeconds", 3600] } },
            internalMinutes: { $toInt: { $mod: [{ $divide: ["$internalTotalSeconds", 60] }, 60] } },
            internalSeconds: { $toInt: { $mod: ["$internalTotalSeconds", 60] } },
            externalHours: { $toInt: { $divide: ["$externalTotalSeconds", 3600] } },
            externalMinutes: { $toInt: { $mod: [{ $divide: ["$externalTotalSeconds", 60] }, 60] } },
            externalSeconds: { $toInt: { $mod: ["$externalTotalSeconds", 60] } }
          }
        },
        {
          $addFields: {
            totalSeconds: { $add: ["$internalTotalSeconds", "$externalTotalSeconds"] },
          }
        },
        {
          $addFields: {
            totalHours: { $toInt: { $divide: ["$totalSeconds", 3600] } },
            totalMinutes: { $toInt: { $mod: [{ $divide: ["$totalSeconds", 60] }, 60] } },
            totalSeconds: { $toInt: { $mod: ["$totalSeconds", 60] } },
          }
        },
        {
          $addFields: {
            duration: {
              $concat: [
                { $cond: { if: { $lte: ["$totalHours", 9] }, then: { $concat: ["0", { $toString: "$totalHours" }] }, else: { $toString: "$totalHours" } } }, ":",
                { $cond: { if: { $lte: ["$totalMinutes", 9] }, then: { $concat: ["0", { $toString: "$totalMinutes" }] }, else: { $toString: "$totalMinutes" } } }, ":",
                { $cond: { if: { $lte: ["$totalSeconds", 9] }, then: { $concat: ["0", { $toString: "$totalSeconds" }] }, else: { $toString: "$totalSeconds" } } }
              ]
            }
          }
        },
        {
          $lookup: {
            from: "enterprises",
            localField: "eid",
            foreignField: "_id",
            pipeline: [
              {
                $match:{
                  is_deleted:0
                }
              },
              {
                $project: {
                  _id: 1,
                  enterprise_name: 1,
                  Logo: 1
                }
              }
            ],
            as: "enterprise_detail"
          }
        },
        {
          $unwind: "$enterprise_detail"
        },
        {
          $sort: {
            duration: -1
          }
        },
        {
          $limit: 5
        },
        {
          $project: {
            eid: 1,
            enterprise_name: "$enterprise_detail.enterprise_name",
            enterprise_image: "$enterprise_detail.Logo",
            duration: 1
          }
        }
      ], { allowDiskUse: true });

      let total_calls_duration: any[] = []
      if (get_enterprise_call_detail_duration.length > 0) {
        await Promise.all(get_enterprise_call_detail_duration.map(async (items: any) => {
          total_calls_duration.push(items.duration)
        }))
      }
      let sum = "00:00:00";

      if (total_calls_duration.length > 0) {
        let totoalHours: any = 0
        let totoalMinutes: any = 0
        let totoalSeconds: any = 0

        await Promise.all(total_calls_duration.map(async (value: any) => {
          const [hours, minutes, seconds] = value.split(':').map(Number)
          totoalHours += hours
          totoalMinutes += minutes
          totoalSeconds += seconds
        }));
        totoalMinutes += Math.floor(totoalSeconds / 60)
        totoalSeconds %= 60
        totoalHours += Math.floor(totoalMinutes / 60)
        totoalMinutes %= 60

        sum = String(totoalHours).padStart(2, "0") + ":" + String(totoalMinutes).padStart(2, "0") + ":" + String(totoalSeconds).padStart(2, "0")
      }

      let top_enterprise_calls_duration_obj: { [key: string]: any } = {};

      let enterprise_list_duration_arr: any[] = [];
      enterprise_list_duration_arr = get_enterprise_call_detail_duration

      top_enterprise_calls_duration_obj.Enterprise_list = enterprise_list_duration_arr
      top_enterprise_calls_duration_obj.total_duration = sum

      respons_obj.top_enterprise_duration_calls = top_enterprise_calls_duration_obj

      let get_user_call_detail: any = await call_history.aggregate([
        {
          $match: {
            call_time: { $gte: start, $lte: end }
          }
        },
        {
          $sort: {
            createdAt: -1
          }
        },
        {
          $group: {
            _id: {
              for_user: "$for_user",
              sipDomain: "$sipDomain"
            },
            user_call: {
              $push: "$$ROOT" // Collect all documents into an array
            }
          },
        },
        {
          $project: {
            sipDomain: 1,
            for_user: 1,
            call_id: 1,
            user_call_count: {
              $size: "$user_call"
            }
          }
        },
        {
          $sort: {
            user_call_count: -1
          }
        },
        {
          $limit: 5
        }
      ], { allowDiskUse: true });

      //console.log("get_user_call_detail",get_user_call_detail)

      let top_users_calls: any[] = []
      let total_call_count_sub: any = 0
      if (get_user_call_detail.length > 0) {
        await Promise.all(get_user_call_detail.map(async (items: any) => {
          let get_user: any = await user.findOne({
            $or: [
              {
                endpointNumber: items._id.for_user,
              },
              {
                callerId: items._id.for_user,
              }
            ],
            sipDomain: items._id.sipDomain,
            is_deleted: 0
          })
          if (get_user) {
            total_call_count_sub = total_call_count_sub + items?.user_call_count
            let send_obj: any = {
              user_name: get_user.first_name + " " + get_user.last_name,
              user_image: get_user.user_image,
              user_count: items?.user_call_count
            }
            top_users_calls.push(send_obj)
          }
        }))
      }
      top_users_calls = top_users_calls.sort((a, b) => {
        let timeA: any = a.user_count
        let timeB: any = b.user_count
        return timeB - timeA; // Sort in descending order
      });

      let top_subscriber_calls_obj: { [key: string]: any } = {};
      top_subscriber_calls_obj.total_calls = total_call_count_sub
      let subscriber_list_arr: any[] = [];
      subscriber_list_arr = top_users_calls
      top_subscriber_calls_obj.subscriber_list = subscriber_list_arr
      respons_obj.top_subscriber_call_count = top_subscriber_calls_obj

      let Difference_In_Time: any = end.getTime() - start.getTime()

      let diff_days: any = Math.round(Difference_In_Time / (1000 * 3600 * 24))

      let loop_count: any = 24

      let grouping_obj: any = {
        y: { $year: "$call_time" },
        m: { $month: "$call_time" },
        d: { $dayOfMonth: "$call_time" },
        h: { $hour: "$call_time" },
      };

      if (diff_days > 1) {
        let get_daysOFmonth: any = moment(start).daysInMonth();
        loop_count = get_daysOFmonth
        grouping_obj = {
          y: { $year: "$call_time" },
          m: { $month: "$call_time" },
          d: { $dayOfMonth: "$call_time" },
        };
      }
      if (diff_days > 31) {
        loop_count = 12
        grouping_obj = {
          y: { $year: "$call_time" },
          m: { $month: "$call_time" }
        };
      }

      let get_live_calls: any[] = await call_history.aggregate([
        {
          $match: {
            $and: [
              {
                call_time: {
                  $gte: start,
                },
              },
              {
                call_time: {
                  $lte: end,
                },
              },
            ],
          }
        },
        {
          $group: {
            _id: grouping_obj,
            internal_call_counts: {
              $sum: {
                $cond:
                  [
                    { $eq: ["$isinternal_call", 1] }, 1, 0],
              },
            },
            external_call_counts: {
              $sum: {
                $cond: [{ $eq: ["$isinternal_call", 0] }, 1, 0],
              },
            },
            call_count: {
              $push: "$$ROOT"
            }
          },
        },
        {
          $project: {
            _id: 1,
            internal_call_counts: 1,
            external_call_counts: 1,
            user_call_count: {
              $size: "$call_count"
            }
          }
        },
      ], { allowDiskUse: true })

      //console.log("get_live_calls",get_live_calls)

      let get_max_call_count: any[] = get_live_calls.sort((a, b) => {
        let A: any = a._id.user_call_count
        let B: any = b._id.user_call_count
        return B - A; // Sort in descending order
      });

      let check_max_data: any = 0
      if (get_max_call_count.length > 0) {
        check_max_data = get_max_call_count[0].user_call_count
      }

      let res_arr: any[] = []
      if (diff_days > 31) {
        for (let index = 1; index <= loop_count; index++) {
          let get_detail: any[] = get_live_calls.filter((item) => item._id.m == index)
          let new_arr_obj = {}
          let string_index: any = index.toString();
          let name_tmp: any = String(string_index).padStart(2, "0");
          let name_new: any = moment(name_tmp, "MM").format("MMM")
          if (get_detail.length > 0) {
            new_arr_obj = {
              name: name_new,
              count: get_detail[0].user_call_count,
              internal_call_counts: get_detail[0].internal_call_counts,
              external_call_counts: get_detail[0].external_call_counts
            }
          } else {
            new_arr_obj = {
              name: name_new,
              count: 0,
              internal_call_counts: 0,
              external_call_counts: 0
            }
          }
          res_arr.push(new_arr_obj)
        }
        //console.log("first if called")
      } else if (diff_days > 1) {
        for (let index = 1; index <= loop_count; index++) {
          let get_detail: any[] = get_live_calls.filter((item) => item._id.d == index)
          let new_arr_obj = {}
          if (get_detail.length > 0) {
            new_arr_obj = {
              name: index.toString(),
              count: get_detail[0].user_call_count,
              internal_call_counts: get_detail[0].internal_call_counts,
              external_call_counts: get_detail[0].external_call_counts
            }
          } else {
            new_arr_obj = {
              name: index.toString(),
              count: 0,
              internal_call_counts: 0,
              external_call_counts: 0
            }
          }
          res_arr.push(new_arr_obj)
        }
        //console.log("second if caaled")
      } else {
        //console.log("else called")
        for (let index = 0; index < loop_count; index++) {
          let get_detail: any[] = get_live_calls.filter((item) => item._id.h == index)
          let new_arr_obj = {}
          let string_index: any = index.toString();
          let name_tmp: any = String(string_index).padStart(2, "0");
          let name_new: any = moment(name_tmp, "HH").format("h a")
          if (get_detail.length > 0) {
            new_arr_obj = {
              name: name_new.toString(),
              count: get_detail[0].user_call_count,
              internal_call_counts: get_detail[0].internal_call_counts,
              external_call_counts: get_detail[0].external_call_counts
            }
          } else {
            new_arr_obj = {
              name: name_new.toString(),
              count: 0,
              internal_call_counts: 0,
              external_call_counts: 0
            }
          }
          res_arr.push(new_arr_obj)
        }
      }

      let top_live_calls_obj: { [key: string]: any } = {};
      top_live_calls_obj.max_calls = check_max_data
      let live_call_list_arr: any[] = [];
      live_call_list_arr = res_arr
      top_live_calls_obj.live_call_list_arr = live_call_list_arr
      respons_obj.top_live_calls = top_live_calls_obj
    }


    return res.status(200).send({
      success: 1,
      message: "Dashboaed Details",
      Dashboard_detail: respons_obj
    });

  } catch (error) {
    console.log("error", error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getDashboardDEtailEnterprise = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token_admin(token);

    let uid: any = user_detail?.uid

    let data: any = req.body
    let startDate: any = data.startDate
    let endDate: any = data.endDate
    let eid: any = data.eid
    startDate = moment(startDate, "YYYY-MM-DD").format("YYYY-MM-DD")
    var start = new Date(startDate);
    start.setUTCHours(0, 0, 0, 0);

    //console.log("start",start)
    endDate = moment(endDate, "YYYY-MM-DD").format("YYYY-MM-DD")
    var end = new Date(endDate);
    end.setUTCHours(23, 59, 59, 999);

    //console.log("start",start)
    //console.log("end",end)

    let get_user_type: any = await user_admin.findById({
      _id: uid
    })

    if (!get_user_type) {
      return res.status(404).send({
        success: 0,
        message: "User Not Exists"
      })
    }


    let respons_obj: { [key: string]: any } = {};

    let get_user_detail: any = await user.find({
      is_deleted: 0,
      eid: eid
    }).countDocuments();

    respons_obj.total_subscriber = get_user_detail

    let get_user_detail_active: any = await user.find({
      is_deleted: 0,
      subscriberActivate: "Y",
      eid: eid
    }).countDocuments();

    respons_obj.total_active_subscriber = get_user_detail_active

    let get_user_admins: any = await user_admin.find({
      is_deleted: 0,
      user_type: 2,
      selected_Enterprise: { $in: [eid] }
    }).countDocuments();

    let get_user_admins_active: any = await user_admin.find({
      is_deleted: 0,
      user_type: 2,
      user_status: 1,
      selected_Enterprise: { $in: [eid] }
    }).countDocuments();

    respons_obj.total_user = get_user_admins

    respons_obj.total_active_user = get_user_admins_active

    let get_enterprisecalls: any = await call_history.find({
      eid: eid,
      call_time: { $gte: start, $lte: end }
    }).countDocuments();

    respons_obj.todays_total_call = get_enterprisecalls


    let get_live_call_count = await call_history.find({
      eid: eid,
      call_time: { $gte: start, $lte: end },
      iscallEnded: 0
    }).countDocuments();

    respons_obj.live_total_call = get_live_call_count

    let get_user_call_detail: any = await call_history.aggregate([
      {
        $match: {
          eid: new mongoose.Types.ObjectId(eid),
          call_time: { $gte: start, $lte: end }
        }
      },
      {
        $sort: {
          createdAt: -1
        }
      },
      {
        $group: {
          _id: {
            for_user: "$for_user",
            sipDomain: "$sipDomain"
          },
          user_call: {
            $push: "$$ROOT"
          }
        },
      },
      {
        $project: {
          sipDomain: 1,
          from: 1,
          user_call_count: {
            $size: "$user_call"
          }
        }
      },
      {
        $sort: {
          user_call_count: -1
        }
      },
      {
        $limit: 5
      }
    ]);

    let top_users_calls: any[] = []
    let total_call_count: any = 0
    if (get_user_call_detail.length > 0) {
      await Promise.all(get_user_call_detail.map(async (items: any) => {
        let get_user: any = await user.findOne({
          $or: [
            {
              endpointNumber: items._id.for_user,
            },
            {
              callerId: items._id.for_user,
            }
          ],
          sipDomain: items._id.sipDomain,
          is_deleted: 0
        })
        if (get_user) {
          total_call_count = total_call_count + items?.user_call_count
          let send_obj: any = {
            user_name: get_user.first_name + " " + get_user.last_name,
            user_image: get_user.user_image,
            user_count: items?.user_call_count
          }
          top_users_calls.push(send_obj)
        }
      }))
    }
    let top_users_calls_obj: { [key: string]: any } = {};
    top_users_calls_obj.total_calls = total_call_count

    top_users_calls = top_users_calls.sort((a, b) => {
      let timeA: any = a.user_count
      let timeB: any = b.user_count
      return timeB - timeA; // Sort in descending order
    });

    top_users_calls_obj.top_users_calls_arr = top_users_calls

    respons_obj.top_users_calls_arr = top_users_calls_obj

    let get_user_call_detail_duration: any = await call_history.aggregate([
      {
        $match: {
          eid: new mongoose.Types.ObjectId(eid),
          call_time: { $gte: start, $lte: end }
        }
      },
      {
        $sort: {
          duration: -1
        }
      },
      {
        $group: {
          _id: { for_user: "$for_user", sipDomain: "$sipDomain" },
          internalDurations: {
            $push: {
              $cond: [
                {
                  $and: [
                    { $eq: ["$isinternal_call", 1] },
                    { $not: [{ $regexMatch: { input: "$call_id", regex: /@/ } }] }
                  ]
                },
                "$duration",
                null
              ]
            }
          },
          externalDurations: {
            $push: {
              $cond: [
                { $eq: ["$isinternal_call", 0] },
                "$duration",
                null
              ]
            }
          }
        }
      },
      {
        $addFields: {
          internalTotalSeconds: {
            $reduce: {
              input: {
                $filter: { input: "$internalDurations", as: "dur", cond: { $ne: ["$$dur", null] } }
              },
              initialValue: 0,
              in: {
                $let: {
                  vars: {
                    parts: { $split: ["$$this", ":"] }
                  },
                  in: {
                    $add: [
                      "$$value",
                      { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 0] } }, 3600] },
                      { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 1] } }, 60] },
                      { $toInt: { $arrayElemAt: ["$$parts", 2] } }
                    ]
                  }
                }
              }
            }
          },
          externalTotalSeconds: {
            $reduce: {
              input: {
                $filter: { input: "$externalDurations", as: "dur", cond: { $ne: ["$$dur", null] } }
              },
              initialValue: 0,
              in: {
                $let: {
                  vars: {
                    parts: { $split: ["$$this", ":"] }
                  },
                  in: {
                    $add: [
                      "$$value",
                      { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 0] } }, 3600] },
                      { $multiply: [{ $toInt: { $arrayElemAt: ["$$parts", 1] } }, 60] },
                      { $toInt: { $arrayElemAt: ["$$parts", 2] } }
                    ]
                  }
                }
              }
            }
          }
        }
      },
      {
        $addFields: {
          internalHours: { $toInt: { $divide: ["$internalTotalSeconds", 3600] } },
          internalMinutes: { $toInt: { $mod: [{ $divide: ["$internalTotalSeconds", 60] }, 60] } },
          internalSeconds: { $toInt: { $mod: ["$internalTotalSeconds", 60] } },
          externalHours: { $toInt: { $divide: ["$externalTotalSeconds", 3600] } },
          externalMinutes: { $toInt: { $mod: [{ $divide: ["$externalTotalSeconds", 60] }, 60] } },
          externalSeconds: { $toInt: { $mod: ["$externalTotalSeconds", 60] } }
        }
      },
      {
        $addFields: {
          totalSeconds: { $add: ["$internalTotalSeconds", "$externalTotalSeconds"] },
        }
      },
      {
        $addFields: {
          totalHours: { $toInt: { $divide: ["$totalSeconds", 3600] } },
          totalMinutes: { $toInt: { $mod: [{ $divide: ["$totalSeconds", 60] }, 60] } },
          totalSeconds: { $toInt: { $mod: ["$totalSeconds", 60] } },
        }
      },
      {
        $addFields: {
          duration: {
            $concat: [
              { $cond: { if: { $lte: ["$totalHours", 9] }, then: { $concat: ["0", { $toString: "$totalHours" }] }, else: { $toString: "$totalHours" } } }, ":",
              { $cond: { if: { $lte: ["$totalMinutes", 9] }, then: { $concat: ["0", { $toString: "$totalMinutes" }] }, else: { $toString: "$totalMinutes" } } }, ":",
              { $cond: { if: { $lte: ["$totalSeconds", 9] }, then: { $concat: ["0", { $toString: "$totalSeconds" }] }, else: { $toString: "$totalSeconds" } } }
            ]
          }
        }
      },
      {
        $project: {
          _id: 1,
          duration: 1
        }
      },
      {
        $sort: {
          duration: -1
        }
      },
      {
        $limit: 5
      }
    ]);
    let top_users_calls_duration: any[] = []
    let sum = "00:00:00";
    if (get_user_call_detail_duration.length > 0) {
      let totoalHours: any = 0
      let totoalMinutes: any = 0
      let totoalSeconds: any = 0
      await Promise.all(get_user_call_detail_duration.map(async (items: any) => {
        let get_user: any = await user.findOne({
          $or: [
            {
              endpointNumber: items._id.for_user,
            },
            {
              callerId: items._id.for_user,
            }
          ],
          sipDomain: items._id.sipDomain,
          is_deleted: 0
        })
        if (get_user) {
          let send_obj: any = {
            user_name: get_user.first_name + " " + get_user.last_name,
            user_image: get_user.user_image,
            duration: items?.duration
          }
          const [hours, minutes, seconds] = items.duration.split(':').map(Number)
          totoalHours += hours
          totoalMinutes += minutes
          totoalSeconds += seconds

          top_users_calls_duration.push(send_obj)
          totoalMinutes += Math.floor(totoalSeconds / 60)
          totoalSeconds %= 60
          totoalHours += Math.floor(totoalMinutes / 60)
          totoalMinutes %= 60
          sum = String(totoalHours).padStart(2, "0") + ":" + String(totoalMinutes).padStart(2, "0") + ":" + String(totoalSeconds).padStart(2, "0")
        }
      }))
    }

    const durationToSeconds = (duration: string) => {
      const [hours, minutes, seconds] = duration.split(':').map(Number);
      return hours * 3600 + minutes * 60 + seconds;
    };

    top_users_calls_duration.sort((a, b) => {
      const timeA = durationToSeconds(a.duration);
      const timeB = durationToSeconds(b.duration);
      return timeB - timeA; // Descending order
    });

    let top_users_calls_duration_obj: { [key: string]: any } = {};
    top_users_calls_duration_obj.total_call_duration = sum
    top_users_calls_duration_obj.top_users_calls_arr = top_users_calls_duration

    respons_obj.top_users_calls_duration_arr = top_users_calls_duration_obj


    let Difference_In_Time: any = end.getTime() - start.getTime()

    let diff_days: any = Math.round(Difference_In_Time / (1000 * 3600 * 24))

    let loop_count: any = 24

    let grouping_obj: any = {
      y: { $year: "$call_time" },
      m: { $month: "$call_time" },
      d: { $dayOfMonth: "$call_time" },
      h: { $hour: "$call_time" },
    };

    if (diff_days > 1) {
      let get_daysOFmonth: any = moment(start).daysInMonth();
      loop_count = get_daysOFmonth
      grouping_obj = {
        y: { $year: "$call_time" },
        m: { $month: "$call_time" },
        d: { $dayOfMonth: "$call_time" },
      };
    }
    if (diff_days > 31) {
      loop_count = 12
      grouping_obj = {
        y: { $year: "$call_time" },
        m: { $month: "$call_time" }
      };
    }

    let get_live_calls: any[] = await call_history.aggregate([
      {
        $match: {
          eid: new mongoose.Types.ObjectId(eid),
          $and: [
            {
              call_time: {
                $gte: start,
              },
            },
            {
              call_time: {
                $lte: end,
              },
            },
          ],
        }
      },
      {
        $group: {
          _id: grouping_obj,
          internal_call_counts: {
            $sum: {
              $cond:
                [
                  { $eq: ["$isinternal_call", 1] }, 1, 0],
            },
          },
          external_call_counts: {
            $sum: {
              $cond: [{ $eq: ["$isinternal_call", 0] }, 1, 0],
            },
          },
          call_count: {
            $push: "$$ROOT"
          }
        },
      },
      {
        $project: {
          _id: 1,
          internal_call_counts: 1,
          external_call_counts: 1,
          user_call_count: {
            $size: "$call_count"
          }
        }
      },
    ])

    let get_max_call_count: any[] = get_live_calls.sort((a, b) => {
      let A: any = a._id.user_call_count
      let B: any = b._id.user_call_count
      return B - A; // Sort in descending order
    });

    let check_max_data: any = 0
    if (get_max_call_count.length > 0) {
      check_max_data = get_max_call_count[0].user_call_count
    }

    let res_arr: any[] = []
    if (diff_days > 31) {
      for (let index = 1; index <= loop_count; index++) {
        let get_detail: any[] = get_live_calls.filter((item) => item._id.m == index)
        let new_arr_obj = {}
        let string_index: any = index.toString();
        let name_tmp: any = String(string_index).padStart(2, "0");
        let name_new: any = moment(name_tmp, "MM").format("MMM")
        if (get_detail.length > 0) {
          new_arr_obj = {
            name: name_new,
            count: get_detail[0].user_call_count,
            internal_call_counts: get_detail[0].internal_call_counts,
            external_call_counts: get_detail[0].external_call_counts
          }
        } else {
          new_arr_obj = {
            name: name_new,
            count: 0,
            internal_call_counts: 0,
            external_call_counts: 0
          }
        }
        res_arr.push(new_arr_obj)
      }
      //console.log("first if called")
    } else if (diff_days > 1) {
      for (let index = 1; index <= loop_count; index++) {
        let get_detail: any[] = get_live_calls.filter((item) => item._id.d == index)
        let new_arr_obj = {}
        if (get_detail.length > 0) {
          new_arr_obj = {
            name: index.toString(),
            count: get_detail[0].user_call_count,
            internal_call_counts: get_detail[0].internal_call_counts,
            external_call_counts: get_detail[0].external_call_counts
          }
        } else {
          new_arr_obj = {
            name: index.toString(),
            count: 0,
            internal_call_counts: 0,
            external_call_counts: 0
          }
        }
        res_arr.push(new_arr_obj)
      }
      //console.log("second if caaled")
    } else {
      //console.log("else called")
      for (let index = 0; index < loop_count; index++) {
        let get_detail: any[] = get_live_calls.filter((item) => item._id.h == index)
        let new_arr_obj = {}
        let string_index: any = index.toString();
        let name_tmp: any = String(string_index).padStart(2, "0");
        let name_new: any = moment(name_tmp, "HH").format("h a")
        if (get_detail.length > 0) {
          new_arr_obj = {
            name: name_new.toString(),
            count: get_detail[0].user_call_count,
            internal_call_counts: get_detail[0].internal_call_counts,
            external_call_counts: get_detail[0].external_call_counts
          }
        } else {
          new_arr_obj = {
            name: name_new.toString(),
            count: 0,
            internal_call_counts: 0,
            external_call_counts: 0
          }
        }
        res_arr.push(new_arr_obj)
      }
    }

    let top_live_calls_obj: { [key: string]: any } = {};
    top_live_calls_obj.max_calls = check_max_data
    let live_call_list_arr: any[] = [];
    live_call_list_arr = res_arr
    top_live_calls_obj.live_call_list_arr = live_call_list_arr
    respons_obj.top_live_calls = top_live_calls_obj


    return res.status(200).send({
      success: 1,
      message: "Dashboaed Details",
      Dashboard_detail: respons_obj
    });

  } catch (error) {
    //console.log("error",error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const updateAdminPassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = req.body;
    const user_email = data.user_email;
    const user_password = data.user_password;
    const user_newPassword = data.user_newPassword;
    const user_newPassword_conform = data.user_newPassword_conform;


    if (user_newPassword !== user_newPassword_conform) {
      return res.status(401).send({
        success: 0,
        message: "Password and Confirm Password must be match",
      });
    }

    const AdminUserDetail: any = await user_admin.findOne(
      {
        user_email: user_email,
        user_password: user_password,
        is_deleted: 0
      }
    );

    if (!AdminUserDetail == null || AdminUserDetail == undefined) {
      return res.status(404).send({
        success: 0,
        message: "Admin User Not Found",
      });
    }

    let udated_admin: any = await user_admin.findByIdAndUpdate({
      _id: AdminUserDetail._id
    }, {
      user_password: user_newPassword
    })

   return res.status(200).send({
      success: 1,
      message: "Password Reset successfully",
    });

  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};
const GetCDRlogsDownload = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let data: any = req.body
    let eid_find: any = data.eid
    let endpointnumber: any = data.endpointnumber;
    let startDate: any = new Date(data.startDate)
    let endDate: any = new Date(data.endDate)
    let internal_calls: any = data.internal_calls

    let find_query: { [key: string]: any } = {};
    if (endpointnumber !== undefined && endpointnumber !== null) {
      find_query = {
        $or: [
          {
            from: {
              $regex: endpointnumber,
              $options: "i"
            }
          },
          {
            to: {
              $regex: endpointnumber,
              $options: "i"
            }
          }
        ]
      }
    }
    if (startDate !== undefined && endDate !== undefined && startDate !== null && endDate !== null) {
      find_query.call_time = {
        $gte: startDate,
        $lte: endDate
      }
    }
    if (eid_find !== undefined && eid_find !== null) {
      find_query.eid = new mongoose.Types.ObjectId(eid_find)
    }
    if (internal_calls == 1) {
      find_query.isinternal_call = 1
    } else if (internal_calls == 2) {
      find_query.isinternal_call = 0
    } else {
      //no need to add filter
    }
    let get_CDR_Log: any = await call_history.aggregate([
      {
        $match: find_query
      },
      {
        $lookup: {
          from: "enterprises",
          localField: "eid",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                enterprise_name: 1
              }
            }],
          as: "enterprise_detail"
        }
      },
      {
        $unwind: {
          path: "$enterprise_detail",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $project: {
          _id: 1,
          eid: 1,
          from: 1,
          to: 1,
          sipDomain: 1,
          duration: 1,
          call_time: 1,
          direction: 1,
          from_user_name: 1,
          to_user_name: 1,
          enterprise_name: "$enterprise_detail.enterprise_name",
          createdAt: 1
        }
      },
      {
        $sort: {
          createdAt: -1
        }
      }
    ])

    let arr_user: any[] = get_CDR_Log.length > 0 ? get_CDR_Log : []

    let response_arr: any[] = [];
    if (arr_user.length > 0) {
      await Promise.all(arr_user.map(async (value: any) => {
        let call_time_tmp: any = moment(value.call_time, "YYYY-MM-DDTHH:mm:ss.sssZ").utc().format("YYYY-MM-DD hh:mm:ss A")
        value.call_time = call_time_tmp
        let created_time_tmp: any = moment(value.createdAt, "YYYY-MM-DDTHH:mm:ss.sssZ").utc().format("YYYY-MM-DD hh:mm:ss A")
        value.createdAt = created_time_tmp
        response_arr.push(value)
      }))
    }

    return res.status(200).send({
      success: 1,
      message: "CDR Log Detail",
      CallDetail: get_CDR_Log,
    });
  } catch (error) {
    //console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
};
const updatePassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = req.body;
    const eid = data.eid;
    const enterprise_password = data.enterprise_password;

    if(!mongoose.Types.ObjectId.isValid(eid)){
      return res.status(404).send({
        success: 0,
        message: "eid is Invalid",
      });
    }

    const companyDetail: any = await enterprise.findOne(
      {
        _id: eid,
        is_deleted: 0
      }
    );

    if (!companyDetail == null || companyDetail == undefined) {
      return res.status(404).send({
        success: 0,
        message: "Company Not Found",
      });
    }

    await enterprise.findByIdAndUpdate({
      _id: companyDetail._id
    }, {
      enterprise_password:enterprise_password
    }
    )

    await user_admin.findOneAndUpdate({
      eid: eid
    }, {
      user_password: enterprise_password
    })

   return res.status(200).send({
      success: 1,
      message: "Company Password Updated successfully",
    });

  } catch (error) {
    console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};
export default {
  addNewRecord,
  editRecord,
  removeRecord,
  GetAllRecord,
  GetRecordByID,
  Enterpriselogin,
  EnterpriseList,
  EnterpriseListdropdown,
  EnterpriseInfo,
  ResetPassword,
  ConfirmResetPassword,
  getDashboardDEtail,
  getDashboardDEtailEnterprise,
  updateAdminPassword,
  GetCDRlogsDownload,
  updatePassword
};
