import { Request, Response, NextFunction } from "express";
import mongoose from "mongoose";
import group from "../../models/group";
import group_conversation from "../../models/group_conversation";
import group_message_status from "../../models/group_message_status";
import group_members from "../../models/group_members";
import User_token from "../../helper/helper";
import get_token from "../../helper/userHeader";

const getMessageDetail = async (req: Request, res: Response, next: NextFunction) => {
    try {
        let message_id = req.params.message_id;

        if(!mongoose.Types.ObjectId.isValid(message_id)){
            return res.status(401).send({
                success:0,
                message:"Message Is Not Valid"
            })
        }
        let tmp_message_deliverd = await group_message_status
        .find({
            message_id: message_id,
            delivery_type: {$ne:3},
        })
        .populate({
            path: "receiver_id",
            model: "user",
            select:"first_name last_name user_image"
        });
        let tmp_message_read = await group_message_status
        .find({
            message_id: message_id,
            delivery_type: 3,
        })
        .populate({
            path: "receiver_id",
            model: "user",
            select:"first_name last_name user_image"
        });

        let MessageDetail:any = await group_conversation.findById({
            _id:message_id
        })
  
    res.status(200).send({
      success: 1,
      message: "Group Message Detail",
      MessageDetail:MessageDetail,
      ReadData: tmp_message_read,
      DeliverdData: tmp_message_deliverd,
    });
    } catch (error) {
        res.status(500).send({
        success: 0,
        messsage: "Internal Server Error"
    })
    }
}
const getGroupDetail = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const token = await get_token(req);
        const user_detail = await User_token(token);
        const uid =user_detail?.uid;

        let group_id = req.params.group_id;

        if(!mongoose.Types.ObjectId.isValid(group_id)){
            return res.status(401).send({
                success:0,
                message:"Group Id Is Not Valid"
            })
        }

        let get_group_detail:any = await group.findOne({
            _id:group_id
        })
        if(!get_group_detail){
            return res.status(404).send({
                success:0,
                message:"Group Is Not Found"
            })
        }

        let check_user_role = await group_members.findOne({
            group_id:group_id,
            member_id:uid
        })

        if(!check_user_role){
            return res.status(404).send({
                success: 0,
                message: "You do not have permission to perform this action"
            })
        }

        let get_group_user_detail1:any = await group_members.find({
            group_id:group_id,
            isleaved:0
        })
      
        let get_group_user_detail:any = await group_members.find({
            group_id:group_id,
            isleaved:0
        }).populate({
            path:"member_id",
            model:"user",
            select:"first_name last_name user_image"
          })
        console.log(get_group_user_detail,"get_group_user_detail")

        get_group_detail = get_group_detail.toObject()
        get_group_detail.group_users = get_group_user_detail

        get_group_detail.group_user_count = get_group_user_detail.length
  
        return res.status(200).send({
             success: 1,
            message: "Group Detail",
            Group_detai:get_group_detail
        });
    } catch (error) {
        res.status(500).send({
        success: 0,
        messsage: "Internal Server Error"
    })
    }
}
export default {
    getMessageDetail,
    getGroupDetail
}