import { Request, Response, NextFunction } from "express";
import mongoose from "mongoose";
import user from "../../models/user";
import user_tokens from "../../models/user_tokens";
import conversation from "../../models/conversation";
import group_conversation from "../../models/group_conversation";
import group_members from "../../models/group_members";
import group from "../../models/group";
import jwt, { Secret, JwtPayload, sign } from "jsonwebtoken";
import { config } from "../../config";
import enterprise from "../../models/enterprise";
import EmailValidation from "../../helper/emailvalidation";
import User_token from "../../helper/helper";
import get_token from "../../helper/userHeader";
import group_message_status from "../../models/group_message_status";
import upload from "../../upload";
import sendPushNotification from "../../helper/sendPushNotification";
//import sendPushNotificationios from "../../helper/sendPushNotificationios";
import user_block from "../../models/user_block";
import user_admin from "../../models/user_admin";
import User_token_admin from "../../helper/helper_admin";
import accessgroup from "../../models/accessgroup";
import REGEXP from "../../regexp";
import multer from 'multer';
import user_contact from "../../models/user_contact";
import call_history from "../../models/call_history";
import provisioninglog from "../../models/provisioninglog";
import moment from "moment";
import momentTimezone from 'moment-timezone';
import { MESSAGE, PROVISIONLOG } from "../../constant";
import user_fav_contact from "../../models/user_fav_contact";
import sharp from "sharp";
import { v1 as uuidv1, v4 as uuidv4 } from 'uuid';
import { emitHandler } from "../../socket";
import { resetAttempts } from "../../middleware/loginAttempt";

const userLogin = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const ip = (req.headers["x-real-ip"] as string) || req.ip || "unknown";
    var data = req.body;
    let device_id: any = data.device_id;
    let device_name: any = data.device_name;
    let osversion: any = data.osversion;
    let apns_push_token: any = data.apns_push_token;
    let user_name: any = data.user_name;
    let password: any = data.password;
    
    // let check_account_deleted: any = await user.find({
    //   user_name: user_name.toLowerCase(),
    //   is_deleted:0
    // })

    // let check_account_exist: any = await user.find({
    //   user_name: user_name.toLowerCase(),
    // })

    // if(check_account_deleted.length==0){
    //   return res.status(402).send({
    //     success: 0,
    //     message: check_account_exist.length!=0?"Your Account Is Deleted":"Your login credentials are invalid.",
    //   });
    // }

    let check_user: any = await user
      .findOne({
        user_name: user_name.toLowerCase(),
        password: password,
        is_deleted:0
      })
      .select(
        "first_name last_name emailAddress MobileNumber  endpointNumber eid user_type keep_message user_name user_image"
      );

    if (!check_user) {
      return res.status(402).send({
        success: 0,
        message: "Your login credentials are invalid.",
      });
    }

    if (device_name === undefined || device_name === "") {
      res.status(403).send({
        success: 0,
        message: "device_name is mandatory",
      });
      return;
    }

    if (device_id === undefined || device_id === "") {
      res.status(403).send({
        success: 0,
        message: "device_id is mandatory",
      });
      return;
    }

    if (osversion === undefined || osversion === "") {
      res.status(403).send({
        success: 0,
        message: "osversion is mandatory",
      });
      return;
    }

    if (osversion != 1 && osversion != 2 && osversion != 3) {
      res.status(403).send({
        success: 0,
        message: "osversion should be in range [1-3]",
      });
      return;
    }


    let get_enterprise_detail: any = await enterprise.findOne({
      _id: check_user.eid,
      is_deleted:0
    });

    if (!check_user) {
      return res.status(402).send({
        success: 0,
        message: "Company Detail Not Found",
      });
    }


    const token = jwt.sign(
      {
        uid: check_user._id,
        eid: check_user.eid.toString(),
        device_id: device_id,
      },
      config.key.secret_key,
    );
    const refresh_token = jwt.sign(
      {
        uid: check_user._id,
        eid: check_user.eid.toString(),
        device_id: device_id,
      },
      config.key.secret_key,
      {
        expiresIn: "1d",
      }
    );

    let get_user_device_query: any = {};
    if (osversion == 1) {
      get_user_device_query = {
        uid: check_user._id,
        device_id: device_id,
      };
    } else if (osversion == 2) {
      get_user_device_query = {
        uid: check_user._id,
        apns_push_token: apns_push_token,
      };
    } else {
      get_user_device_query = {
        uid: check_user._id,
        device_id: device_id,
      };
    }
    
    let get_user_device_detail: any = await user_tokens.findOne(
      get_user_device_query
    );

    let check_user_login_device_all_count: any = await user_tokens
      .find({
        uid: check_user._id,
        is_primary:true
      })
      .countDocuments();
      // remove device limit for iostesting remove first if part 
      if(user_name=="iostesting"){
        const token_post = new user_tokens();
      token_post.uid = check_user._id;
      token_post.token = token;
      token_post.refresh_token = refresh_token;
      token_post.device_id = device_id;
      token_post.push_token = data.push_token ? data.push_token : "";
      token_post.device_id = device_id;
      token_post.device_name = device_name;
      token_post.osversion = osversion;
      token_post.device_os_version = data.device_os_version
        ? data.device_os_version
        : "";
      token_post.apns_push_token = osversion == 2 ? apns_push_token : "";
      token_post.login_Time = new Date();
      await token_post.save();
      }else if (get_user_device_detail !== null) {
      await user_tokens.findByIdAndUpdate(
        {
          _id: get_user_device_detail._id,
        },
        {
          token: token,
          refresh_token: refresh_token,
          push_token: data.push_token ? data.push_token : "",
          device_name: device_name,
          device_os_version: data.device_os_version
            ? data.device_os_version
            : "",
          apns_push_token: osversion == 2 ? apns_push_token : "",
          login_Time: new Date(),
        }
      );
    } else if (
      check_user_login_device_all_count < 1 &&
      get_user_device_detail == null
    ) {
      const token_post = new user_tokens();
      token_post.uid = check_user._id;
      token_post.token = token;
      token_post.refresh_token = refresh_token;
      token_post.device_id = device_id;
      token_post.push_token = data.push_token ? data.push_token : "";
      token_post.device_id = device_id;
      token_post.device_name = device_name;
      token_post.osversion = osversion;
      token_post.device_os_version = data.device_os_version
        ? data.device_os_version
        : "";
      token_post.apns_push_token = osversion == 2 ? apns_push_token : "";
      token_post.login_Time = new Date();
      await token_post.save();
    }else{
      return res.status(401).send({
        success: 0,
        message: "Your Device Login limit is Over",
      });
    }

    resetAttempts(ip)
    return res.status(200).send({
      success: 1,
      message: "Your Token and Details",
      Token: token,
      RefreshToken: refresh_token,
      UserDetails: check_user,
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};

const qrLogin = async (req:Request, res:Response, next:NextFunction)=>{
  try {
    const token = await get_token(req);
    console.log(token,"token lig")
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    console.log(uid,"user id log")
    const refresh_token:any = await user_tokens.findOne({
      token:token
    }).select("refresh_token")
    let check_user: any = await user
      .findOne({
        _id:uid,
        is_deleted:0
      })
      .select(
        "first_name last_name emailAddress MobileNumber  endpointNumber eid user_type keep_message user_name user_image"
      );
    return res.status(200).send({
      success: 1,
      message: "Your Token and Details",
      Token: token,
      RefreshToken: refresh_token.refresh_token,
      UserDetails: check_user,
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
}
const create = async (req: Request, res: Response, next: NextFunction) => {
  try {
    upload(req, res, async (error: any) => {
      if (!req?.files) {
        res.status(404).send({
          success: 0,
          message: "File not found",
        });
        return;
      }
      if (error) {
        if (error instanceof multer.MulterError) {
          let create_message: any = error.field + " " + error.message
          res.status(500).send({
            success: 0,
            message: create_message,
          });
        } else {
          res.status(500).send({
            success: 0,
            message: error.message,
          });
        }
        return;
      }
      let data: any = req.body
      let eid: any = data.eid
      let first_name: any = data.first_name
      let last_name: any = data.last_name
      let password: any = data.password;
      let emailAddress: any = data.emailAddress;
      let MobileNumber: any = data.MobileNumber;
      let user_name:any = data.user_name.toLowerCase();
      let keep_message:any = data.keep_message
      if (!eid) {
        return res.status(403).send({
          success: 0,
          message: "eid is mandatory"
        });
      }
      if (!first_name) {
        return res.status(403).send({
          success: 0,
          message:
            "first_name is mandatory",
        });
      }
      if (!last_name) {
        return res.status(403).send({
          success: 0,
          message:
            "last_name is mandatory",
        });
      }
      if (!password) {
        return res.status(403).send({
          success: 0,
          message:
            "password is mandatory",
        });
      }
      if (!emailAddress) {
        return res.status(403).send({
          success: 0,
          message:
            "emailAddress is mandatory",
        });
      }
      if (!keep_message) {
        return res.status(403).send({
          success: 0,
          message:
            "keep_message is mandatory",
        });
      }
      if (!MobileNumber) {
        return res.status(403).send({
          success: 0,
          message:
            "MobileNumber is mandatory",
        });
      }
      if (!mongoose.Types.ObjectId.isValid(eid)) {
        return res.status(403).send({
          success: 0,
          message: "eid is Invalid"
        });
      }
      if (!REGEXP.USER.first_name.test(first_name)) {
        return res.status(403).send({
          success: 0,
          message:
            "first_name Id is invalid",
        });
      }
      if(!REGEXP.COMMON.BOOLEAN_STRING_REGEX.test(keep_message)){
        return res.status(403).send({
          success: 0,
          message:"keep_message is invalid",
        });
      }
      if (!REGEXP.USER.last_name.test(last_name)) {
        return res.status(403).send({
          success: 0,
          message:
            "last_name is invalid",
        });
      }
      // if (!REGEXP.COMMON.EMAIL.test(emailAddress)) {
      //   return res.status(403).send({
      //     success: 0,
      //     message:
      //       "Email Address is invalid",
      //   });
      // }
      if (!REGEXP.USER.USERNAME.test(user_name)) {
        return res.status(403).send({
          success: 0,
          message:
            "User Name is invalid",
        });
      }

      // let check_email: any = await EmailValidation(emailAddress);
      // if(!check_email){
      //   return res.status(401).send({
      //     success: 0,
      //     message: "Please Enter Valid Email",
      //   });
      // }
        let get_enterprise_id: any = await enterprise.findOne({
          _id: eid,
          is_deleted:0
        })
        if(get_enterprise_id == null){
         return res.status(404).send({
            success: 0,
            message: "Company Not Exists",
          });
        }
          let check_user_mobile: any = await user.findOne({
            MobileNumber: MobileNumber,
            is_deleted:0
          })
          if (check_user_mobile) {
            return res.status(409).send({
              success: 0,
              message: "User With This MobileNumber Already Exists",
            });
          }
          let check_user_email: any = await user.findOne({
            emailAddress: emailAddress,
            is_deleted:0
          })
          if (check_user_email) {
           return res.status(409).send({
              success: 0,
              message: "User Email Already Exists",
            });
          } 
          let check_user_name: any = await user.findOne({
            user_name: user_name,
            is_deleted:0
          })
          if (check_user_name) {
           return res.status(409).send({
              success: 0,
              message: "User Name Already Exists",
            });
          } 

            let files_detail: any = req?.files;
            let image_url: any = "";

            if (files_detail !== undefined && files_detail.file && files_detail.file[0]?.path) {
              let myUrl = files_detail.file[0]?.path
              myUrl = myUrl.replace("../uploads", "uploads");
              image_url = myUrl
              let temp_url_path: any = files_detail.file[0]?.path
              let get_file_name: any = files_detail.file[0].filename.split("/")
              let name: any = get_file_name[3]
              let name_split: any = name.split(".")
              let final_name: any = name_split[0]
              let folder_nm: any = get_file_name[2]
              let thumbnail_nm: string = '../uploads/' + folder_nm + '/thumbnails__' + final_name + '.png';
              console.log("thumbnail_nm", thumbnail_nm)
              if (files_detail.file[0].mimetype.includes("image/")) {
                //console.log("if clled of sharpe")
                sharp.cache({ files: 0 })
                const data = await sharp(temp_url_path)
                data.metadata()
                  .then(function (metadata: any) {
                    //console.log("shrepe metadat",metadata)
                    return data
                      .toFormat('png', { palette: true })
                      .resize(Math.round(metadata?.width / (metadata?.width * 0.01)))
                      .toFile(thumbnail_nm)
                  })
              }
            }

              first_name = first_name
              let firstCharCode: any = first_name.charCodeAt(0);
              if (firstCharCode >= 65 && firstCharCode <= 90 || firstCharCode >= 97 && firstCharCode <= 122) {
                first_name = first_name.charAt(0).toUpperCase() + first_name.slice(1);
              }
              const post = new user();
              post.eid = eid
              post.first_name = first_name
              post.last_name = last_name
              post.password = password;
              post.emailAddress = emailAddress;
              post.MobileNumber = MobileNumber;
              post.keep_message = keep_message;
              post.user_image = image_url
              post.user_name = user_name.toLowerCase();
              await post.save();

              return res.status(201).send({
                success: 1,
                message: "Add User Successfully",
                UserDetail: post
              });
      } )
  } catch (error) {
    //console.log("Internal Server Error 3",error);
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getallUsersbyEid = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token_admin(token);
    let uid: any = user_detail?.uid
    let data: any = req.body
    let get_eid: any = data.eid
    let page: any = data.page
    let size: any = data.size
    if (!page) page = 1
    if (!size) size = 20
    if(get_eid==undefined){
      const user_admin_data:any = await user_admin.findOne({
        _id : uid
      })
      get_eid = user_admin_data?.selected_Enterprise[0]
    }
    if(get_eid !== undefined && !mongoose.Types.ObjectId.isValid(get_eid)){
      return res.status(404).send({
        success: 0,
        message: "Enterprise ID Is Invalid.",
      });
    }
      if(get_eid !== null && get_eid !== undefined){
        console.log("if called")
        let check_enterprise: any = await enterprise.findOne({
          _id: get_eid,
          is_deleted:0
        })
        if (check_enterprise == null) {
         return res.status(404).send({
            success: 0,
            message: "Company not Exists",
          });
        } 
        let search: any = data.search?.toString()
        let tmp_filter: any = data.filter
        let filter: any = parseInt(tmp_filter)

        let find_query: any;
        if (search) {
          find_query = {
            $or: [
              {
                first_name: {
                  $regex: search,
                  $options: "i"
                }
              },
              {
                last_name: {
                  $regex: search,
                  $options: "i"
                }
              },
              {
                emailAddress: {
                  $regex: search,
                  $options: "i"
                }
              },
              {
                user_name: {
                  $regex: search,
                  $options: "i"
                }
              },
            ],
            eid: check_enterprise._id,
            is_deleted:0
          }
        } else {
          find_query = {
            eid: check_enterprise._id,
            is_deleted:0
          }
        }

        if (filter == 1) {
          find_query.is_online = 1
        } else if (filter == 2) {
          find_query.is_online = 0
        } else {
          
        }
        let limit: any = parseInt(size)
        let skip: any = (page - 1) * size;

        let get_user_detail_new: any = await user.aggregate([
          {
            $match: find_query
          },
          {
            $lookup: {
              from: "user_tokens",
              localField: "_id",
              foreignField: "uid",
              pipeline: [{
                $match: {
                  device_id: { $ne: "" },
                  device_name: { $ne: "" },
                  osversion: { $ne: 0 }
                }
              },
              {
                $sort: {
                  createdAt: -1
                }
              },
              {
                $project: {
                  _id: 1,
                  device_os_version: 1,
                  device_name: 1,
                  login_Time: 1,
                  osversion: 1,
                  device_id: 1,
                }
              }],
              as: "users_login_devices"
            }
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              MobileNumber: 1,
              user_name:1,
              keep_message:1,
              is_online: 1,
              user_image: 1,
              userLogin_devices_count: {
                $size: "$users_login_devices"
              },
              userLogin_devices: "$users_login_devices",
              createdAt: 1
            }
          },
          {
            $lookup: {
              from: "enterprises",
              localField: "eid",
              foreignField: "_id",
              as: "enterprise_detail"
            }
          },
          {
            $unwind: "$enterprise_detail"
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              MobileNumber: 1,
              user_name:1,
              keep_message:1,
              is_online: 1,
              is_deleted:1,
              user_image: 1,
              userLogin_devices_count: 1,
              userLogin_devices: 1,
              createdAt: 1,
              enterprise_name: "$enterprise_detail.enterprise_name"
            }
          }
        ]).sort({ createdAt: -1 }).skip(skip).limit(limit);

        let get_users_count: any = await user.find(find_query).countDocuments();
        let total_page_count: any = Math.ceil(get_users_count / size);


        let get_count_all_user: any = await user.find({
          eid: check_enterprise._id,
          is_deleted:0
        }).countDocuments()

        let online_user_count: any = await user.find({
          eid: check_enterprise._id,
          is_online: 1,
          is_deleted:0
        }).countDocuments()

        let offline_user_count: any = await user.find({
          eid: check_enterprise._id,
          is_online: 0,
          is_deleted:0
        }).countDocuments()

       return res.status(200).send({
          success: 1,
          message: "Company User List",
          UsersList: get_user_detail_new,
          total_userCount: get_users_count,
          total_page_count,
          all_user_count: get_count_all_user,
          online_user_count: online_user_count,
          offline_user_count: offline_user_count
        });
      }else{
        console.log("else called")
        let search: any = data.search?.toString()
        let tmp_filter: any = data.filter
        let filter: any = parseInt(tmp_filter)
        let find_query: any;
        if (search) {
          find_query = {
            $or: [
              {
                first_name: {
                  $regex: search,
                  $options: "i"
                }
              },
              {
                last_name: {
                  $regex: search,
                  $options: "i"
                }
              },
              {
                emailAddress: {
                  $regex: search,
                  $options: "i"
                }
              },
              {
                enterprise_name: {
                  $regex: search,
                  $options: "i"
                }
              },
              {
                user_name: {
                  $regex: search,
                  $options: "i"
                }
              },
            ],
            is_deleted:0
          }
        } else {
          find_query = {
            is_deleted:0
          }
        }
        if (filter == 1) {
          find_query.is_online = 1
        } else if (filter == 2) {
          find_query.is_online = 0
        } else {
  
        }
        //console.log("find_query",find_query)
        let limit: any = parseInt(size)
        let skip: any = (page - 1) * size;
        console.log("find_query",find_query,limit,skip)
        let get_user_detail_new: any = await user.aggregate([
          {
            $lookup: {
              from: "enterprises",
              localField: "eid",
              foreignField: "_id",
              as: "enterprise_detail"
            }
          },
          {
            $unwind: "$enterprise_detail"
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              MobileNumber: 1,
              user_name:1,
              keep_message:1,
              is_online: 1,
              user_image: 1,
              is_deleted:1,
              createdAt: 1,
              enterprise_name: "$enterprise_detail.enterprise_name"
            }
          },
          {
            $match: find_query
          },
          {
            $lookup: {
              from: "user_tokens",
              localField: "_id",
              foreignField: "uid",
              pipeline: [{
                $match: {
                  device_id: { $ne: "" },
                  device_name: { $ne: "" },
                  osversion: { $ne: 0 }
                }
              },
              {
                $sort: {
                  createdAt: -1
                }
              },
              {
                $project: {
                  _id: 1,
                  device_os_version: 1,
                  device_name: 1,
                  login_Time: 1,
                  osversion: 1,
                  device_id: 1,
                  push_token: 1,
                  apns_push_token: 1,
                  // token: 1,
                  // refresh_token: 1
                }
              }],
              as: "users_login_devices"
            }
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              MobileNumber: 1,
              user_name:1,
              keep_message:1,
              is_online: 1,
              user_image: 1,
              userLogin_devices_count: {
                $size: "$users_login_devices"
              },
              userLogin_devices: "$users_login_devices",
              createdAt: 1,
              enterprise_name: 1
            }
          }
        ]).sort({ createdAt: -1 }).skip(skip).limit(limit);
  
        let get_users_count_aggregate: any = await user.aggregate([
          {
            $lookup: {
              from: "enterprises",
              localField: "eid",
              foreignField: "_id",
              as: "enterprise_detail"
            }
          },
          {
            $unwind: "$enterprise_detail"
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              MobileNumber: 1,
              is_online: 1,
              is_deleted:1,
              user_image: 1,
              createdAt: 1,
              enterprise_name: "$enterprise_detail.enterprise_name"
            }
          },
          {
            $match: find_query
          },
          {
            $lookup: {
              from: "user_tokens",
              localField: "_id",
              foreignField: "uid",
              pipeline: [{
                $match: {
                  device_id: { $ne: "" },
                  device_name: { $ne: "" },
                  osversion: { $ne: 0 }
                }
              },
              {
                $sort: {
                  createdAt: -1
                }
              },
              {
                $project: {
                  _id: 1,
                  device_os_version: 1,
                  device_name: 1,
                  login_Time: 1,
                  osversion: 1
                }
              }],
              as: "users_login_devices"
            }
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              MobileNumber: 1,
              is_online: 1,
              user_image: 1,
              userLogin_devices_count: {
                $size: "$users_login_devices"
              },
              userLogin_devices: "$users_login_devices",
              createdAt: 1,
              enterprise_name: 1
            }
          }
        ])
        let get_users_count: any = get_users_count_aggregate.length;
        let total_page_count: any = Math.ceil(get_users_count / size);
  
        let count_users_aggregate: any = await user.aggregate([
          {
            $match:{
              is_deleted:0
            }
          },
          {
            $lookup: {
              from: "user_tokens",
              localField: "_id",
              foreignField: "uid",
              pipeline: [{
                $match: {
                  device_id: { $ne: "" },
                  device_name: { $ne: "" }
                }
              }],
              as: "users_login_devices"
            }
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              sipDomain: 1,
              subscriberActivate: 1,
              MobileNumber: 1,
              is_online: 1,
              user_image: 1,
              endpointNumber: 1,
              userLogin_devices_count: {
                $size: "$users_login_devices"
              },
              userLogin_devices: "$users_login_devices",
              createdAt: 1
            }
          },
          {
            $lookup: {
              from: "enterprises",
              localField: "eid",
              foreignField: "_id",
              as: "enterprise_detail"
            }
          },
          {
            $unwind: "$enterprise_detail"
          },
          {
            $project: {
              _id: 1,
              eid: 1,
              first_name: 1,
              last_name: 1,
              emailAddress: 1,
              sipDomain: 1,
              subscriberActivate: 1,
              MobileNumber: 1,
              is_online: 1,
              user_image: 1,
              userLogin_devices_count: 1,
              userLogin_devices: 1,
              createdAt: 1,
              endpointNumber: 1,
              enterprise_name: "$enterprise_detail.enterprise_name"
            }
          }
        ])
  
        let get_count_all_user: any = count_users_aggregate.length;
  
        let online_user_count: any = count_users_aggregate.filter((item: any) => item.is_online == 1).length;
  
        let offline_user_count: any = count_users_aggregate.filter((item: any) => item.is_online == 0).length;
  
        return res.status(200).send({
          success: 1,
          message: "Company User List",
          UsersList: get_user_detail_new,
          total_userCount: get_users_count,
          total_page_count,
          all_user_count: get_count_all_user,
          online_user_count: online_user_count,
          offline_user_count: offline_user_count
        });
      }
  } catch (error) {
    //console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getUserDetailUid = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let get_uid: any = req.body.uid
    if(get_uid == undefined){
      return res.status(403).send({
        success: 0,
        message: "User ID is Mandatory"
      });
    }
  
    if(!mongoose.Types.ObjectId.isValid(get_uid)){
      return res.status(403).send({
        success: 0,
        message: "User ID is Invalid"
      });
    }
      let get_users: any = await user.findOne({
        _id: get_uid,
        is_deleted:0
      }).select("eid user_image is_online first_name last_name emailAddress MobileNumber user_name keep_message")
      if (get_users == null) {
       return res.status(404).send({
          success: 0,
          message: "User not Exists",
        });
      } 

      return res.status(200).send({
        success: 1,
        message: "User Detail.",
        UserDetail: get_users
      });
     
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const editUserbyUid = async (req: Request, res: Response, next: NextFunction) => {
  try {
    upload(req, res, async (error) => {
      if (!req?.files) {
        res.status(404).send({
          success: 0,
          message: "File not found",
        });
        return;
      }
      if (error) {
        if (error instanceof multer.MulterError) {
          let create_message: any = error.field + " " + error.message
          res.status(500).send({
            success: 0,
            message: create_message,
          });
        } else {
          res.status(500).send({
            success: 0,
            message: error.message,
          });
        }
        return;
      }
      let data: any = req.body
      let uid: any = data.uid
      let emailAddress: any = data.emailAddress;
      let user_name:any = data.user_name
      if (!uid) {
        return res.status(403).send({
          success: 0,
          message:
            "uid is mandatory",
        });
      }

      if (!data.first_name) {
        return res.status(403).send({
          success: 0,
          message:
            "first_name is mandatory",
        });
      }
      if (!data.last_name) {
        return res.status(403).send({
          success: 0,
          message:
            "last_name is mandatory",
        });
      }

      if (!data.emailAddress) {
        return res.status(403).send({
          success: 0,
          message:
            "emailAddress is mandatory",
        });
      }
      if (!data.MobileNumber) {
        return res.status(403).send({
          success: 0,
          message:
            "MobileNumber is mandatory",
        });
      }
      if (!data.keep_message) {
        return res.status(403).send({
          success: 0,
          message:
            "keep_message is mandatory",
        });
      }
      if (!data.user_image == undefined) {
        return res.status(403).send({
          success: 0,
          message:
            "user_image is mandatory",
        });
      }
      if (!REGEXP.USER.first_name.test(data.first_name)) {
        return res.status(403).send({
          success: 0,
          message:
            "first_name Id is invalid",
        });
      }

      if (!REGEXP.USER.last_name.test(data.last_name)) {
        return res.status(403).send({
          success: 0,
          message:
            "last_name is invalid",
        });
      }
      if (!REGEXP.COMMON.BOOLEAN_STRING_REGEX.test(data.keep_message)) {
        return res.status(403).send({
          success: 0,
          message:
            "keep_message is invalid",
        });
      }

      // if (!REGEXP.COMMON.EMAIL.test(data.emailAddress)) {
      //   return res.status(403).send({
      //     success: 0,
      //     message:
      //       "Email Address is invalid",
      //   });
      // }

      if(!mongoose.Types.ObjectId.isValid(uid)){
        return res.status(403).send({
          success: 0,
          message:
            "uid is invalid",
        });
      }
        let check_user: any = await user.findOne({
          _id: uid,
          is_deleted:0
        })
        if(!check_user){
          return res.status(404).send({
            success: 0,
            message: "User Not Found",
          });
        }
          // let check_email_tmp: any = await EmailValidation(emailAddress);
          // if(!check_email_tmp){
          //   return res.status(409).send({
          //     success: 0,
          //     message: "Please Enter Valid Email",
          //   });
          // }
            let check_user_mobile: any = await user.findOne({
              MobileNumber: data.MobileNumber,
              _id: { $ne: uid },
              is_deleted:0
            })
            if (check_user_mobile) {
              return res.status(409).send({
                success: 0,
                message: "User With This MobileNumber Already Exists",
              });
            }
            let check_email: any = await user.findOne({
              emailAddress: emailAddress,
              _id: { $ne: uid },
              is_deleted:0
            })
            if (check_email) {
              return res.status(409).send({
                success: 0,
                message: "User Email Already Exists",
              });
            }
              let new_data: any = req.body
              //console.log("new_data",new_data)
              let files_detail: any = req?.files;
              let image_url: any = new_data.user_image
              if (files_detail !== undefined && files_detail.file && files_detail.file[0]?.path) {
                let myUrl = files_detail.file[0]?.path
                myUrl = myUrl.replace("../uploads", "uploads");
                image_url = myUrl
                let temp_url_path: any = files_detail.file[0]?.path
                let get_file_name: any = files_detail.file[0].filename.split("/")
                let name: any = get_file_name[3]
                let name_split: any = name.split(".")
                let final_name: any = name_split[0]
                let folder_nm: any = get_file_name[2]
                let thumbnail_nm: string = '../uploads/' + folder_nm + '/thumbnails__' + final_name + '.png';
                console.log("thumbnail_nm", thumbnail_nm)
                if (files_detail.file[0].mimetype.includes("image/")) {
                  sharp.cache({ files: 0 })
                  const data = await sharp(temp_url_path)
                  data.metadata()
                    .then(function (metadata: any) {
                      return data
                        .toFormat('png', { palette: true })
                        .resize(Math.round(metadata?.width / (metadata?.width * 0.01)))
                        .toFile(thumbnail_nm)
                    })
                }
              }

              let convert_first_name = new_data.first_name
              let firstCharCode: any = new_data.first_name.charCodeAt(0);
              if (firstCharCode >= 65 && firstCharCode <= 90 || firstCharCode >= 97 && firstCharCode <= 122) {
                convert_first_name = new_data.first_name.charAt(0).toUpperCase() + new_data.first_name.slice(1);
              }
              let upate_user_detail: any = await user.findOneAndUpdate({
                _id: uid,
                is_deleted:0
              },
                {
                  first_name: convert_first_name,
                  last_name: new_data.last_name,
                  emailAddress: new_data.emailAddress,
                  MobileNumber: new_data.MobileNumber,
                  keep_message: new_data.keep_message,
                  user_image: image_url,
                  user_name:user_name
                },
                {
                  new: true,
                  runValidators: true
                })
                await emitHandler("send_update_user", {
                  uid: uid,
                  user_image: image_url,
                  first_name: convert_first_name,
                  last_name: new_data.last_name,
                  cid: upate_user_detail.eid,
                });
                
              // let deleted_deices: any = await user_tokens.deleteMany({
              //   uid: upate_user_detail._id
              // }, {
              //   runValidators: true,
              //   new: true
              // })   

              return res.status(201).send({
                success: 1,
                message: "User Detail Updated Successfully",
                UserDetail: upate_user_detail
              });
    })
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const deleteUserById = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let uid: any = req.body.uid
    if(uid == undefined){
     return res.status(403).send({
        success: 0,
        message: "Uid is Mandatory.",
      });
    }

    if(!mongoose.Types.ObjectId.isValid(uid)){
      return res.status(403).send({
        success: 0,
        message: "Uid is Invalid.",
      });
    }

      let check_user: any = await user.findOne({
        _id: uid,
        is_deleted:0
      })

      if(check_user == null){
        return res.status(404).send({
          success: 0,
          message: "User Not Found",
        });
      }

       await emitHandler("authentication_fail", {
          uid: check_user._id,
          type: MESSAGE.AUTH_FAIL_TYPE.DELETEBYADMIN,
          device_id: null,
        });

        let deleted_user: any = await user.findOneAndUpdate({
          _id: uid,
          is_deleted:0
        },{
          is_deleted:1
        })
        let deleted_deices: any = await user_tokens.deleteMany(
          {
            uid: uid,
          },
          {
            runValidators: true,
            new: true,
          }
        );
       return res.status(200).send({
          success: 1,
          message: "Delete User Successfully",
          userDetail: deleted_user
        });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getUserConverationData = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let cid: any = user_detail?.eid

    let create_uid = new mongoose.Types.ObjectId(uid)
    let create_uid_String = uid.toString();
    let create_cid = new mongoose.Types.ObjectId(cid)

    let get_detail: any[] = await user.aggregate([
      {
        $match: {
          _id: { $ne: create_uid },
          eid: create_cid,
          is_deleted: 0,
          isguest: { $ne: 1 },
          conversation_deleted_users: { $nin: [create_uid_String] }
        }
      },
      {
        $lookup: {
          from: "conversations",
          localField: "_id",
          foreignField: "sender_id",
          pipeline: [{
            $match: {
              receiver_id: create_uid,
              is_deleted: 0,
              delete_message_users: { $ne: create_uid_String },
              message_type: { $ne: 3 }
            }
          },
          {
            $sort: {
              createdAt: -1
            }
          },
          { $limit: 1 }
          ],
          as: "recived_message"
        },
      },
      {
        $lookup: {
          from: "conversations",
          localField: "_id",
          foreignField: "receiver_id",
          pipeline: [{
            $match: {
              sender_id: create_uid,
              is_deleted: 0,
              delete_message_users: { $ne: create_uid_String },
              message_type: { $ne: 3 }
            }
          },
          {
            $sort: {
              createdAt: -1
            }
          },
          { $limit: 1 }
          ],
          as: "sended_message"
        },
      },
      {
        $lookup: {
          from: "conversations",
          localField: "_id",
          foreignField: "sender_id",
          pipeline: [{
            $match: {
              receiver_id: create_uid,
              is_deleted: 0,
              delivery_type: { $ne: 3 },
              message_type: { $ne: 3 }
            }
          },
          ],
          as: "recived_message_unread"
        }
      },
      {
        $addFields: {
          message_data: {
            $concatArrays: ["$recived_message", "$sended_message"]
          },
          block_by: 0,
          description: "",
          isGroup: 0,
          isReported: 0,
          istyping: 0,
          name: { $concat: ["$first_name", " ", "$last_name"] },
        }
      },
      {
        $project: {
          _id: 1,
          name: 1,
          cid: "$eid",
          user_extension: 1,
          image: "$user_image",
          is_online: 1,
          last_seen: "$updatedAt",
          message_data: 1,
          block_by: 1,
          description: 1,
          isGroup: 1,
          isReported: 1,
          istyping: 1,
          sipDomain: "$sipDomain",
          endpointNumber: "$endpointNumber",
          unread_msg_count: {
            $size: "$recived_message_unread"
          }
        }
      },
      {
        $unwind: {
          path: "$message_data",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $sort: { "message_data.createdAt": -1 }
      },
      {
        $group: {
          _id: "$_id",
          name: { $first: "$name" },
          cid: { $first: "$cid" },
          user_extension: { $first: "$user_extension" },
          image: { $first: "$image" },
          is_online: { $first: "$is_online" },
          last_seen: { $first: "$last_seen" },
          message_data: { $first: "$message_data" },
          block_by: { $first: "$block_by" },
          description: { $first: "$description" },
          isGroup: { $first: "$isGroup" },
          isReported: { $first: "$isReported" },
          istyping: { $first: "$istyping" },
          sipDomain: { $first: "$sipDomain" },
          endpointNumber: { $first: "$endpointNumber" },
          unread_msg_count: { $first: "$unread_msg_count" }
        }
      },
      {
        $addFields: {
          last_message_time: "$message_data.createdAt",
          last_message: "$message_data.message",
          last_media_type: "$message_data.media_type",
          last_message_sender_id:"$message_data.sender_id"
        }
      },
      {
        $lookup: {
          from: "pinned_conversations",
          localField: "_id",
          foreignField: "pin_to",
          pipeline: [{
            $match: {
              pin_by: create_uid,
              pin_status: 1
            }
          },
          ],
          as: "pinned_detail"
        }
      },
      {
        $unwind: {
          path: "$pinned_detail",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "user_blocks",
          localField: "_id",
          foreignField: "block_id",
          pipeline: [{
            $match: {
              block_by: create_uid
            }
          },
          ],
          as: "blocke_user"
        }
      },
      {
        $lookup: {
          from: "user_blocks",
          localField: "_id",
          foreignField: "block_by",
          pipeline: [{
            $match: {
              block_id: create_uid
            }
          },
          ],
          as: "isblocked_by_reciver"
        }
      },
      {
        $lookup: {
          from: "notification_setting_users",
          localField: "_id",
          foreignField: "notification_mute_id",
          pipeline: [{
            $match: {
              uid: create_uid,
              notification_mute_type: { $ne: 4 },
              isgroup: 0
            }
          },
          ],
          as: "mute_detail"
        }
      },
      {
        $lookup: {
          from: "conversations",
          localField: "_id",
          foreignField: "sender_id",
          pipeline: [{
            $match: {
              receiver_id: create_uid,
              message_type: { $ne: 3 },
            }
          },
          {
            $sort: {
              createdAt: -1
            }
          },
          { $limit: 1 }
          ],
          as: "recived_message_deleted"
        },
      },
      {
        $lookup: {
          from: "conversations",
          localField: "_id",
          foreignField: "receiver_id",
          pipeline: [{
            $match: {
              sender_id: create_uid
            }
          },
          {
            $sort: {
              createdAt: -1
            }
          },
          { $limit: 1 }
          ],
          as: "sended_message_deleted"
        },
      },
      {
        $addFields: {
          message_data_delete: {
            $concatArrays: ["$recived_message_deleted", "$sended_message_deleted"]
          },
          isblocked_by_reciver: {
            $size: "$isblocked_by_reciver"
          },
          isBlocked: {
            $size: "$blocke_user"
          },
          ismute: {
            $size: "$mute_detail"
          },
          mute_type: {
            $cond:
            {
              if: { $gt: [{ $size: "$mute_detail" }, 0] },
              then: { $first: "$mute_detail.notification_mute_type" },
              else: 4
            }
          }
        }
      },
      {
        $unwind: "$message_data_delete"
      },
      {
        $sort: { "message_data_delete.createdAt": -1 }
      },
      {
        $group: {
          _id: "$_id",
          name: { $first: "$name" },
          cid: { $first: "$cid" },
          user_extension: { $first: "$user_extension" },
          image: { $first: "$image" },
          is_online: { $first: "$is_online" },
          last_seen: { $first: "$last_seen" },
          message_data: { $first: "$message_data" },
          message_data_delete: { $first: "$message_data_delete" },
          block_by: { $first: "$block_by" },
          description: { $first: "$description" },
          isGroup: { $first: "$isGroup" },
          isReported: { $first: "$isReported" },
          istyping: { $first: "$istyping" },
          sipDomain: { $first: "$sipDomain" },
          endpointNumber: { $first: "$endpointNumber" },
          unread_msg_count: { $first: "$unread_msg_count" },
          last_message_time: { $first: "$last_message_time" },
          last_message: { $first: "$last_message" },
          last_media_type: { $first: "$last_media_type" },
          last_message_sender_id:{$first:"$last_message_sender_id"},
          isblocked_by_reciver: { $first: "$isblocked_by_reciver" },
          isBlocked: { $first: "$isBlocked" },
          ismute: { $first: "$ismute" },
          mute_type: { $first: "$mute_type" }
        }
      },
      {
        $project: {
          _id: 1,
          name: 1,
          cid: 1,
          user_extension: 1,
          image: 1,
          is_online: 1,
          last_seen: 1,
          block_by: 1,
          description: 1,
          isGroup: 1,
          isReported: 1,
          istyping: 1,
          last_message_time: { $ifNull: ["$last_message_time", "$message_data_delete.createdAt"] },
          last_message: 1,
          last_media_type: 1,
          last_message_sender_id:{
            $ifNull: ["$last_message_sender_id", null]
          },
          unread_msg_count: 1,
          pintime: { $ifNull: ["$pinned_detail.pin_time", null] },
          ispin: { $ifNull: ["$pinned_detail.pin_status", 0] },
          isBlocked: 1,
          isblocked_by_reciver: 1,
          createdAt: 1,
          ismute: 1,
          mute_type: 1,
          sipDomain: 1,
          endpointNumber: 1,
          isAdmin: { $ifNull: ["$Group_member_detail.is_admin", 0] },
          is_admin_send_message: { $ifNull: ["$Group_member_detail.is_admin", 0] }
        }
      },
    ]).sort({
      last_message_time: -1
    })

    let get_group_detail = await group.aggregate([
      {
        $sort: {
          createdAt: -1
        }
      },
      {
        $match: {
          cid: create_cid,
          is_deleted: 0,
          group_users: { $in: [create_uid_String] },
          group_leave_members: { $nin: [create_uid] }
        }
      },
      {
        $lookup: {
          from: "group_conversations",
          localField: "_id",
          foreignField: "group_id",
          pipeline: [
            {
              $match: {
                is_deleted: 0,
                delete_message_users: { $ne: create_uid_String },
                message_type: { $ne: 3 },
              }
            },
            {
              $sort: {
                createdAt: -1
              }
            },
            {
              $limit: 1
            }
          ],
          as: "group_messages"
        }
      },
      {
        $lookup: {
          from: "group_message_status",
          localField: "_id",
          foreignField: "group_id",
          pipeline: [
            {
              $match: {
                receiver_id: uid,
                delivery_type: { $ne: 3 },
                message_type: { $ne: 3 }
              }
            },
          ],
          as: "group_messages_unread"
        }
      },
      {
        $lookup: {
          from: "notification_setting_users",
          localField: "_id",
          foreignField: "notification_mute_id",
          pipeline: [{
            $match: {
              uid: create_uid,
              notification_mute_type: { $ne: 4 },
              isgroup: 1
            }
          },
          ],
          as: "mute_detail"
        }
      },
      {
        $unwind: {
          path: "$group_messages",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $addFields: {
          block_by: 0,
          user_extension: "",
          isGroup: 1,
          isReported: 0,
          isBlocked: 0,
          istyping: 0,
          is_online: 0,
          sipDomain: "",
          endpointNumber: "",
          isblocked_by_reciver: 0,
          last_seen: null,
          last_message_time: "$group_messages.createdAt",
          last_message: "$group_messages.message",
          last_media_type: "$group_messages.media_type",
          last_message_sender_id:"$group_messages.sender_id",
          mute_type: {
            $cond:
            {
              if: { $gt: [{ $size: "$mute_detail" }, 0] },
              then: { $first: "$mute_detail.notification_mute_type" },
              else: 4
            }
          },
          ismute: {
            $size: "$mute_detail"
          }
        }
      },
      {
        $lookup: {
          from: "pinned_conversations",
          localField: "_id",
          foreignField: "pin_to",
          pipeline: [{
            $match: {
              pin_by: create_uid,
              pin_status: 1
            }
          },
          ],
          as: "pinned_detail"
        }
      },
      {
        $unwind: {
          path: "$pinned_detail",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "group_members",
          localField: "_id",
          foreignField: "group_id",
          pipeline: [
            {
              $match: {
                member_id: create_uid
              }
            },
            { $limit: 1 }
          ],
          as: "Group_member_detail"
        }
      },
      {
        $unwind: {
          path: "$Group_member_detail",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $project: {
          _id: 1,
          name: "$group_name",
          cid: "$cid",
          description: "$description",
          image: "$group_image",
          block_by: 1,
          user_extension: 1,
          isGroup: 1,
          isReported: 1,
          isBlocked: 1,
          istyping: 1,
          is_online: 1,
          last_seen: 1,
          sipDomain: 1,
          endpointNumber: 1,
          last_message_time: {
            $ifNull: ["$last_message_time", "$createdAt"]
          },
          last_message: 1,
          last_media_type: 1,
          last_message_sender_id:{
            $ifNull: ["$last_message_sender_id", null]
          },
          unread_msg_count: {
            $size: "$group_messages_unread"
          },
          pintime: { $ifNull: ["$pinned_detail.pin_time", null] },
          ispin: { $ifNull: ["$pinned_detail.pin_status", 0] },
          isblocked_by_reciver: 1,
          createdAt: 1,
          ismute: 1,
          mute_type: 1,
          isAdmin: { $ifNull: ["$Group_member_detail.is_admin", 0] },
          is_admin_send_message: 1
        }
      }
    ]).sort({
      last_message_time: -1
    })

    let sidebarData_tmp: any[] = get_detail.concat(get_group_detail);
    let get_pinnde_arr: any[] = sidebarData_tmp.filter((item) => item.ispin == 1)
    let get_normal_arr: any[] = sidebarData_tmp.filter((item) => item.ispin == 0)
    get_pinnde_arr.sort((a, b) => {
      const timeA = a.pintime || 0;
      const timeB = b.pintime || 0;
      return timeB - timeA; // Sort in descending order
    });

    // Sort get_normal_arr based on last_message_time
    get_normal_arr.sort((a, b) => {
      const timeA = a.last_message_time || 0;
      const timeB = b.last_message_time || 0;
      return timeB - timeA; // Sort in descending order
    });
    // get_pinnde_arr = _(get_pinnde_arr).orderBy("pintime", "desc").value()
    // get_normal_arr = _(get_normal_arr).orderBy("last_message_time", "desc").value()
    let sidebarData_new: any[] = get_pinnde_arr.concat(get_normal_arr);

    const groupsData = await group.find({
      is_deleted: 0,
      group_users: uid,
      group_leave_members: { $nin: [create_uid] }
    }).distinct("_id")

    await group_message_status.find({
      receiver_id: create_uid,
      delivery_type: 1
    })

    await group_message_status.updateMany({
      receiver_id: create_uid,
      delivery_type: 1
    }, {
      delivery_type: 2
    })

    // let group_fincCondition = {
    //   is_deleted: 0,
    //   delete_message_users: { $ne: uid },
    //   message_type: { $ne: 3 },
    //   group_id: { $in: groupsData },
    // }

    // let UserGroupChatData = await group_conversation.find(group_fincCondition).populate({
    //   path: "sender_id",
    //   model: "user",
    //   select: "first_name last_name user_extension"
    // })

    let UserGroupChatData: any = await group_conversation.aggregate([
      {
        $match: {
          is_deleted: 0,
          delete_message_users: { $ne: uid },
          message_type: { $ne: 3 },
          group_id: { $in: groupsData }
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "sender_id",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                first_name: 1,
                last_name: 1
              }
            }
          ],
          as: "group_message_sender_detail"
        }
      },
      {
        $unwind: "$group_message_sender_detail"
      },
      {
        $project: {
          _id: 1,
          originalName: 1,
          message: 1,
          message_caption: 1,
          message_type: 1,
          media_type: 1,
          delivery_type: 1,
          reply_message_id: 1,
          schedule_time: 1,
          block_message_users: 1,
          delete_message_users: 1,
          is_deleted: 1,
          message_reaction_users: 1,
          message_dissapear_time: 1,
          is_edited: 1,
          cid: 1,
          group_id: 1,
          sender_id: "$group_message_sender_detail",
          createdAt: 1,
          updatedAt: 1,
          __v: 1
        }
      }
    ])


    await conversation.updateMany({
      is_deleted: 0,
      receiver_id: create_uid,
      delivery_type: 1,
      delete_message_users: { $ne: create_uid }
    }, {
      delivery_type: 2
    })


    let findconditon = {
      is_deleted: 0,
      delete_message_users: { $ne: uid },
      $or: [
        { receiver_id: uid },
        { sender_id: uid },
      ],
    }

    let userChatData = await conversation.find(findconditon)



    let UserProfileDetail: any = await user.findOne({
      _id: uid,
      is_deleted:0
    }).select("first_name last_name user_image emailAddress MobileNumber")

    res.send({
      success: 1,
      message: "User Convartion Data",
      sideBarData: sidebarData_new,
      userChatData,
      UserGroupChatData,
      userChatDataLength: userChatData.length,
      UserGroupChatDataLength: UserGroupChatData.length,
      UserProfileDetail
    })
  } catch (error) {
    res.status(401).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getuserlist = async (req: Request, res: Response, next: NextFunction) => {
  console.log("contact/list api called")
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let eid: any = user_detail?.eid

    const UserData = await user.find({
      eid: eid,
      _id: { $ne: uid },
      is_deleted:0
    }).select("first_name last_name user_image MobileNumber").sort({ first_name: 1 })
    res.status(200).send({
      success: 1,
      message: "User List",
      UserData
    });

  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }

}
const getblockuserlist = async (req: Request, res: Response, next: NextFunction) => {
  console.log("block/list api called")
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let eid: any = user_detail?.eid

    const UserData = await user_block.find({
      block_by: uid
    })

    let get_block_user_list: any = await user_block.aggregate([
      {
        $match: {
          block_by: uid,
          cid: eid
        }
      },
      {
        $lookup: {
          from: "users",
          localField: "block_id",
          foreignField: "_id",
          as: "block_user_Detail"
        }
      },
      {
        $unwind: "$block_user_Detail"
      },
      {
        $project: {
          uid: "$block_user_Detail._id",
          cid: 1,
          first_name: "$block_user_Detail.first_name",
          last_name: "$block_user_Detail.last_name",
          user_image: "$block_user_Detail.user_image"
        }
      }
    ])

    res.status(200).send({
      success: 1,
      message: "Block User List",
      get_block_user_list
    });

  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }

}
const userLogout = async (req: Request, res: Response, next: NextFunction) => {
  try {
    //console.log("userLogout api called",req.body)
    var token = req.header("Authorization");
    //console.log("userLogout api called token",token)
    let countryCode: any = req.body.countryCode
    const user_detail = await User_token(token);
    var uid = user_detail?.uid;
    let isSecondary = await user_tokens.findOne({
      token:token,
      uid:uid,
      is_primary:false
    })
    let log = await user_tokens.findOneAndRemove({
      token: token,
      uid: uid,
    });
    if (isSecondary) {
      emitHandler("secondary_devices_onlogout", {
        uid: uid,
      });
    }
    if (!log) {
      return res.status(400).send({
        success: 0,
        message: "User not found"
      });
    }
    const check_user = await user.findOne({_id:uid,is_deleted:0});
    if (!check_user) {
      return res.status(400).send({
        success: 0,
        message: "User not found"
      });
    }
    const provisioninglogObj = {
      userId: uid,
      platform: log?.osversion,
      time: new Date(),
      ip: req.headers['x-forwarded-for'] || req.socket.remoteAddress?.replace("::ffff:", '') || req.ip?.replace("::ffff:", ''),
      activity: "User Logout Successfully",
      devicename: log?.device_name,
      email: check_user.emailAddress,
      mobilenumber: check_user.MobileNumber,
      activity_type: PROVISIONLOG.ACTVITY_TYPE.SUCCESSFULLY_LOGOUT,
      countryCode: countryCode
    }

    const newprovisioninglog = await provisioninglog.create(provisioninglogObj)

    res.send({
      success: 1,
      message: "Logout Successfully",
      logoutUser: log
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const RemoveLoginSession = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let token_id: any = req.params.token_id
    if (!mongoose.Types.ObjectId.isValid(token_id)) {
      return res.status(400).send({
        success: 0,
        message: "Invalid ObjectId"
      });
    }
    let check_token_data: any = await user_tokens.findById({
      _id: token_id
    })
    if (!check_token_data) {
      return res.status(400).send({
        success: 0,
        message: "Device Detail not Found"
      });
    }
    await emitHandler("authentication_fail", {
      uid: check_token_data.uid,
      type:MESSAGE.AUTH_FAIL_TYPE.DELETE,
      device_id:check_token_data.device_id
    });
    let deleted_device_detail: any = await user_tokens.findByIdAndDelete({
      _id: token_id
    }, {
      new: true
    })

    return res.status(200).send({
      success: 1,
      message: "Device Session Removed Successfully",
      Device_detail: deleted_device_detail
    });
  } catch (error) {
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getDashboardDEtail = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token_admin(token);

    let uid: any = user_detail?.uid

    let get_user_type: any = await user_admin.findById({
      _id: uid
    })

    if (!get_user_type) {
      return res.status(404).send({
        success: 0,
        message: "User Not Exists"
      })
    }

    let user_type: Number = get_user_type.user_type;
    let accessgroup_id: any = get_user_type.accessgroup

    let respons_obj: { [key: string]: any } = {};

    if (user_type === 1) {
      let get_enterprise: any = await enterprise.find({
        is_deleted: 0
      }).countDocuments();

      respons_obj.total_enterprise = get_enterprise

      let get_enterprise_active: any = await enterprise.find({
        is_deleted: 0,
        status: "A",
      }).countDocuments();

      respons_obj.total_active_enterprise = get_enterprise_active

      let get_user_detail: any = await user.find({
        is_deleted: 0
      }).countDocuments();

      respons_obj.total_subscriber = get_user_detail

      let get_user_detail_active: any = await user.find({
        is_deleted: 0,
        subscriberActivate: "Y"
      }).countDocuments();

      respons_obj.total_active_subscriber = get_user_detail_active

      let get_enterprise_call_detail: any = await call_history.aggregate([
        {
          $sort: {
            createdAt: -1
          }
        },
        {
          $group: {
            _id: "$eid",
            enterprise_call: {
              $push: "$$ROOT"
            }
          }
        },
        {
          $lookup: {
            from: "enterprises",
            localField: "_id",
            foreignField: "_id",
            pipeline: [
              {
                $project: {
                  _id: 1,
                  enterprise_name: 1,
                  Logo: 1
                }
              }],
            as: "enterprise_detail"
          }
        },
        {
          $unwind: "$enterprise_detail"
        },
        {
          $project: {
            enterprise_calls: {
              $size: "$enterprise_call"
            },
            enterprise_name: "$enterprise_detail.enterprise_name",
            enterprise_image: "$enterprise_detail.Logo"
          }
        },
        {
          $sort: {
            enterprise_calls: -1
          }
        },
        {
          $limit: 5
        }
      ])

      let get_total_call: any = await call_history.find().countDocuments()
      let get_outgoing_call: any = await call_history.find(
        {
          direction: "Outgoing"
        }
      ).countDocuments()

      let get_incoming_call: any = await call_history.find(
        {
          direction: "Incoming"
        }
      ).countDocuments()

      let top_enterprise_calls_obj: { [key: string]: any } = {};
      top_enterprise_calls_obj.total_calls = get_total_call
      top_enterprise_calls_obj.all_calls = 0
      top_enterprise_calls_obj.inbound_calls = get_incoming_call
      top_enterprise_calls_obj.outbound_calls = get_outgoing_call
      top_enterprise_calls_obj.tollfree_calls = 0
      top_enterprise_calls_obj.international_calls = 0

      let enterprise_list_arr: any[] = [];
      enterprise_list_arr = get_enterprise_call_detail

      top_enterprise_calls_obj.Enterprise_list = enterprise_list_arr

      respons_obj.top_enterprise_calls = top_enterprise_calls_obj


      let top_subsciber_calls_obj: { [key: string]: any } = {};
      top_subsciber_calls_obj.total_calls = 28137
      top_subsciber_calls_obj.all_calls = 300
      top_subsciber_calls_obj.inbound_calls = 400
      top_subsciber_calls_obj.outbound_calls = 300
      top_subsciber_calls_obj.tollfree_calls = 300
      top_subsciber_calls_obj.international_calls = 200

      let subsciber_list_arr: any[] = [];
      subsciber_list_arr = [{
        subsciber_name: "Meresso Telecome",
        subsciber_image: "",
        subsciber_calls: 8167
      },
      {
        subsciber_name: "Hermonias Communication",
        subsciber_image: "uploads/image/photo_2024-01-19_18-33-43.jpg",
        subsciber_calls: 7246
      }, {
        subsciber_name: "Kameya Solution",
        subsciber_image: "",
        subsciber_calls: 5756
      },
      {
        subsciber_name: "Tremesko Tele communication",
        subsciber_image: "",
        subsciber_calls: 8167
      },
      {
        subsciber_name: "createca Solute",
        subsciber_image: "",
        subsciber_calls: 2944
      }]

      top_subsciber_calls_obj.subsciber_list = subsciber_list_arr

      respons_obj.top_subsciber_calls = top_subsciber_calls_obj
    } else if (user_type === 2) {

      let get_subadmin_permission: any = await accessgroup.findById({
        _id: accessgroup_id
      })

      if (get_subadmin_permission !== undefined && get_subadmin_permission !== null && get_subadmin_permission.dashboard_view == 1) {
        let get_enterprise: any = await enterprise.find({
          is_deleted: 0
        }).countDocuments();

        respons_obj.total_enterprise = get_enterprise

        let get_enterprise_active: any = await enterprise.find({
          is_deleted: 0,
          status: "A",
        }).countDocuments();

        respons_obj.total_active_enterprise = get_enterprise_active

        let get_user_detail: any = await user.find({
          is_deleted: 0
        }).countDocuments();

        respons_obj.total_subscriber = get_user_detail

        let get_user_detail_active: any = await user.find({
          is_deleted: 0,
          subscriberActivate: "Y"
        }).countDocuments();

        respons_obj.total_active_subscriber = get_user_detail_active

        let top_enterprise_calls_obj: { [key: string]: any } = {};
        top_enterprise_calls_obj.total_calls = 28137
        top_enterprise_calls_obj.all_calls = 2908
        top_enterprise_calls_obj.inbound_calls = 4800
        top_enterprise_calls_obj.outbound_calls = 3567
        top_enterprise_calls_obj.tollfree_calls = 1398
        top_enterprise_calls_obj.international_calls = 2800

        let enterprise_list_arr: any[] = [];
        enterprise_list_arr = [{
          enterprise_name: "Meresso Telecome",
          enterprise_image: "",
          enterprise_calls: 8167
        },
        {
          enterprise_name: "Hermonias Communication",
          enterprise_image: "uploads/image/photo_2024-01-19_18-33-43.jpg",
          enterprise_calls: 7246
        }, {
          enterprise_name: "Kameya Solution",
          enterprise_image: "",
          enterprise_calls: 5756
        },
        {
          enterprise_name: "Tremesko Tele communication",
          enterprise_image: "",
          enterprise_calls: 8167
        },
        {
          enterprise_name: "createca Solute",
          enterprise_image: "",
          enterprise_calls: 2944
        }]

        top_enterprise_calls_obj.Enterprise_list = enterprise_list_arr

        respons_obj.top_enterprise_calls = top_enterprise_calls_obj


        let top_subsciber_calls_obj: { [key: string]: any } = {};
        top_subsciber_calls_obj.total_calls = 28137
        top_subsciber_calls_obj.all_calls = 300
        top_subsciber_calls_obj.inbound_calls = 400
        top_subsciber_calls_obj.outbound_calls = 300
        top_subsciber_calls_obj.tollfree_calls = 300
        top_subsciber_calls_obj.international_calls = 200

        let subsciber_list_arr: any[] = [];
        subsciber_list_arr = [{
          subsciber_name: "Meresso Telecome",
          subsciber_image: "",
          subsciber_calls: 8167
        },
        {
          subsciber_name: "Hermonias Communication",
          subsciber_image: "uploads/image/photo_2024-01-19_18-33-43.jpg",
          subsciber_calls: 7246
        }, {
          subsciber_name: "Kameya Solution",
          subsciber_image: "",
          subsciber_calls: 5756
        },
        {
          subsciber_name: "Tremesko Tele communication",
          subsciber_image: "",
          subsciber_calls: 8167
        },
        {
          subsciber_name: "createca Solute",
          subsciber_image: "",
          subsciber_calls: 2944
        }]

        top_subsciber_calls_obj.subsciber_list = subsciber_list_arr

        respons_obj.top_subsciber_calls = top_subsciber_calls_obj
      } else {

      }

    }

    // let get_enterprise_call_detail:any = await call_history.aggregate([
    //   {
    //     $sort:{
    //       createdAt:-1
    //     }
    //   },
    //   {
    //     $group:{
    //       _id:"$from",
    //       user_call:{
    //         $push:"$$ROOT"
    //       }
    //     }
    //   },
    //   {
    //     $lookup: {
    //       from: "users",
    //       localField: "from",
    //       foreignField: "endpointNumber",
    //       pipeline:[
    //       {
    //         $project:{
    //           _id:1,
    //           enterprise_name:1,
    //           Logo:1
    //         }
    //       }],
    //       as: "user_detail"
    //     }
    //   },
    //   {
    //     $unwind:"$user_detail"
    //   },
    //   // {
    //   //   $project:{
    //   //     enterprise_calls: {
    //   //       $size: "$enterprise_call"
    //   //     },
    //   //     enterprise_name:"$enterprise_detail.enterprise_name",
    //   //     enterprise_image:"$enterprise_detail.Logo"
    //   //   }
    //   // },
    //   // {
    //   //   $sort:{
    //   //     enterprise_calls:-1
    //   //   }
    //   // },
    //   // {
    //   //   $limit:5
    //   // }
    // ])

    return res.status(200).send({
      success: 1,
      message: "Dashboaed Details",
      Dashboard_detail: respons_obj,
      //get_enterprise_call_detail:get_enterprise_call_detail
    });

  } catch (error) {
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const refreshaccesstoken = async (req: Request, res: Response, next: NextFunction) => {
  console.log("refreshaccesstoken api called", req.body.token)
  try {
    const token = req.body.token;
    if (!token) {
      return res.status(400).send({
        success: 0,
        message: "Token is missing",
      });
    }

    let decode_token: any;
    try {
      decode_token = jwt.decode(token);
    } catch (error) {
      console.error("Error decoding token:", error);
      return res.status(400).send({
        success: 0,
        message: "Invalid token",
      });
    }

    if (!decode_token) {
      return res.status(400).send({
        success: 0,
        message: "Invalid token",
      });
    }
    delete decode_token.iat;
    delete decode_token.exp;
    //console.log(decode_token, "decoded token");
    let uid: any = decode_token?.uid;

    let user_token_details: any = await user_tokens.findOne({
      refresh_token: token,
    });

    //console.log("user_token_details",user_token_details)

    if (user_token_details === undefined || user_token_details === null) {
      return res.status(401).send({
        success: 0,
        message: "Invalid Refresh Token",
      });
    }

    //const user_detail = await User_token_admin(token);

    // let eid:any = decode_token?.eid

    // //console.log("uid",uid)
    // let iv = Buffer.from(decode_token.iv, 'hex');
    // let encryptedText = Buffer.from(decode_token.encryptedData, 'hex');
    // let decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(key), iv);
    // let decrypted = decipher.update(encryptedText);
    // decrypted = Buffer.concat([decrypted, decipher.final()]);
    // let decrepted_token:any = decrypted.toString()

    //console.log("decrepted_token",decrepted_token)

    //   let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), ivmain);
    //  let encrypted = cipher.update(uid);
    //  encrypted = Buffer.concat([encrypted, cipher.final()]);
    //  let encrepted_token:any ={ iv: ivmain.toString('hex'), encryptedData: encrypted.toString('hex') };

    let new_objdata: any = {
      iv: decode_token.iv,
      encryptedData: decode_token.encryptedData,
    };

    // let decrepted_token:any =await decryptDart(new_objdata)
    //console.log("decrepted_token",decrepted_token)

    const token_new = jwt.sign(
      decode_token,
      config.key.secret_key,
      {
        expiresIn: "1d"
      }
    );
    //console.log("token_new",token_new)

    let updatedtoken: any = await user_tokens.findByIdAndUpdate(
      user_token_details._id,
      {
        token: token_new,
      },
      {
        new: true,
      }
    );

    //console.log("updatedtoken",updatedtoken)

    return res.status(200).send({
      success: 1,
      message: "Token Details",
      Token: token_new,
    });
  } catch (error) {
    //console.log(error);
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};
const sendPushtoApp = async (req: Request, res: Response, next: NextFunction) => {
  try {
    console.log("sendPushtoApp called", req.body)
    let data: any = req.body
    let sip_username: any = data.sip_username
    let caller_number: any = data.caller_number
    let caller_id: any = data.caller_id
    let call_type: any = 0
    let sip_domain: any;
    let isadroidfaild: any = 0
    let androidErrorCount: any = 0;
    let iosErrorCount: any = 0;
    let isiosfaild: any = 0


    const word = '@';
    //console.log(sip_username);
    if (sip_username.includes(word)) {
      let sip_usernameactual = sip_username.split(word);
      //console.log("sip username contails @. username after split: ");
      console.log(sip_usernameactual);
      let sip_tmp_name: any = sip_usernameactual[0].split(":");
      let sip_tmp_domain: any = sip_usernameactual[1];
      sip_username = sip_tmp_name[1];
      sip_domain = sip_tmp_domain
    }

    console.log(sip_username, "sip_username");
    console.log(sip_domain, "sip_domain");

    let get_from_user_detail: any = await user.findOne({
      endpointNumber: caller_number,
      sipDomain: sip_domain
    })

    if (sip_username !== undefined && sip_domain !== undefined
    ) {
      let get_user_detail: any = await user.findOne({
        endpointNumber: sip_username,
        sipDomain: sip_domain
      })

      //console.log("get_user_detail",get_user_detail)

      if (get_user_detail == null) {
        return res.status(403).send({
          success: 0,
          message: "Sip User Detail Not Found"
        });
      }

      let get_sip_tokens: any = await user_tokens.find({
        uid: get_user_detail._id,
        osversion: 1,
      })
      //console.log("get_sip_tokens",get_sip_tokens)
      if (get_sip_tokens.length > 0) {
        let push_tokens_detail: any[] = [];

        await Promise.all(get_sip_tokens.map(async (item: any) => {
          push_tokens_detail.push(item.push_token.toString())
        }));
        let title: any = "incoming Call";
        let body: any = sip_username.toString();
        let token: any[] = push_tokens_detail

        let tmp_caller_nm: any = ""
        if (get_from_user_detail !== null) {
          tmp_caller_nm = get_from_user_detail.first_name + " " + get_from_user_detail.last_name
        }
        let notification_data: any = {
          call_id: caller_id.toString(),
          caller_number: caller_number.toString(),
          caller_name: tmp_caller_nm.toString(),
          call_type: call_type.toString()
        }
        console.log("notification_data", notification_data)
        console.log("token", token)
        let sendpush_response_android: any = await sendPushNotification(title, body, token, notification_data);
        console.log("sendpush_response_android", sendpush_response_android)
        if (sendpush_response_android.failureCount > 0) {
          isadroidfaild = 1
          androidErrorCount = sendpush_response_android.failureCount
        }
      }
      let get_sip_tokens_ios: any = await user_tokens.find({
        uid: get_user_detail._id,
        osversion: 2
      })
      //console.log("get_sip_tokens_ios",get_sip_tokens_ios)
      // if (get_sip_tokens_ios.length > 0) {
      //   let push_tokens_detail: any[] = [];

      //   await Promise.all(get_sip_tokens_ios.map(async (item: any) => {
      //     push_tokens_detail.push(item.apns_push_token.toString())
      //   }));
      //   let title: any = "incoming Call";
      //   let body: any = sip_username.toString();
      //   let token: any[] = push_tokens_detail

      //   let tmp_caller_nm: any = ""
      //   if (get_from_user_detail !== null) {
      //     tmp_caller_nm = get_from_user_detail.first_name + " " + get_from_user_detail.last_name
      //   }
      //   let tmp_caller_extantion: any = 0
      //   if (get_from_user_detail !== null) {
      //     tmp_caller_extantion = parseInt(get_from_user_detail.endpointNumber);
      //   }
      //   let call_type_parse: any = parseInt(call_type);
      //   let uuid4: string = uuidv4();
      //   let notification_data: any = {
      //     "caller_number": caller_number.toString(),
      //     "call-id": caller_id.toString(),
      //     "session_id": uuid4.toString(),
      //     "call_type": call_type_parse,
      //     "caller_id": tmp_caller_extantion,
      //     "signal_type": "startCall",
      //     "caller_name": tmp_caller_nm.toString(),
      //     "call_opponents": caller_number.toString(),
      //     "user_info": caller_number.toString()
      //   }
      //   console.log("notification_data", notification_data)
      //   let sendpush_response_ios: any = await sendPushNotificationios(title, body, token, notification_data);
      //   //console.log("sendpush_response_ios",sendpush_response_ios.failed.length)
      //   if (sendpush_response_ios.failed.length > 0) {
      //     isiosfaild = 1
      //     iosErrorCount = sendpush_response_ios.failed.length
      //   }
      // }
      if (isiosfaild || isadroidfaild) {
        res.status(400).send({
          success: 0,
          message: "Send Push Not Working",
          AndroidFaildCount: androidErrorCount,
          IosFailCount: iosErrorCount
        });
      } else {
        res.status(200).send({
          success: 1,
          message: "Send Push Successfully"
        });
      }
    } else {
      res.status(401).send({
        success: 0,
        message: "Some Params Missing"
      });
    }
  } catch (error) {
    console.log("error internal", error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getContacts = async (req: Request, res: Response) => {
  console.log("/contacts api called")
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid;


    let contact_fetch = await user_contact.findOne({ uid: uid });
    let json_response_contacts: any[] = []
    if (contact_fetch !== null) {
      let contact_string: any = contact_fetch?.contacts;
      json_response_contacts = JSON.parse(contact_string)
    }

    return res.status(200).send({
      success: 1,
      message: "Successfully fetched User Contacts",
      data: json_response_contacts
    });
  } catch (err) {
    console.log("err", err)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};
const addUpdateContacts = async (req: Request, res: Response) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid;
    if (!uid) {
      return res.status(500).send({
        success: 0,
        message: "Internal Server Error",
      });
    }
    const data = req.body;
    const contacts = JSON.stringify(data.contacts)
    if (data.contacts === undefined) {
      res.status(400).send({
        success: 0,
        message: "contacts is mandotary",
      });
      return;
    }
    const isUserContactExists = await user_contact.findOne({ uid: uid });

    if (isUserContactExists) {
      const updatedUserContacts = await user_contact.findByIdAndUpdate(
        isUserContactExists._id,
        { contacts: contacts },
        {
          new: true,
        }
      );

      return res.status(200).send({
        success: 1,
        message: "Successfully updated User Contacts",
        data: updatedUserContacts,
      });
    } else {
      const newUserContact = await user_contact.create({
        uid: uid,
        contacts: contacts,
      });

      return res
        .status(200)
        .send({ success: 1, message: "Successfully store User Contacts", data: newUserContact });
    }
  } catch (err) {
    console.error(err);
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};
const addcdrlog = async (req: Request, res: Response, next: NextFunction) => {
  //console.log("cdr add api called",req.body)
  try {
    let data: any = req.body
    let from: any = data.from
    let to: any = data.to
    let call_duration: any = data.call_duration
    let call_time: any = data.call_time

    if (from == undefined) {
      return res.status(400).send({
        message: "from field is mandatory"
      })
    }

    if (to == undefined) {
      return res.status(400).send({
        message: "to field is mandatory"
      })
    }

    if (call_time == undefined) {
      return res.status(400).send({
        message: "call_time field is mandatory"
      })
    }

    //console.log("call_duration",call_duration)
    if (call_duration == undefined) {
      return res.status(400).send({
        message: "call_duration field is mandatory"
      })
    }

    let get_sipdomain_from: any = "";
    let get_pin_from: any = "";
    let get_sipdomain_to: any = "";
    let get_pin_to: any = "";
    const word = '@';
    //console.log(sip_username);
    if (from.includes(word)) {
      let from_split = from.split(word);
      get_sipdomain_from = from_split[1];
      get_pin_from = from_split[0];
      let remove_sip: any = get_pin_from.split(':')
      remove_sip = remove_sip[1];
      get_pin_from = remove_sip
      let remove_port_from_domain: any = get_sipdomain_from.split(":")
      let get_new_domain_from: any = remove_port_from_domain[0];
      get_sipdomain_from = get_new_domain_from
    }
    if (to.includes(word)) {
      let to_split = to.split(word);
      get_sipdomain_to = to_split[1];
      get_pin_to = to_split[0]
      let remove_sip_to: any = get_pin_to.split(':')
      remove_sip_to = remove_sip_to[1];
      get_pin_to = remove_sip_to
    }

    let get_enterprise_detail: any = await enterprise.findOne({
      sipDomain: get_sipdomain_from,
      is_deleted: 0
    })
    let eid_tmp: any = null;
    if (get_enterprise_detail !== null) {
      eid_tmp = get_enterprise_detail._id
    }


    let date_time = new Date(call_time * 1000).toISOString();
    //console.log("date_time",date_time)


    let call_end_time: any = new Date().toISOString()
    let startTime: any = moment(date_time, "YYYY-MM-DDTHH:mm:ss.sssZ").format("YYYY-MM-DD HH:mm:ss")
    let endTime: any = moment(call_end_time, "YYYY-MM-DDTHH:mm:ss.sssZ").format("YYYY-MM-DD HH:mm:ss")
    //console.log("startTime",startTime)
    let duration: any = moment.duration(moment(endTime).diff(moment(startTime)))
    var seconds: any = duration.asSeconds();

    let totalSeconds = seconds;
    let hours_tmp: any = Math.floor(totalSeconds / 3600);
    totalSeconds %= 3600;
    let minutes: any = Math.floor(totalSeconds / 60);
    let seconds_tmp: any = totalSeconds % 60;

    minutes = String(minutes).padStart(2, "0");
    hours_tmp = String(hours_tmp).padStart(2, "0");
    seconds_tmp = String(seconds_tmp).padStart(2, "0");
    let duration_time: any = hours_tmp + ":" + minutes + ":" + seconds_tmp;


    let get_from_user_detail: any = await user.findOne({
      sipDomain: get_sipdomain_from,
      endpointNumber: get_pin_from,
      is_deleted: 0
    })

    let from_user_name: any = "";
    let from_user_image: any = "";

    if (get_from_user_detail !== null) {
      from_user_name = get_from_user_detail.first_name + " " + get_from_user_detail.last_name
      from_user_image = get_from_user_detail.user_image
    }

    let get_to_user_detail: any = await user.findOne({
      sipDomain: get_sipdomain_from,
      endpointNumber: get_pin_to,
      is_deleted: 0
    })

    let to_user_name: any = "";
    let to_user_image: any = "";

    if (get_to_user_detail !== null) {
      to_user_name = get_to_user_detail.first_name + " " + get_to_user_detail.last_name
      to_user_image = get_to_user_detail.user_image
    }

    let create_cdr_obj: any = {
      eid: eid_tmp,
      from: get_pin_from,
      to: get_pin_to,
      sipDomain: get_sipdomain_from,
      duration: duration_time,
      call_time: date_time,
      ingressip: "",
      egressip: "",
      from_user_name: from_user_name,
      from_user_image: from_user_image,
      to_user_name: to_user_name,
      to_user_image: to_user_image
    }
    //console.log("create_cdr_obj",create_cdr_obj)

    let create_cdr: any = await call_history.create(create_cdr_obj)

    return res.status(200).send({
      success: 1,
      message: "Call Detail Stored Successfully",
      CallDetail: create_cdr
    });


  } catch (error) {
    //console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const addcdrlogNew = async (req: Request, res: Response, next: NextFunction) => {
  console.log("cdr add api called addcdrlogNew", req.body)
  try {
    let data: any = req.body
    let from: any = data.from
    let to: any = data.to
    let call_id: any = data.call_id
    let call_type: any = data.call_type
    let isadroidfaild: any = 0
    let androidErrorCount: any = 0;
    let iosErrorCount: any = 0;
    let isiosfaild: any = 0

    if (call_id == undefined) {
      return res.status(400).send({
        message: "call_id field is mandatory"
      })
    }

    if (from == undefined) {
      return res.status(400).send({
        message: "from field is mandatory"
      })
    }

    if (to == undefined) {
      return res.status(400).send({
        message: "to field is mandatory"
      })
    }

    if (call_type == undefined) {
      return res.status(400).send({
        message: "call_type field is mandatory"
      })
    }

    let check_call_exists: any = await call_history.findOne({
      call_id: call_id
    })

    if (check_call_exists !== null) {
      return res.status(400).send({
        message: "Call Already Exists in Db With this call_id."
      })
    }

    let get_sipdomain_from: any = "";
    let get_pin_from: any = "";
    let get_sipdomain_to: any = "";
    let get_pin_to: any = "";
    const word = '@';
    //console.log(sip_username);
    if (from.includes(word)) {
      let from_split = from.split(word);
      get_sipdomain_from = from_split[1];
      get_pin_from = from_split[0];
      let remove_sip: any = get_pin_from.split(':')
      remove_sip = remove_sip[1];
      get_pin_from = remove_sip
      let remove_port_from_domain: any = get_sipdomain_from.split(":")
      let get_new_domain_from: any = remove_port_from_domain[0];
      get_sipdomain_from = get_new_domain_from
    }
    let get_sip_domain_to = ""
    if (to.includes(word)) {
      let to_split = to.split(word);
      get_sipdomain_to = to_split[1];
      console.log("get_sipdomain_to", get_sipdomain_to)
      let get_sip_domain_to_tmp = get_sipdomain_to.split(":")
      get_sip_domain_to = get_sip_domain_to_tmp[0]
      console.log("get_sip_domain_to", get_sip_domain_to)
      get_pin_to = to_split[0]
      console.log("to_split", to_split)
      let remove_sip_to: any = get_pin_to.split(':')
      remove_sip_to = remove_sip_to[1];
      get_pin_to = remove_sip_to
    }

    let get_enterprise_detail: any = await enterprise.findOne({
      sipDomain: get_sip_domain_to,
      is_deleted: 0
    })
    let eid_tmp: any = null;
    if (get_enterprise_detail !== null) {
      eid_tmp = get_enterprise_detail._id
    }


    let timezone_serve: any = momentTimezone.tz.guess();
    //console.log("timezone_serve",timezone_serve)

    let date_time_utc: any = moment.utc().toDate();
    //console.log("date_time_utc",date_time_utc)
    let localtime_date = moment(date_time_utc).local().format('YYYY-MM-DDTHH:mm:ss.sssZ');
    //console.log("localtime_date",localtime_date)
    let get_year: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("YYYY")
    let get_month: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("MM")
    let get_day: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("DD")
    let get_hour: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("HH")
    let get_minutes: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("mm")
    let get_seconds: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("ss")


    let get_int_month: any = parseFloat(get_month) - 1
    //console.log("get_int",get_int_month)


    let new_tmp_date: any = new Date();
    new_tmp_date.setUTCFullYear(get_year)
    new_tmp_date.setUTCMonth(get_int_month)
    new_tmp_date.setUTCDate(get_day)
    new_tmp_date.setUTCHours(get_hour)
    new_tmp_date.setUTCMinutes(get_minutes)
    new_tmp_date.setUTCSeconds(get_seconds)

    //console.log("new_tmp_date",new_tmp_date)


    console.log("get_from_user_detail", get_sip_domain_to)
    console.log("get_pin_from", get_pin_from)
    let get_from_user_detail: any = await user.findOne({
      sipDomain: get_sip_domain_to,
      endpointNumber: get_pin_from,
      is_deleted: 0
    })

    let from_user_name: any = "";
    let from_user_image: any = "";
    let from_user_extantion: any = ""

    if (get_from_user_detail !== null) {
      from_user_name = get_from_user_detail.first_name + " " + get_from_user_detail.last_name
      from_user_image = get_from_user_detail.user_image
      from_user_extantion = get_from_user_detail.endpointNumber
    }
    console.log("from_user_name", from_user_name)

    console.log("get_sip_domain_to", get_sip_domain_to)
    console.log("get_pin_to", get_pin_to)
    let get_to_user_detail: any = await user.findOne({
      sipDomain: get_sip_domain_to,
      endpointNumber: get_pin_to,
      is_deleted: 0
    })

    let to_user_name: any = "";
    let to_user_image: any = "";

    if (get_to_user_detail !== null) {
      to_user_name = get_to_user_detail.first_name + " " + get_to_user_detail.last_name
      to_user_image = get_to_user_detail.user_image
    }

    console.log("to_user_name", to_user_name)

    let isinternal_call: Number = 0
    if (get_from_user_detail !== null && get_to_user_detail !== null && get_from_user_detail.eid.toString() === get_to_user_detail.eid.toString()) {
      isinternal_call = 1
    }

    let uuid4: string = uuidv4();

    let create_cdr_obj: any = {
      call_id: call_id,
      eid: eid_tmp,
      from: get_pin_from,
      to: get_pin_to,
      sipDomain: get_sip_domain_to,
      duration: "00:00:00",
      call_time: new_tmp_date,
      ingressip: "",
      egressip: "",
      from_user_name: from_user_name,
      from_user_image: from_user_image,
      to_user_name: to_user_name,
      to_user_image: to_user_image,
      isvideo_call: call_type,
      isinternal_call: isinternal_call,
      session_id: uuid4
    }

    let create_cdr: any = await call_history.create(create_cdr_obj)

    //console.log("get_to_user_detail",get_to_user_detail)
    let get_sip_tokens: any = await user_tokens.find({
      uid: get_to_user_detail._id,
      osversion: 1,
    })
    //console.log("get_sip_tokens",get_sip_tokens)
    if (get_sip_tokens.length > 0) {
      let push_tokens_detail: any[] = [];

      await Promise.all(get_sip_tokens.map(async (item: any) => {
        push_tokens_detail.push(item.push_token.toString())
      }));
      let title: any = "incoming Call";
      let body: any = from_user_extantion == "" ? get_pin_from.toString() : from_user_extantion.toString();
      let token: any[] = push_tokens_detail

      let tmp_caller_nm: any = from_user_name == "" ? get_pin_from : from_user_name
      let caller_number: any = from_user_extantion == "" ? get_pin_from : from_user_extantion

      console.log("call_type", call_type,)
      let call_type_parse = 0
      if (call_type !== "" || call_type !== '') {
        call_type_parse = parseInt(call_type);
      }


      let notification_data: any = {
        call_id: call_id.toString(),
        caller_number: caller_number.toString(),
        caller_name: tmp_caller_nm.toString(),
        call_type: call_type_parse.toString(),
        caller_image: from_user_image.toString()
      }
      console.log("notification_data", notification_data)
      console.log("token", token)
      let sendpush_response_android: any = await sendPushNotification(title, body, token, notification_data);
      console.log("sendpush_response_android", sendpush_response_android)
      if (sendpush_response_android.failureCount > 0) {
        isadroidfaild = 1
        androidErrorCount = sendpush_response_android.failureCount
      }
    }
    let get_sip_tokens_ios: any = await user_tokens.find({
      uid: get_to_user_detail._id,
      osversion: 2
    })
    //console.log("get_sip_tokens_ios",get_sip_tokens_ios)
    // if (get_sip_tokens_ios.length > 0) {
    //   let push_tokens_detail: any[] = [];

    //   await Promise.all(get_sip_tokens_ios.map(async (item: any) => {
    //     push_tokens_detail.push(item.apns_push_token.toString())
    //   }));
    //   let title: any = "incoming Call";
    //   let body: any = from_user_extantion == "" ? get_pin_from.toString() : from_user_extantion.toString();
    //   let token: any[] = push_tokens_detail

    //   let tmp_caller_nm: any = from_user_name == "" ? get_pin_from : from_user_name;
    //   let caller_number: any = from_user_extantion == "" ? parseInt(get_pin_from) : parseInt(from_user_extantion);
    //   let tmp_caller_extantion: any = 0
    //   let call_type_parse: any = 0
    //   console.log("call_type", call_type)
    //   if (call_type !== "" || call_type !== '') {
    //     call_type_parse = parseInt(call_type);
    //   }


    //   let notification_data: any = {
    //     "caller_number": caller_number.toString(),
    //     "call-id": call_id.toString(),
    //     "session_id": uuid4.toString(),
    //     "call_type": call_type_parse,
    //     "caller_id": tmp_caller_extantion,
    //     "signal_type": "startCall",
    //     "caller_name": tmp_caller_nm.toString(),
    //     "call_opponents": caller_number.toString(),
    //     "user_info": caller_number.toString(),
    //     "caller_image": from_user_image.toString()
    //   }
    //   console.log("notification_data", notification_data)
    //   let sendpush_response_ios: any = await sendPushNotificationios(title, body, token, notification_data);
    //   //console.log("sendpush_response_ios",sendpush_response_ios.failed.length)
    //   if (sendpush_response_ios.failed.length > 0) {
    //     isiosfaild = 1
    //     iosErrorCount = sendpush_response_ios.failed.length
    //   }
    // }


    return res.status(200).send({
      success: 1,
      message: "Call Detail Stored Successfully",
      CallDetail: create_cdr,
      iosErrorCount: iosErrorCount,
      androidErrorCount: androidErrorCount
    });


  } catch (error) {
    console.log("error", error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const Endcallcdrlog = async (req: Request, res: Response, next: NextFunction) => {
  console.log("cdr end api called", req.body)
  try {
    let data: any = req.body
    let call_id: any = data.call_id
    let from: any = data.from
    let to: any = data.to
    let call_type: any = 0
    let androidErrorCount: any = 0;
    let iosErrorCount: any = 0;

    if (call_id == undefined) {
      return res.status(400).send({
        message: "call_id field is mandatory"
      })
    }

    if (from == undefined) {
      return res.status(400).send({
        message: "from field is mandatory"
      })
    }

    if (to == undefined) {
      return res.status(400).send({
        message: "to field is mandatory"
      })
    }

    if (call_type == undefined) {
      return res.status(400).send({
        message: "call_type field is mandatory"
      })
    }

    let get_sipdomain_from: any = "";
    let get_pin_from: any = "";
    let get_sipdomain_to: any = "";
    let get_pin_to: any = "";
    const word = '@';
    //console.log(sip_username);
    if (from.includes(word)) {
      let from_split = from.split(word);
      get_sipdomain_from = from_split[1];
      get_pin_from = from_split[0];
      let remove_sip: any = get_pin_from.split(':')
      remove_sip = remove_sip[1];
      get_pin_from = remove_sip
      let remove_port_from_domain: any = get_sipdomain_from.split(":")
      let get_new_domain_from: any = remove_port_from_domain[0];
      get_sipdomain_from = get_new_domain_from
    }
    let get_sip_domain_to = ""
    if (to.includes(word)) {
      let to_split = to.split(word);
      get_sipdomain_to = to_split[1];
      console.log("get_sipdomain_to", get_sipdomain_to)
      let get_sip_domain_to_tmp = get_sipdomain_to.split(":")
      get_sip_domain_to = get_sip_domain_to_tmp[0]
      console.log("get_sip_domain_to", get_sip_domain_to)
      get_pin_to = to_split[0]
      console.log("to_split", to_split)
      let remove_sip_to: any = get_pin_to.split(':')
      remove_sip_to = remove_sip_to[1];
      get_pin_to = remove_sip_to
    }

    let get_from_user_detail: any = await user.findOne({
      endpointNumber: get_pin_from,
      sipDomain: get_sip_domain_to,
      is_deleted: 0
    })

    let from_user_extantion: any = ""
    if (get_from_user_detail !== null) {
      from_user_extantion = get_from_user_detail.endpointNumber
    }


    let get_to_user_detail: any = await user.findOne({
      endpointNumber: get_pin_to,
      sipDomain: get_sip_domain_to,
      is_deleted: 0
    })

    let to_user_extantion = "";
    if (get_to_user_detail !== null) {
      to_user_extantion = get_to_user_detail.endpointNumber
    }

    console.log("from_user_extantion", from_user_extantion)
    console.log("to_user_extantion", to_user_extantion)

    console.log("get_pin_to", get_pin_to)
    console.log("get_pin_from", get_pin_from)

    let check_call: any = await call_history.findOne({
      call_id: call_id
    })
    let updated_call: any = {};
    if (check_call !== null) {
      let duration_time: any = "00:00:00"
      if (check_call.call_start_time !== null) {
        let start_date: any = new Date(check_call.call_start_time);
        // console.log("start_date",start_date)
        // console.log("check_call.call_time",check_call.call_time)
        start_date.toISOString().slice(0, 19);
        let end_date: any = new Date();

        let date_time_utc: any = moment.utc().toDate();
        //console.log("date_time_utc",date_time_utc)
        let localtime_date = moment(date_time_utc)
          .local()
          .format("YYYY-MM-DDTHH:mm:ss.sssZ");
        //console.log("localtime_date",localtime_date)
        let get_year: any = moment(
          localtime_date,
          "YYYY-MM-DDTHH:mm:ss.sssZ"
        ).format("YYYY");
        let get_month: any = moment(
          localtime_date,
          "YYYY-MM-DDTHH:mm:ss.sssZ"
        ).format("MM");
        let get_day: any = moment(
          localtime_date,
          "YYYY-MM-DDTHH:mm:ss.sssZ"
        ).format("DD");
        let get_hour: any = moment(
          localtime_date,
          "YYYY-MM-DDTHH:mm:ss.sssZ"
        ).format("HH");
        let get_minutes: any = moment(
          localtime_date,
          "YYYY-MM-DDTHH:mm:ss.sssZ"
        ).format("mm");
        let get_seconds: any = moment(
          localtime_date,
          "YYYY-MM-DDTHH:mm:ss.sssZ"
        ).format("ss");

        let get_int_month: any = parseFloat(get_month) - 1;

        end_date.setUTCFullYear(get_year);
        end_date.setUTCMonth(get_int_month);
        end_date.setUTCDate(get_day);
        end_date.setUTCHours(get_hour);
        end_date.setUTCMinutes(get_minutes);
        end_date.setUTCSeconds(get_seconds);

        //console.log("end_date",end_date)

        end_date.toISOString().slice(0, 19);
        let diff_num_ms: any = Math.abs(start_date.getTime() - end_date.getTime());
        let diff_num_sec: any = Math.floor(diff_num_ms / 1000);

        let totalSeconds = diff_num_sec;
        let hours_tmp: any = Math.floor(totalSeconds / 3600);
        totalSeconds %= 3600;
        let minutes: any = Math.floor(totalSeconds / 60);
        let seconds_tmp: any = totalSeconds % 60;

        minutes = String(minutes).padStart(2, "0");
        hours_tmp = String(hours_tmp).padStart(2, "0");
        seconds_tmp = String(seconds_tmp).padStart(2, "0");
        duration_time = hours_tmp + ":" + minutes + ":" + seconds_tmp;
      }
      updated_call = await call_history.findByIdAndUpdate(
        {
          _id: check_call._id,
        },
        {
          call_id: call_id,
          duration: duration_time,
          iscallEnded: 1,
          is_connected: 1,
          call_end_time: new Date()
        },
        {
          new: true,
        }
      );
    }

    let get_user_detail: any = get_to_user_detail;
    let caller_number: any = "";
    let isadroidfaild: any = 0;
    let isiosfaild: any = 0;
    // if (updated_call.isinternal_call == 1) {
    //   get_user_detail = await user.findOne({
    //     endpointNumber: updated_call.to,
    //     sipDomain: updated_call.sipDomain,
    //     is_deleted:0
    //   });
    //   caller_number = updated_call.from;
    // }
    // } else {
    //   console.log("else called of updatED CALL")
    //   let get_user_detail_from: any = await user.findOne({
    //     endpointNumber: updated_call.to,
    //     sipDomain: updated_call.sipDomain,
    //     is_deleted:0
    //   });
    //   let get_user_detail_to: any = await user.findOne({
    //     endpointNumber: updated_call.from,
    //     sipDomain: updated_call.sipDomain,
    //     is_deleted:0
    //   });
    //   console.log("get_user_detail_from",get_user_detail_from)
    //   console.log("get_user_detail_to",get_user_detail_to)
    //   if (get_user_detail_from == null && get_user_detail_to !== null) {
    //     caller_number = updated_call.from;
    //     get_user_detail = get_user_detail_to;
    //   } else {
    //     get_user_detail = null;
    //   }
    // }
    console.log("get_to_user_detail", get_to_user_detail)
    let check_call_id: any = call_id.includes(word)
    console.log("check_call_id",)
    if (get_to_user_detail !== null) {
      console.log("get_user_detail", get_user_detail)
      let get_sip_tokens: any = await user_tokens.find({
        uid: get_user_detail._id,
        osversion: 1,
      });
      console.log("get_sip_tokens", get_sip_tokens)
      if (get_sip_tokens.length > 0) {
        let push_tokens_detail: any[] = [];

        await Promise.all(
          get_sip_tokens.map(async (item: any) => {
            push_tokens_detail.push(item.push_token.toString());
          })
        );
        let title: any = "End Call";
        let body: any =
          get_user_detail == null
            ? updated_call.from
            : get_user_detail.pin.toString();
        let token: any[] = push_tokens_detail;

        let tmp_caller_nm: any =
          get_user_detail == null
            ? updated_call.from
            : get_user_detail.first_name + " " + get_user_detail.last_name;
        let from_user_image: any =
          get_user_detail == null ? "" : get_user_detail.user_image;
        let defualt_img = ""
        let notification_data: any = {
          call_id: call_id.toString(),
          caller_number: caller_number.toString(),
          caller_name: tmp_caller_nm.toString(),
          call_type: call_type.toString(),
          caller_image: from_user_image == "" ? defualt_img.toString() : from_user_image.toString(),
        };
        console.log("notification_data", notification_data);
        let sendpush_response_android: any = await sendPushNotification(
          title,
          body,
          token,
          notification_data
        );
        console.log("sendpush_response_android", sendpush_response_android);
        if (sendpush_response_android.failureCount > 0) {
          isadroidfaild = 1;
          androidErrorCount = sendpush_response_android.failureCount;
        }
      }
    }
    return res.status(200).send({
      success: 1,
      message: "Call Detail Stored Successfully",
      CallDetail: updated_call,
      AndroidFaildCount: androidErrorCount,
      IosFailCount: iosErrorCount
    });


  } catch (error) {
    //console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const Getcallhistory = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let eid: any = user_detail?.eid
    let created_uid: any = new mongoose.Types.ObjectId(uid)

    let get_user_pin: any = await user.findOne({
      _id: uid,
      is_deleted:0
    })

    if (get_user_pin == null) {
      return res.status(404).send({
        success: 0,
        message: "User Not Found"
      });
    }

    let data: any = req.body
    let page: any = parseInt(data.page)
    let size: any = parseInt(data.size);
    if (!page) page = 1;
    if (!size) size = 50;

    let get_CDR_Log: any = await call_history.aggregate([
      {
        $sort: {
          createdAt: -1
        }
      },
      {
        $match: {
          $or: [
            {
              for_user: get_user_pin.endpointNumber
            },
            {
              for_user: get_user_pin.callerId
            }
          ],
          deleted_users: { $nin: [created_uid] }
        }
      },
      // {
      //   $match:{
      //     $or:[
      //       {
      //         $or:[
      //           {
      //             for_user:get_user_pin.endpointNumber
      //           }
      //         ]
      //       },
      //       {
      //         $or:[
      //           {
      //             to:get_user_pin.endpointNumber
      //           }
      //         ]
      //       }
      //     ]
      //   }
      // },
      {
        $lookup: {
          from: "enterprises",
          localField: "eid",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                enterprise_name: 1
              }
            }],
          as: "enterprise_detail"
        }
      },
      {
        $unwind: {
          path: "$to_enterprise_detail",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $project: {
          _id: 1,
          fromExtantion: "$from",
          toExtantion: "$to",
          sipDomain: 1,
          duration: 1,
          call_time: 1,
          direction: 1,
          from_user_name: 1,
          from_user_image: 1,
          to_user_name: 1,
          to_user_image: 1,
          isvideo_call: 1
        }
      },
      {
        $facet: {
          metadata: [{ $count: 'totalCount' }],
          callDtails: [{ $skip: (page - 1) * size }, { $limit: size }],
        },
      },
    ])

    let temp_data: any[] = [];
    if (get_CDR_Log[0].callDtails.length > 0) {
      let tmp_arr: any[] = get_CDR_Log[0].callDtails
      temp_data = await Promise.all(tmp_arr.map(async (items: any) => {
        let get_from_name_tmp: any = await user.findOne({
          sipDomain: items.sipDomain,
          endpointNumber: items.fromExtantion,
          is_deleted: 0
        })
        items.from_user_name = get_from_name_tmp !== null ? get_from_name_tmp.first_name + " " + get_from_name_tmp.last_name : items.from_user_name;
        items.from_user_image = get_from_name_tmp !== null ? get_from_name_tmp.user_image : items.from_user_image;

        let get_to_name_tmp: any = await user.findOne({
          sipDomain: items.sipDomain,
          endpointNumber: items.toExtantion,
          is_deleted: 0
        })
        items.to_user_name = get_to_name_tmp !== null ? get_to_name_tmp.first_name + " " + get_to_name_tmp.last_name : items.to_user_name;
        items.to_user_image = get_to_name_tmp !== null ? get_to_name_tmp.user_image : items.to_user_image;
        return items;
      }))
      //console.log("temp_data",temp_data)
    }


    let total_call_count: any = get_CDR_Log[0].callDtails.length > 0 ? get_CDR_Log[0].metadata[0].totalCount : 0
    let total_page_count: any = Math.ceil(total_call_count / size);


    return res.status(200).send({
      success: 1,
      message: "CDR Log Detail",
      CallDetail: temp_data,
      total_call_count: total_call_count,
      total_page_count: total_page_count
    });
  } catch (error) {
    //console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const GetCDRlogs = async (req: Request, res: Response, next: NextFunction) => {
  try {

    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid

    let data: any = req.body
    let page: any = data.page;
    let size: any = parseInt(data.size);
    if (!page) page = 1;
    if (!size) size = 50;

    let eid_find: any = data.eid
    let endpointnumber: any = data.endpointnumber;
    let startDate: any = new Date(data.startDate)
    let endDate: any = new Date(data.endDate)
    let internal_calls: any = data.internal_calls

    let find_query: { [key: string]: any } = {
      call_id: { $regex: '@' }
    };
    if (endpointnumber !== undefined && endpointnumber !== null) {
      find_query = {
        $or: [
          {
            from: {
              $regex: endpointnumber,
              $options: "i"
            }
          },
          {
            to: {
              $regex: endpointnumber,
              $options: "i"
            }
          }
        ]
      }
    }
    if (startDate !== undefined && endDate !== undefined && startDate !== null && endDate !== null) {
      find_query.call_time = {
        $gte: startDate,
        $lte: endDate
      }
    }
    if (eid_find !== undefined && eid_find !== null) {
      find_query.eid = new mongoose.Types.ObjectId(eid_find)
    }
    if (internal_calls == 1) {
      find_query.isinternal_call = 1
    } else if (internal_calls == 2) {
      find_query.isinternal_call = 0
    } else {
      //no need to add filter
    }
    console.log("find_query", find_query)
    let get_CDR_Log: any = await call_history.aggregate([
      {
        $match: find_query
      },
      {
        $lookup: {
          from: "enterprises",
          localField: "eid",
          foreignField: "_id",
          pipeline: [
            {
              $project: {
                _id: 1,
                enterprise_name: 1
              }
            }],
          as: "enterprise_detail"
        }
      },
      {
        $unwind: {
          path: "$enterprise_detail",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $project: {
          _id: 1,
          eid: 1,
          from: 1,
          to: 1,
          sipDomain: 1,
          duration: 1,
          call_time: 1,
          direction: 1,
          from_user_name: 1,
          from_user_image: 1,
          to_user_name: 1,
          to_user_image: 1,
          enterprise_name: "$enterprise_detail.enterprise_name",
          createdAt: 1,
          call_id: 1
        }
      },
      {
        $sort: {
          createdAt: -1
        }
      },
      {
        $facet: {
          metadata: [{ $count: 'totalCount' }],
          callDtails: [{ $skip: (page - 1) * size }, { $limit: size }],
        },
      },
    ])

    let total_call_count: any = get_CDR_Log[0].callDtails.length > 0 ? get_CDR_Log[0].metadata[0].totalCount : 0
    let total_page_count: any = Math.ceil(total_call_count / size);

    let arr_user: any[] = get_CDR_Log[0].callDtails.length > 0 ? get_CDR_Log[0].callDtails : []

    let response_arr: any[] = [];

    if (arr_user.length > 0) {
      await Promise.all(arr_user.map(async (value: any) => {
        let call_time_tmp: any = moment(value.call_time, "YYYY-MM-DDTHH:mm:ss.sssZ").utc().format("YYYY-MM-DD hh:mm:ss A")
        value.call_time = call_time_tmp
        response_arr.push(value)
      }))
    }


    return res.status(200).send({
      success: 1,
      message: "CDR Log Detail",
      CallDetail: response_arr,
      total_call_count: total_call_count,
      total_page_count: total_page_count
    });
  } catch (error) {
    console.log("error", error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const EnterpriseUserList = async (req: Request, res: Response, next: NextFunction) => {
  // try {
  //   let get_eid: any = req.body.eid
  //   if (get_eid == undefined) {
  //     return res.status(404).send({
  //       success: 0,
  //       message: "eid field is mandatory"
  //     });
  //   }
  //   let check_enterprise_user_list: any = await user
  //     .find({
  //       is_deleted: 0,
  //       eid: get_eid
  //     })
  //     .select("first_name last_name endpointNumber");

  //   return res.status(200).send({
  //     success: 1,
  //     message: "User List",
  //     UserDetail: check_enterprise_user_list,
  //   });
  // } catch (error) {
  //   return res.status(500).send({
  //     success: 0,
  //     message: "Internal Server Error,"
  //   });
  // }
  return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
  });
};
const addFavContact = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let eid: any = user_detail?.eid
    let data: any = req.body
    let user_id:any = data.user_id

    if (user_id == undefined) {
      return res.status(400).send({
        success: 0,
        message: "user_id is Mandatory."
      });
    }
    const rowData = await user_fav_contact.findOne({user_id:user_id,uid:uid})
    if(rowData){
      return res.status(200).send({
      success: 1,
      message: "Contact Detail Stored Successfully",
    });
    }
    let create_fav_obj: any = {
      eid: eid,
      uid: uid,
      user_id:user_id,
    }

    let create_fav_contats: any = await user_fav_contact.create(create_fav_obj)
    await emitHandler("sync_data", {
      uid: uid,
    });
    return res.status(200).send({
      success: 1,
      message: "Contact Detail Stored Successfully",
      Contact_detail: create_fav_contats
    });


  } catch (error) {
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const deteleFavContact = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let data: any = req.body
    let favorite_id: any = data.favorite_id
    console.log("Deleting Favorite Contact :", favorite_id);

    let deleted_fav_detail: any = await user_fav_contact.findByIdAndDelete({
      _id: favorite_id
    }, {
      new: true
    })
    await emitHandler("sync_data", {
      uid: uid,
    });
    return res.status(200).send({
      success: 1,
      message: "Contact removed from Favorite Successfully"
    });
  } catch (error) {
    console.log("error in deleting favorite contact error : ", error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const getFavContactList = async (req: Request, res: Response, next: NextFunction) => {
  console.log("favorite/contacts/list api called")
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid

    let data = await user_fav_contact.aggregate([
      {
        $match:{
          uid:uid
        }
      },
      {
        $lookup:{
          from:"users",
          localField:"user_id",
          foreignField:"_id",
          as:"user_details",
          pipeline: [
            {
            
              $match: {
                is_deleted: 0
              }
            },
            {$project:{
              MobileNumber:1,
              first_name:1,
              last_name:1,
              user_image:1,
              user_name:1
            }}
          ]
        }
      },{
        $unwind:{
          path:"$user_details", 
          preserveNullAndEmptyArrays:false
        }
      }
    ])
    return res.status(200).send({
      success: 1,
      message: "Favorite Contact List",
      // ContactList: get_fav_contats
      ContactList: data
    });


  } catch (error) {
    //console.log("create fqdn error",error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const updategroupmember_detail = async (req: Request, res: Response, next: NextFunction) => {
  try {

    let get_group_details: any = await group.find();

    if (get_group_details.length > 0) {
      await Promise.all(get_group_details.map(async (items: any) => {
        let find_group_members: any[] = await group_members.find({
          group_id: items._id
        })

        if (find_group_members.length > 0) {
          await Promise.all(find_group_members.map(async (rows: any) => {
            await group_members.findByIdAndUpdate({
              _id: rows._id
            }, {
              isleaved: 0
            })
          }))

          if (items.group_leave_members.length > 0) {
            await Promise.all(items.group_leave_members.map(async (itemsss: any) => {
              await group_members.findOneAndUpdate({
                group_id: items._id,
                member_id: itemsss
              }, {
                isleaved: 1
              })
            }))
          }
        }
      }))
    }


    return res.status(200).send({
      success: 1,
      message: "Favorite Contact List",
      //ContactList:get_fav_contats
    });


  } catch (error) {
    //console.log("create fqdn error",error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const addCallInCdr = async (req: Request, res: Response, next: NextFunction) => {
  try {
    console.log("cdr add api called addCallInCdr", req.body)
    try {
      let data: any = req.body
      let from: any = data.from
      let to: any = data.to
      let call_id: any = data.call_id
      let call_type: any = data.call_type


      if (call_id == undefined) {
        return res.status(400).send({
          message: "call_id field is mandatory"
        })
      }

      if (from == undefined) {
        return res.status(400).send({
          message: "from field is mandatory"
        })
      }

      if (to == undefined) {
        return res.status(400).send({
          message: "to field is mandatory"
        })
      }

      if (call_type == undefined) {
        return res.status(400).send({
          message: "call_type field is mandatory"
        })
      }

      let check_call_exists: any = await call_history.findOne({
        call_id: call_id
      })

      if (check_call_exists !== null) {
        return res.status(400).send({
          message: "Call Already Exists in Db With this call_id."
        })
      }

      let get_sipdomain_from: any = "";
      let get_pin_from: any = "";
      let get_sipdomain_to: any = "";
      let get_pin_to: any = "";
      const word = '@';
      //console.log(sip_username);
      if (from.includes(word)) {
        let from_split = from.split(word);
        get_sipdomain_from = from_split[1];
        get_pin_from = from_split[0];
        let remove_sip: any = get_pin_from.split(':')
        remove_sip = remove_sip[1];
        get_pin_from = remove_sip
        let remove_port_from_domain: any = get_sipdomain_from.split(":")
        let get_new_domain_from: any = remove_port_from_domain[0];
        get_sipdomain_from = get_new_domain_from
      }
      let get_sip_domain_to = ""
      if (to.includes(word)) {
        let to_split = to.split(word);
        get_sipdomain_to = to_split[1];
        console.log("get_sipdomain_to", get_sipdomain_to)
        let get_sip_domain_to_tmp = get_sipdomain_to.split(":")
        get_sip_domain_to = get_sip_domain_to_tmp[0]
        console.log("get_sip_domain_to", get_sip_domain_to)
        get_pin_to = to_split[0]
        console.log("to_split", to_split)
        let remove_sip_to: any = get_pin_to.split(':')
        remove_sip_to = remove_sip_to[1];
        get_pin_to = remove_sip_to
      }

      let get_enterprise_detail: any = await enterprise.findOne({
        sipDomain: get_sip_domain_to,
        is_deleted: 0
      })
      let eid_tmp: any = null;
      if (get_enterprise_detail !== null) {
        eid_tmp = get_enterprise_detail._id
      }


      let timezone_serve: any = momentTimezone.tz.guess();
      //console.log("timezone_serve",timezone_serve)

      let date_time_utc: any = moment.utc().toDate();
      //console.log("date_time_utc",date_time_utc)
      let localtime_date = moment(date_time_utc).local().format('YYYY-MM-DDTHH:mm:ss.sssZ');
      //console.log("localtime_date",localtime_date)
      let get_year: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("YYYY")
      let get_month: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("MM")
      let get_day: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("DD")
      let get_hour: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("HH")
      let get_minutes: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("mm")
      let get_seconds: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("ss")


      let get_int_month: any = parseFloat(get_month) - 1
      //console.log("get_int",get_int_month)


      let new_tmp_date: any = new Date();
      new_tmp_date.setUTCFullYear(get_year)
      new_tmp_date.setUTCMonth(get_int_month)
      new_tmp_date.setUTCDate(get_day)
      new_tmp_date.setUTCHours(get_hour)
      new_tmp_date.setUTCMinutes(get_minutes)
      new_tmp_date.setUTCSeconds(get_seconds)

      console.log("new_tmp_date", new_tmp_date)


      console.log("get_from_user_detail", get_sip_domain_to)
      console.log("get_pin_from", get_pin_from)
      let get_from_user_detail: any = await user.findOne({
        sipDomain: get_sip_domain_to,
        endpointNumber: get_pin_from,
        is_deleted: 0
      })

      let from_user_name: any = "";
      let from_user_image: any = "";
      let from_user_extantion: any = ""

      if (get_from_user_detail !== null) {
        from_user_name = get_from_user_detail.first_name + " " + get_from_user_detail.last_name
        from_user_image = get_from_user_detail.user_image
        from_user_extantion = get_from_user_detail.endpointNumber
      }
      console.log("from_user_name", from_user_name)

      console.log("get_sip_domain_to", get_sip_domain_to)
      console.log("get_pin_to", get_pin_to)
      let get_to_user_detail: any = await user.findOne({
        sipDomain: get_sip_domain_to,
        endpointNumber: get_pin_to,
        is_deleted: 0
      })

      let to_user_name: any = "";
      let to_user_image: any = "";

      if (get_to_user_detail !== null) {
        to_user_name = get_to_user_detail.first_name + " " + get_to_user_detail.last_name
        to_user_image = get_to_user_detail.user_image
      }

      console.log("to_user_name", to_user_name)

      let isinternal_call: Number = 0
      if (get_from_user_detail !== null && get_to_user_detail !== null && get_from_user_detail.eid.toString() === get_to_user_detail.eid.toString()) {
        isinternal_call = 1
      }

      let uuid4: string = uuidv4();
      //console.log(sip_username);
      let for_user_extention: String = get_pin_from
      if (call_id.includes(word)) {
        for_user_extention = get_pin_to
      }

      let create_cdr_obj: any = {
        call_id: call_id,
        eid: eid_tmp,
        from: get_pin_from,
        to: get_pin_to,
        sipDomain: get_sip_domain_to,
        call_time: new_tmp_date,
        duration: "00:00:00",
        ingressip: "",
        egressip: "",
        from_user_name: from_user_name,
        from_user_image: from_user_image,
        to_user_name: to_user_name,
        to_user_image: to_user_image,
        isvideo_call: call_type,
        isinternal_call: isinternal_call,
        session_id: uuid4,
        for_user: for_user_extention
      }

      let create_cdr: any = await call_history.create(create_cdr_obj)

      return res.status(200).send({
        success: 1,
        message: "Call Detail Stored Successfully",
        CallDetail: create_cdr
      });

    } catch (error) {
      console.log("error", error)
      res.status(500).send({
        success: 0,
        message: "Internal Server Error"
      });
    }
  } catch (error) {
    //console.log("create fqdn error",error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};
const SendpushToAppNew = async (req: Request, res: Response, next: NextFunction) => {
  console.log("send push to api called", req.body)
  try {
    let data: any = req.body
    let from: any = data.from
    let to: any = data.to
    let call_id: any = data.call_id
    let call_type: any = data.call_type
    let isadroidfaild: any = 0
    let androidErrorCount: any = 0;
    let iosErrorCount: any = 0;
    let isiosfaild: any = 0

    if (call_id == undefined) {
      return res.status(400).send({
        message: "call_id field is mandatory"
      })
    }

    if (from == undefined) {
      return res.status(400).send({
        message: "from field is mandatory"
      })
    }

    if (to == undefined) {
      return res.status(400).send({
        message: "to field is mandatory"
      })
    }

    if (call_type == undefined) {
      return res.status(400).send({
        message: "call_type field is mandatory"
      })
    }


    let get_sipdomain_from: any = "";
    let get_pin_from: any = "";
    let get_sipdomain_to: any = "";
    let get_pin_to: any = "";
    const word = '@';
    //console.log(sip_username);
    if (from.includes(word)) {
      let from_split = from.split(word);
      get_sipdomain_from = from_split[1];
      get_pin_from = from_split[0];
      let remove_sip: any = get_pin_from.split(':')
      remove_sip = remove_sip[1];
      get_pin_from = remove_sip
      let remove_port_from_domain: any = get_sipdomain_from.split(":")
      let get_new_domain_from: any = remove_port_from_domain[0];
      get_sipdomain_from = get_new_domain_from
    }
    let get_sip_domain_to = ""
    if (to.includes(word)) {
      let to_split = to.split(word);
      get_sipdomain_to = to_split[1];
      console.log("get_sipdomain_to", get_sipdomain_to)
      let get_sip_domain_to_tmp = get_sipdomain_to.split(":")
      get_sip_domain_to = get_sip_domain_to_tmp[0]
      console.log("get_sip_domain_to", get_sip_domain_to)
      get_pin_to = to_split[0]
      console.log("to_split", to_split)
      let remove_sip_to: any = get_pin_to.split(':')
      remove_sip_to = remove_sip_to[1];
      get_pin_to = remove_sip_to
    }

    let get_enterprise_detail: any = await enterprise.findOne({
      sipDomain: get_sip_domain_to,
      is_deleted: 0
    })
    let eid_tmp: any = null;
    if (get_enterprise_detail !== null) {
      eid_tmp = get_enterprise_detail._id
    }



    let timezone_serve: any = momentTimezone.tz.guess();
    //console.log("timezone_serve",timezone_serve)

    let date_time_utc: any = moment.utc().toDate();
    //console.log("date_time_utc",date_time_utc)
    let localtime_date = moment(date_time_utc).local().format('YYYY-MM-DDTHH:mm:ss.sssZ');
    //console.log("localtime_date",localtime_date)
    let get_year: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("YYYY")
    let get_month: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("MM")
    let get_day: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("DD")
    let get_hour: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("HH")
    let get_minutes: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("mm")
    let get_seconds: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("ss")


    let get_int_month: any = parseFloat(get_month) - 1
    //console.log("get_int",get_int_month)


    let new_tmp_date: any = new Date();
    new_tmp_date.setUTCFullYear(get_year)
    new_tmp_date.setUTCMonth(get_int_month)
    new_tmp_date.setUTCDate(get_day)
    new_tmp_date.setUTCHours(get_hour)
    new_tmp_date.setUTCMinutes(get_minutes)
    new_tmp_date.setUTCSeconds(get_seconds)

    //console.log("new_tmp_date",new_tmp_date)


    console.log("get_from_user_detail", get_sip_domain_to)
    console.log("get_pin_from", get_pin_from)
    let get_from_user_detail: any = await user.findOne({
      sipDomain: get_sip_domain_to,
      endpointNumber: get_pin_from,
      is_deleted: 0
    })

    let from_user_name: any = "";
    let from_user_image: any = "";
    let from_user_extantion: any = ""

    if (get_from_user_detail !== null) {
      from_user_name = get_from_user_detail.first_name + " " + get_from_user_detail.last_name
      from_user_image = get_from_user_detail.user_image
      from_user_extantion = get_from_user_detail.endpointNumber
    }
    console.log("from_user_name", from_user_name)

    console.log("get_sip_domain_to", get_sip_domain_to)
    console.log("get_pin_to", get_pin_to)
    let get_to_user_detail: any = await user.findOne({
      sipDomain: get_sip_domain_to,
      endpointNumber: get_pin_to,
      is_deleted: 0
    })

    let to_user_name: any = "";
    let to_user_image: any = "";
    let to_user_extantion: any = "";
    if (get_to_user_detail !== null) {
      to_user_name = get_to_user_detail.first_name + " " + get_to_user_detail.last_name
      to_user_image = get_to_user_detail.user_image
      to_user_extantion = get_to_user_detail.endpointNumber
    }

    console.log("to_user_name", to_user_name)

    let isinternal_call: Number = 0
    if (get_from_user_detail !== null && get_to_user_detail !== null && get_from_user_detail.eid.toString() === get_to_user_detail.eid.toString()) {
      isinternal_call = 1
    }

    let check_call: any = await call_history.findOne({
      from: from_user_extantion,
      to: to_user_extantion,
      sipDomain: get_sip_domain_to,
      iscallEnded: 0,
      isinternal_call: 1
    })

    let uuid4: string = "";
    if (check_call !== null) {

      check_call = await call_history.findOne({
        from: from_user_extantion,
        to: to_user_extantion,
        sipDomain: get_sip_domain_to,
        iscallEnded: 0,
        isinternal_call: 1
      }).sort({ createdAt: -1 })

      uuid4 = check_call.session_id

    } else {
      uuid4 = uuidv4();
    }



    //console.log("get_to_user_detail",get_to_user_detail)
    let get_sip_tokens: any = await user_tokens.find({
      uid: get_to_user_detail._id,
      osversion: 1,
    })
    //console.log("get_sip_tokens",get_sip_tokens)
    if (get_sip_tokens.length > 0) {
      let push_tokens_detail: any[] = [];

      await Promise.all(get_sip_tokens.map(async (item: any) => {
        push_tokens_detail.push(item.push_token.toString())
      }));
      let title: any = "incoming Call";
      let body: any = from_user_extantion == "" ? get_pin_from.toString() : from_user_extantion.toString();
      let token: any[] = push_tokens_detail

      let tmp_caller_nm: any = from_user_name == "" ? get_pin_from : from_user_name
      let caller_number: any = from_user_extantion == "" ? get_pin_from : from_user_extantion

      console.log("call_type", call_type,)
      let call_type_parse = 0
      if (call_type !== "" || call_type !== '') {
        call_type_parse = parseInt(call_type);
      }

      let defualt_img = ""
      let notification_data: any = {
        call_id: call_id.toString(),
        caller_number: caller_number.toString(),
        caller_name: tmp_caller_nm.toString(),
        call_type: call_type_parse.toString(),
        caller_image: from_user_image == "" ? defualt_img.toString() : from_user_image.toString()
      }
      console.log("notification_data", notification_data)
      console.log("token", token)
      let sendpush_response_android: any = await sendPushNotification(title, body, token, notification_data);
      console.log("sendpush_response_android", sendpush_response_android)
      if (sendpush_response_android.failureCount > 0) {
        isadroidfaild = 1
        androidErrorCount = sendpush_response_android.failureCount
      }
    }
    let get_sip_tokens_ios: any = await user_tokens.find({
      uid: get_to_user_detail._id,
      osversion: 2
    })
    //console.log("get_sip_tokens_ios",get_sip_tokens_ios)
    // if (get_sip_tokens_ios.length > 0) {
    //   let push_tokens_detail: any[] = [];

    //   await Promise.all(get_sip_tokens_ios.map(async (item: any) => {
    //     push_tokens_detail.push(item.apns_push_token.toString())
    //   }));
    //   let title: any = "incoming Call";
    //   let body: any = from_user_extantion == "" ? get_pin_from.toString() : from_user_extantion.toString();
    //   let token: any[] = push_tokens_detail

    //   let tmp_caller_nm: any = from_user_name == "" ? get_pin_from : from_user_name;
    //   let caller_number: any = from_user_extantion == "" ? parseInt(get_pin_from) : parseInt(from_user_extantion);
    //   let tmp_caller_extantion: any = 0
    //   let call_type_parse: any = 0
    //   console.log("call_type", call_type)
    //   if (call_type !== "" || call_type !== '') {
    //     call_type_parse = parseInt(call_type);
    //   }

    //   let defualt_img = ""
    //   let notification_data: any = {
    //     "caller_number": caller_number.toString(),
    //     "call-id": call_id.toString(),
    //     "session_id": uuid4.toString(),
    //     "call_type": call_type_parse,
    //     "caller_id": call_type_parse,
    //     "signal_type": "startCall",
    //     "caller_name": tmp_caller_nm.toString(),
    //     "call_opponents": caller_number.toString(),
    //     "user_info": caller_number.toString(),
    //     "caller_image": from_user_image == "" ? defualt_img.toString() : from_user_image.toString()
    //   }
    //   console.log("notification_data", notification_data)
    //   let sendpush_response_ios: any = await sendPushNotificationios(title, body, token, notification_data);
    //   //console.log("sendpush_response_ios",sendpush_response_ios.failed.length)
    //   if (sendpush_response_ios.failed.length > 0) {
    //     isiosfaild = 1
    //     iosErrorCount = sendpush_response_ios.failed.length
    //   }
    // }

    return res.status(200).send({
      success: 1,
      message: "Send Push Success",
      iosErrorCount: iosErrorCount,
      androidErrorCount: androidErrorCount
    });


  } catch (error) {
    console.log("error", error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
};
const UpdateCallStartime = async (req: Request, res: Response, next: NextFunction) => {
  try {
    let call_id: any = req.body.call_id;

    let localtime_date = moment().local().format('YYYY-MM-DDTHH:mm:ss.sssZ');

    let get_year: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("YYYY")
    let get_month: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("MM")
    let get_day: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("DD")
    let get_hour: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("HH")
    let get_minutes: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("mm")
    let get_seconds: any = moment(localtime_date, "YYYY-MM-DDTHH:mm:ss.sssZ").format("ss")

    let get_int_month: any = parseFloat(get_month) - 1


    let new_tmp_date: any = new Date();
    new_tmp_date.setUTCFullYear(get_year)
    new_tmp_date.setUTCMonth(get_int_month)
    new_tmp_date.setUTCDate(get_day)
    new_tmp_date.setUTCHours(get_hour)
    new_tmp_date.setUTCMinutes(get_minutes)
    new_tmp_date.setUTCSeconds(get_seconds)

    let get_call_detail: any = await call_history.findOne({
      call_id: call_id
    })

    if (get_call_detail == null) {
      res.status(400).send({
        success: 0,
        message: "Call Detail Not Found"
      });
    }

    let update_call_detail = await call_history.findOneAndUpdate({
      call_id: call_id,
      call_start_time: null
    }, {
      call_start_time: new_tmp_date
    }, {
      new: true
    })

    res.status(200).send({
      success: 1,
      message: "Call Detail Updated Successfully",
      update_call_detail
    });

  } catch (error) {
    console.log("error", error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
};
const removeUsercallLogApp = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let created_uid: any = new mongoose.Types.ObjectId(uid)
    let get_user_detail: any = await user.findOne({
      _id: uid,
      is_deleted:0
    })

    if (get_user_detail == null) {
      return res.status(404).send({
        success: 0,
        message: "User Not Found"
      });
    }

    let call_ids: any = req.body.call_ids

    if (call_ids.length == 0) {
      return res.status(404).send({
        success: 0,
        message: "Please Select Calls"
      });
    }

    await call_history.updateMany({
      _id: { $in: call_ids }
    }, {
      $push: { deleted_users: created_uid }
    })

    return res.status(200).send({
      success: 1,
      message: "Delete Call Log Successfully"
    });

  } catch (error) {
    console.log("error", error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
};
const getUserProfile = async (req:Request,res:Response,next:NextFunction)=>{
  try {
    let get_uid: any = req.body.uid
    if(get_uid == undefined){
      return res.status(403).send({
        success: 0,
        message: "User ID is Mandatory"
      });
    }
  
    if(!mongoose.Types.ObjectId.isValid(get_uid)){
      return res.status(403).send({
        success: 0,
        message: "User ID is Invalid"
      });
    }
      let get_users: any = await user.findOne({
        _id: get_uid,
        is_deleted:0
      }).select("first_name last_name emailAddress MobileNumber user_name user_image")
      if (get_users == null) {
       return res.status(404).send({
          success: 0,
          message: "User not Exists",
        });
      } 

      return res.status(200).send({
        success: 1,
        message: "User Detail.",
        UserDetail: get_users
      });
     
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const getUserDetailByUserName = async (req:Request,res:Response,next:NextFunction)=>{
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    let eid: any = user_detail?.eid
    let user_name: any = req.query.user_name
    let isFriend:any = false
    if(user_name == undefined){
      return res.status(403).send({
        success: 0,
        message: "User Name is Mandatory"
      });
    }
    user_name = user_name.toLowerCase();
      let get_users: any = await user.findOne({
        user_name: user_name,
        eid:eid,
        _id:{$ne:uid},
        is_deleted:0
      }).select("_id first_name last_name user_name user_image is_online eid")

      if (get_users == null) {
        return res.status(404).send({
          success: 0,
          message: "User not Exists",
        });
      } 

      if(get_users){
        let isFriendData:any= await user_fav_contact.findOne({
          uid:uid,
          user_id:get_users._id
        }) 
        if(isFriendData !== null){
          isFriend=true
        }
      }
      const userObject = get_users.toObject();
      userObject.isFriend = isFriend;
      return res.status(200).send({
        success: 1,
        message: "User Detail By User Name",
        UserDetail: userObject
      });
     
  } catch (error) {
    console.log(error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error"
    });
  }
}
const updatePassword = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid;
    let get_user_detail: any = await user.findOne({
      _id: uid,
      is_deleted:0
    });

    if (get_user_detail == null) {
      return res.status(404).send({
        success: 0,
        message: "User Not Found",
      });
    }
    let data: any = req.body;
    let oldPassword: any = data.old_password;
    let newPassword: any = data.new_password;

    if (!oldPassword) {
      return res.status(403).send({
        success: 0,
        message: "old password is mandatory",
      });
    }
    if (!newPassword) {
      return res.status(403).send({
        success: 0,
        message: "new password is mandatory",
      });
    }

    if (!REGEXP.USER.password.test(newPassword)) {
      return res.status(403).send({
        success: 0,
        message: "New password format is invalid",
      });
    }

    if (get_user_detail.password !== oldPassword) {
      return res.status(401).send({
        success: 0,
        message: "Old password is incorrect",
      });
    }

    await user.findByIdAndUpdate(uid, { password: newPassword });

    return res.status(200).send({
      success: 1,
      message: "Password updated successfully!",
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};
const updateProfie = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid;

    const { first_name, last_name, user_image } = req.body;
    let get_user_detail: any = await user.findOne({
      _id: uid,
      is_deleted:0
    });

    if (get_user_detail == null) {
      return res.status(404).send({
        success: 0,
        message: "User Not Found",
      });
    }

    if ((first_name)&&!REGEXP.USER.first_name.test(first_name)) {
      return res.status(403).send({
        success: 0,
        message: "first name is invalid",
      });
    }
    if ((last_name)&&!REGEXP.USER.last_name.test(last_name)) {
      return res.status(403).send({
        success: 0,
        message: "last name is invalid",
      });
    }

    let updateObj:any = {}
    if(first_name){
      updateObj.first_name = first_name
    }
    if(last_name){
      updateObj.last_name = last_name
    }
    console.log(user_image,"user_image")
    if(user_image!=undefined){
      updateObj.user_image = user_image
    }
    const update: any = await user.findByIdAndUpdate(
      uid,
      updateObj,
      {
        new: true,
        runValidators: true,
      }
    );

    await emitHandler("send_update_user", {
      uid: update._id,
      user_image: update.user_image,
      first_name: update.first_name,
      last_name: update.last_name,
      cid: update.eid,
    });

    return res.status(200).send({
      success: 1,
      message: "updated successfully!",
    });
  } catch (error) {
    res.status(500).send({
      success: 0,
      message: "Internal Server Error",
    });
  }
};

const updatedeliverystatus=async(
   req: Request,
  res: Response,
  next: NextFunction
)=>{
  try {
    const data = req.query
    const isGroup:any = req.query.isGroup
    console.log({
    isgroup: parseInt(isGroup),
    message_id: data.messageId,
    group_id: data.receiver_id,
    delivery_type:2,
    receiver_id: data.receiver_id,
    cid: data.cid
    },"objectdata")
    await emitHandler("send_delivery_status", {
    isgroup: parseInt(isGroup),
    message_id: data.messageId,
    group_id: data.receiver_id,
    delivery_type:2,
    receiver_id: data.receiver_id,
    cid: data.cid
    });
  } catch (error) {
    console.log(error,'API called update delivery status error')
  }
};
const updatedeliveryType=async(
   req: Request,
  res: Response,
  next: NextFunction
)=>{
  try {
        const token = await get_token(req);
    const user_detail = await User_token(token);
    let eid: any = user_detail?.eid;

    const bodyData = req.body?.data;
    if (!Array.isArray(bodyData) || bodyData.length === 0) {
      return res.status(400).json({ message: "Invalid request body" });
    }


    for (const item of bodyData) {
      const payload = {
        isgroup: parseInt(item.isgroup),
        message_id: item.message_id,
        group_id: item.receiver_id,
        delivery_type: 2,
        receiver_id: item.receiver_id,
        cid:eid,
      };

      console.log(payload, "objectData");

      await emitHandler("send_delivery_status", payload);
    }

    return res.status(200).json({ success: true, message: "Delivery status updated" });

  } catch (error) {
    console.log(error,'API called update delivery status error')
  }
};
const updateUserPassword = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const data = req.body;
    const uid = data.uid;
    const user_password = data.user_password;

    if(!mongoose.Types.ObjectId.isValid(uid)){
      return res.status(404).send({
        success: 0,
        message: "uid is Invalid",
      });
    }

    const userDetail: any = await user.findOne(
      {
        _id: uid,
        is_deleted: 0
      }
    );

    if (!userDetail == null || userDetail == undefined) {
      return res.status(404).send({
        success: 0,
        message: "User Not Found",
      });
    }

    await user.findByIdAndUpdate({
      _id: userDetail._id
    }, {
      password:user_password
    })

     await emitHandler("authentication_fail", {
       uid: uid,
       type: MESSAGE.AUTH_FAIL_TYPE.DELETEBYADMIN,
       device_id: null,
     });
   return res.status(200).send({
      success: 1,
      message: "User Password Updated successfully",
    });

  } catch (error) {
    console.log("error",error)
    res.status(500).send({
      success: 0,
      message: "Internal Server Error,",
    });
  }
};

const userLogoutWeb = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    const uid: any = user_detail?.uid;

    const id = req.body.id;

    console.log("userLogout web api called token", token);

    // Find the primary account for this uid
    const isValidUser = await user_tokens.findOne({
      uid: uid,
      is_primary: true,
    });

    if (!isValidUser) {
      return res.status(403).send({
        success: 0,
        message: "You are not authorized to log out.",
      });
    }
    const tokenData = await user_tokens.findOne({
      _id:id
    })
    // Remove the user token for this session
    const log = await user_tokens.findOneAndRemove({
      _id: id,
      uid: uid,
    });

    if (!log) {
      return res.status(404).send({
        success: 0,
        message: "Session not found or already logged out.",
      });
    }
    console.log(tokenData?.device_id,"auth fail emmit")
    await emitHandler("authentication_fail", {
      uid: uid,
      type: MESSAGE.AUTH_FAIL_TYPE.DELETE,
      device_id: tokenData?.device_id,
    });
    return res.send({
      success: 1,
      message: "Logout successfully.",
      logoutUser: log,
    });
  } catch (error) {
    console.log("error", error);
    return res.status(500).send({
      success: 0,
      message: "Internal server error",
    });
  }
};
const ContactList = async (req: Request, res: Response, next: NextFunction) => {
  console.log("favorite/contacts/list api called")
  try {
    const token = await get_token(req);
    const user_detail = await User_token(token);
    let uid: any = user_detail?.uid
    const eid: any = user_detail?.eid;

    let data = await user.find({ eid: eid }).select("MobileNumber first_name last_name user_image user_name")
    return res.status(200).send({
      success: 1,
      message: "Favorite Contact List",
      // ContactList: get_fav_contats
      ContactList: data
    });


  } catch (error) {
    //console.log("create fqdn error",error)
    return res.status(500).send({
      success: 0,
      message: "Internal Server Error,"
    });
  }
};

export default {
  userLogin,
  qrLogin,
  create,
  getallUsersbyEid,
  getUserDetailUid,
  editUserbyUid,
  deleteUserById,
  getUserConverationData,
  sendPushtoApp,
  getuserlist,
  getblockuserlist,
  userLogout,
  RemoveLoginSession,
  getDashboardDEtail,
  refreshaccesstoken,
  getContacts,
  addUpdateContacts,
  addcdrlog,
  Getcallhistory,
  GetCDRlogs,
  EnterpriseUserList,
  addFavContact,
  deteleFavContact,
  getFavContactList,
  updategroupmember_detail,
  Endcallcdrlog,
  addcdrlogNew,
  addCallInCdr,
  SendpushToAppNew,
  UpdateCallStartime,
  removeUsercallLogApp,
  getUserProfile,
  getUserDetailByUserName,
  updatePassword,
  updateProfie,
  updatedeliverystatus,
  updatedeliveryType,
  updateUserPassword,
  userLogoutWeb,
  ContactList
};
