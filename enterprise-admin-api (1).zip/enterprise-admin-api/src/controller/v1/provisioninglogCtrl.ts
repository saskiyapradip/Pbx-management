import { Request, Response } from "express";
import provisioninglog from "../../models/provisioninglog";

const getProvisioningLogsByUserId = async (req: Request, res: Response) => {
  try {
    let uid: any = req.body.uid;
    let page: number = req.body.page || 1;
    let size: number = req.body.size || 10; 


    let skip = (page - 1) * size;

    const logs = await provisioninglog.find({
      userId: uid,
    })
    .sort({ createdAt: -1 }) 
    .skip(skip)
    .limit(size);

    const totalRecords = await provisioninglog.countDocuments({
      userId: uid,
    });

    let total_page_count: any = Math.ceil(totalRecords / size);

    res.status(200).json({
      status: 1,
      data: logs,
      totalRecords: totalRecords,
      total_page_count:total_page_count,
      message: "Provision Log fetched successfully",
    });
  } catch (error) {
    //console.log("Error in get Provision Log: ", error);
    res.status(500).json({
      status: 0,
      message: "Internal Server Error",
    });
  }
};
export default {
  getProvisioningLogsByUserId
};
