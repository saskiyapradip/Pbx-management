import moment from "moment";
import user from "../../models/user";
import conversation from "../../models/conversation";
import group_conversation from "../../models/group_conversation";
import group from "../../models/group";
import mongoose from "mongoose";
const deleteOldMessage = async () => {
  try {
    const date180DaysAgo = moment().subtract(180, "days").toDate();

    await conversation.deleteMany({
      createdAt: { $lt: date180DaysAgo },
    })

    await group_conversation.deleteMany({
      createdAt: { $lt: date180DaysAgo }
    })
    // const date180DaysAgo = moment().subtract(180, "days").toDate();
    // const userList = await user.find({
    //   keep_message: true,
    // });
    // // for 1-to-1 conv
    // const userIds = userList.map((user) => user._id);
    // console.log(userIds, date180DaysAgo, "userIds");
    // // for group conv
    // const stringUserIds = userIds.map((id) => id.toString());
    // const allGroup = await group.aggregate([
    //   {
    //     $match: {
    //       group_users: { $in: stringUserIds },
    //       is_deleted: 0,
    //     },
    //   },
    //   {
    //     $group: {
    //       _id: null,
    //       ids: { $push: "$_id" }, 
    //     },
    //   },
    // ]);
    // const allGroupIds = allGroup[0].ids;

    // const allConversations = await conversation.aggregate([
    //   {
    //     $match: {
    //       createdAt: { $lt: date180DaysAgo },
    //       $or: [
    //         { receiver_id: { $in: userIds } },
    //         { sender_id: { $in: userIds } },
    //       ],
    //       is_deleted: 0,
    //     },
    //   },
    //   {
    //     $project: {
    //       sender_id: 1,
    //       receiver_id: 1,
    //       _id: 1,
    //     },
    //   },
    // ]);

    // const bulkOps:any[] = allConversations.map((message) => {
    //   const validUsers = userIds
    //     .filter(
    //       (uid) =>
    //         message.sender_id.equals(uid) || message.receiver_id.equals(uid)
    //     )
    //     .map((uid) => new mongoose.Types.ObjectId(uid));

    //   return {
    //     updateOne: {
    //       filter: { _id: message._id },
    //       update: {
    //         $addToSet: {
    //           delete_message_users: { $each: validUsers },
    //         },
    //         $set: { updatedAt: new Date() },
    //       },
    //     },
    //   };
    // });

    // if (bulkOps.length > 0) {
    //   await conversation.bulkWrite(bulkOps);
    // }
    // const allGroupConversation = await group_conversation.aggregate([
    //   {
    //     $match: {
    //       createdAt: { $lt: date180DaysAgo },
    //       group_id: { $in: allGroupIds },
    //       is_deleted: 0,
    //     },
    //   },
    //   {
    //     $lookup:{
    //       from:"groups",
    //       localField:"group_id",
    //       foreignField:"_id",
    //       as:"group_details"
    //     }
    //   },
    //   {
    //     $unwind:"$group_details"
    //   },
    //   {
    //     $project:{
    //       _id:1,
    //       group_id:1,
    //       group_users:"$group_details.group_users"
    //     }
    //   },
    // ]);
    //   const bulkOpsGroup:any[] = allGroupConversation.map((message) => {
    //   const validUsers = userIds
    //     .filter(
    //       (uid) =>
    //         message.group_users.includes(uid.toString())
    //     )
    //     .map((uid) => new mongoose.Types.ObjectId(uid));
    //   return {
    //     updateOne: {
    //       filter: { _id: message._id },
    //       update: {
    //         $addToSet: {
    //           delete_message_users: { $each: validUsers },
    //         },
    //         $set: { updatedAt: new Date() },
    //       },
    //     },
    //   };
    // });

    // if (bulkOps.length > 0) {
    //   await group_conversation.bulkWrite(bulkOpsGroup);
    // }
  } catch (error) {
    console.log(error);
  }
};

export { deleteOldMessage };
