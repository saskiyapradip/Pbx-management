import mongoose from "mongoose";
import user_tokens from "../models/user_tokens";
import user from "../models/user";
import { Request } from "express";

interface userData{
    uid:string;
    eid:String;
    device_id:any;
  }

const User_token = async (token:any)=>{
    const get_user_detail_token = await user_tokens.findOne({
        token:token
    })
    const get_user_detail = await user.findOne({
        _id:get_user_detail_token?.uid
    })
    if(get_user_detail){
        const user_data:userData={
            uid:get_user_detail?._id,
            eid:get_user_detail?.eid,
            device_id:get_user_detail_token?.device_id
        }
        return user_data
    }
} 

export default User_token;