import mongoose from "mongoose";
import user_tokens from "../models/user_tokens";
import user_admin from "../models/user_admin";
import { Request } from "express";

interface userDataAdmin{
    uid:string;
    eid:mongoose.Schema.Types.ObjectId;
  }

  const admin_token = async (token:any)=>{
    const get_admin_user_detail_token = await user_tokens.findOne({
        token:token
    })
    const get_user_detail = await user_admin.findOne({
        _id:get_admin_user_detail_token?.uid
    })
    if(get_user_detail){
        const user_data:userDataAdmin={
            uid:get_user_detail?._id,
            eid:get_user_detail?.eid
        }
        return user_data
    }
}  

export default admin_token;