const EmailValidation = async (email: any) => {
    const email_tmp = email;
    let reg_ex = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if (reg_ex.test(email_tmp)) {
        return true
    } else {
        return false
    }
}
export default EmailValidation;