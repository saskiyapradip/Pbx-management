// utils/permission.ts
import { Request, Response, NextFunction } from "express";
import user_admin from "../models/user_admin";
import accessgroup from "../models/accessgroup";
import get_token from "./userHeader";
import User_token_admin from "./helper_admin"



export const checkPermission = (permission: string) => {
    return async (req: Request, res: Response, next: NextFunction) => {
      try {
        console.log("checkPermission callled")
        const token = await get_token(req);
        const user_detail = await User_token_admin(token);

        const userId = user_detail?.uid; 
        const user = await user_admin.findById(userId);
        if (!user) {
          return res.status(404).json({ success: 0, message: "User not found" });
        }
  
        // Super Admin → always allowed
        if (user.user_type === 1) {
          return next();
        }
  
        // Enterprise Admin → always allowed
        if (user.user_type === 3) {
          const get_access_group = {
            dashboard_view: 1,
            enterprise_create: 0,
            enterprise_update: 0,
            enterprise_delete: 0,
            enterprise_view: 0,
            subscriber_create: 1,
            subscriber_update: 1,
            subscriber_delete: 1,
            subscriber_view: 1,
            add_admin_create: 0,
            add_admin_update: 0,
            add_admin_delete: 0,
            add_admin_view: 0,
            add_role_create: 0,
            add_role_update: 0,
            add_role_delete: 0,
            add_role_view: 0,
            cdr_view: 1,
            cdr_download: 1,
          };
          if ((get_access_group as any)[permission] === 1) {
            return next();
          } else {
            return res
              .status(403)
              .json({ success: 0, message: "Permission denied" });
          }
        }
  
        // Enterprise Sub Admin → check permissions
        if (user.user_type === 2) {
          const get_access_group = await accessgroup.findById(user.accessgroup);
          if (!get_access_group) {
            return res
              .status(404)
              .json({ success: 0, message: "Access Group not found" });
          }
  
          // Check if sub admin has the required permission
          if ((get_access_group as any)[permission] === 1) {
            return next();
          } else {
            return res
              .status(403)
              .json({ success: 0, message: "Permission denied" });
          }
        }
  
        return res.status(403).json({ success: 0, message: "Access denied" });
      } catch (error:any) {
        return res.status(500).json({
            success: 0,
            message: "Internal Server Error",
            error: (error as Error).message, // only message
          });
      }
    };
  };
  
