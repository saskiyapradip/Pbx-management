import apn from "apn";
import fs from "fs";
const key_file = process.env.APN_AUTH_KEY ? Buffer.from(process.env.APN_AUTH_KEY.replace(/\\n/g, "\n")) : fs.readFileSync(__dirname + "/AuthKey.p8");
const appprovider: any = new apn.Provider({
	token:{
		keyId: process.env.APN_KEY_ID || "",
		teamId: process.env.APN_TEAM_ID || "",
		key:key_file
	},
	production:true
});
const debugappprovider: any = new apn.Provider({
        token:{
                keyId: process.env.APN_KEY_ID || "",
                teamId: process.env.APN_TEAM_ID || "",
                key:key_file
        },
        production:false
});
const sendPushNotificationios = async (title: any, body: any, myTokens: any, mydata: any) => {
	try {
	console.log("send notification function called ios")
	let registrationTokens = [...new Set(myTokens)];

	let notification = new apn.Notification();
    notification.topic = "com.example.app.voip";   // Make sure to append .voip here!
	notification.expiry = 10;
	notification.badge = 0;
	notification.sound = "default";
	notification.alert = "Incoming Call";
	notification.priority = 10;
	notification.payload = mydata;
	if(mydata.caller_number == "3001" || mydata.caller_number == "7007" || mydata.caller_number == "7474") {
		console.log("send DEBUG notification ios debugg",mydata)
	let apiresponse:any = await debugappprovider.send(notification,registrationTokens)
        .then((response:any) => {
                console.log("push response ios debuug",JSON.stringify(response))
                        return response;
        });
	return apiresponse;
	} else {
		console.log("send PRODUCTION notification",mydata)
	let apiresponse:any = await appprovider.send(notification,registrationTokens)
	.then((response:any) => {
		console.log("push response ios",JSON.stringify(response))
			return response;
	});
	return apiresponse;
	}
} catch (error:any) {
	console.log("error",error)
}
}

export default sendPushNotificationios;






