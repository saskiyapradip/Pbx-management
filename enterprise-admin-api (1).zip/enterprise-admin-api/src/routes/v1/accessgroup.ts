import { Router } from "express";
import accessgroupCtrl from "../../controller/v1/accessgroupCtrl";
import authUser from "../../middleware/authUser";
import authAdmin from "../../middleware/authAdmin";
import { checkPermission } from "../../helper/adminPermission";

export const accessgroupRoute = Router();


accessgroupRoute.get("/list",authAdmin,checkPermission("add_role_view"),accessgroupCtrl.AccessGroupList)
accessgroupRoute.get("/:group_id",authAdmin,checkPermission("add_role_view"),accessgroupCtrl.getGroupDetailByID)
accessgroupRoute.get("/",authAdmin,checkPermission("add_role_view"),accessgroupCtrl.AllAccessGroupList)
accessgroupRoute.post("/create" ,authAdmin,checkPermission("add_role_create"),accessgroupCtrl.createAccessGroup)
accessgroupRoute.put("/edit/:group_id" ,authAdmin,checkPermission("add_role_update"),accessgroupCtrl.EditGroupDetailByID)
accessgroupRoute.delete("/delete/:group_id",authAdmin,checkPermission("add_role_delete"),accessgroupCtrl.removeGroupById)



