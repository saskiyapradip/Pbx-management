import { Router } from "express";
import authUser from "../../middleware/authUser";
import uploadCtrl from "../../controller/v1//uploadCtrl";
import newuploadCtrl from "../../controller/v1//newUploadCtrl";
export const uploadRoute = Router();

uploadRoute.post("/",authUser,uploadCtrl.uploadFile)
uploadRoute.post("/files",authUser,newuploadCtrl.NewuploadFile)
uploadRoute.get("/getmedia",newuploadCtrl.getBlobFile)
