import { Router } from "express";
import groupCtrl from "../../controller/v1/groupCtrl";
import authUser from "../../middleware/authUser";

export const groupRoute = Router();

groupRoute.get("/message/info/:message_id",authUser,groupCtrl.getMessageDetail)
groupRoute.get("/info/:group_id",authUser,groupCtrl.getGroupDetail)


