import { Router } from "express";
import subAdminCtrl from "../../controller/v1/subAdminCtrl";
import authUser from "../../middleware/authUser";
import authAdmin from "../../middleware/authAdmin";
import { checkPermission } from "../../helper/adminPermission";
export const subAdminRoute = Router();


subAdminRoute.get("/:subAdmin_id",authAdmin,checkPermission("add_admin_view"),subAdminCtrl.getSubAdminDetailByID)
subAdminRoute.get("/",authAdmin,checkPermission("add_admin_view"),subAdminCtrl.AllSubAdminList)
subAdminRoute.post("/create" ,authAdmin,checkPermission("enterprise_create"),subAdminCtrl.createSubAdmin)
subAdminRoute.put("/edit/:subAdmin_id" ,checkPermission("add_admin_update"),authAdmin,subAdminCtrl.EditAdminDetailByID)
subAdminRoute.delete("/delete/:subAdmin_id",authAdmin,checkPermission("add_admin_delete"),subAdminCtrl.removeSubAdminById)
subAdminRoute.put("/update/password",authAdmin,checkPermission("add_admin_update"),subAdminCtrl.updatePassword)




