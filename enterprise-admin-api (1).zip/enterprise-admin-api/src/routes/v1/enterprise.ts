import { Router } from "express";
import authUser from "../../middleware/authUser";
import enterpriseCtrl from "../../controller/v1/enterpriseCtrl";
import authAdmin from "../../middleware/authAdmin";
import { checkPermission } from "../../helper/adminPermission";

export const enterpriseRoute = Router();

enterpriseRoute.get("/pakage/list", authUser, enterpriseCtrl.EnterpriseList);
enterpriseRoute.get("/list", authAdmin,checkPermission("cdr_view"),enterpriseCtrl.EnterpriseListdropdown);
enterpriseRoute.post("/cdr/list/download", authUser, enterpriseCtrl.GetCDRlogsDownload);
enterpriseRoute.post("/dashboard", authUser, enterpriseCtrl.getDashboardDEtail);
enterpriseRoute.post("/dashboard/ent", authUser, enterpriseCtrl.getDashboardDEtailEnterprise);
enterpriseRoute.post("/create", authAdmin,checkPermission("enterprise_create"),enterpriseCtrl.addNewRecord);
enterpriseRoute.post("/login", enterpriseCtrl.Enterpriselogin);
enterpriseRoute.post("/detail",authAdmin,checkPermission("enterprise_view"), enterpriseCtrl.GetRecordByID);
enterpriseRoute.post("/",authAdmin,checkPermission("enterprise_view"),enterpriseCtrl.GetAllRecord);
enterpriseRoute.put("/admin/password/update", authAdmin, enterpriseCtrl.updateAdminPassword);
enterpriseRoute.put("/edit",authAdmin,checkPermission("enterprise_update"), enterpriseCtrl.editRecord);
enterpriseRoute.put("/delete", authAdmin,checkPermission("enterprise_delete"),enterpriseCtrl.removeRecord);
enterpriseRoute.get("/info", authUser, enterpriseCtrl.EnterpriseInfo);
enterpriseRoute.post("/resetPassowrd", enterpriseCtrl.ResetPassword);
enterpriseRoute.post("/confirmResetPassword", enterpriseCtrl.ConfirmResetPassword);
enterpriseRoute.put("/password/update", authAdmin,checkPermission("enterprise_update"),enterpriseCtrl.updatePassword);






