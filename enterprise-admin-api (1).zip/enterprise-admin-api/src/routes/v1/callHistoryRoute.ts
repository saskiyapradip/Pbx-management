import { Router } from "express";
import callHistoryCtrl from "../../controller/v1/callHistoryCtrl";
import authUser from "../../middleware/authUser";
import authAdmin from "../../middleware/authAdmin";
import { checkPermission } from "../../helper/adminPermission";

export const callHistoryRoute = Router();


callHistoryRoute.post("/",authUser,callHistoryCtrl.getCallHistory)
callHistoryRoute.post("/list",authAdmin,checkPermission("cdr_view"),callHistoryCtrl.getCallHistoryAll)
callHistoryRoute.post("/call/reject",authUser,callHistoryCtrl.callRejectByUser)