import { Router } from "express";
import { UserRoute } from "././v1/user";
import { enterpriseRoute } from "./v1/enterprise";
import { uploadRoute } from "./v1/upload";
import {accessgroupRoute}  from "./v1/accessgroup"
import { subAdminRoute } from "./v1/subadmin";
import {groupRoute} from "./v1/group"
import { callHistoryRoute } from "./v1/callHistoryRoute";

export const Route = Router();

Route.use("/v1/user", UserRoute);
Route.use("/v1/company", enterpriseRoute);
Route.use("/v1/upload", uploadRoute);
Route.use("upload", (req, res) => {
  res.status(404).json({ error: 'Route not found' });});
Route.use("/v1/accessgroup", accessgroupRoute);
Route.use("/v1/subadmin", subAdminRoute);
Route.use("/v1/group", groupRoute);
Route.use("/v1/callhistory", callHistoryRoute)


Route.use((req, res, next) => {
    const error = new Error("Routes not found")
    return res.status(404).json({
        success: 0, 
        message: error.message 
    })
})




