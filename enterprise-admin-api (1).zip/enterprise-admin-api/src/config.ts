import dotenv from "dotenv";
dotenv.config();

const MONGOURI = process.env.MONGOURI || "";
const MONGO_DB_NAME = process.env.MONGO_DB_NAME || "";
const PORT = process.env.PORT
const SECRET_KEY = process.env.JWT_SECRATE_KEY || "";
const ENVIRONMENT = process.env.ENVIRONMENT || "";
const TOKEN_EXPIRE = process.env.TOKEN_EXPIRE
const DEFAULT_DOMAIN = process.env.DEFAULT_DOMAIN
const USERNAME = process.env.USERNAME
const PASSWORD = process.env.PASSWORD
const SOCKET_URL = process.env.SOCKET_URL || "";
const SOCKET_TOKEN = process.env.SOCKET_TOKEN || "";
const LOGIN_MAX_ATTEMPTS = process.env.LOGIN_MAX_ATTEMPTS || 5;
const BLOCK_TIME = process.env.LOGIN_MAX_ATTEMPTS_BLOCK_TIME || 60000;
const TIME_FRAME = process.env.LOGIN_TIME_FRAME || 60000
export const config = {
    mongo: {
        uri: MONGOURI
    },
    server: {
        port: PORT
    },
    db: {
        dbname: MONGO_DB_NAME
    },
    key: {
        secret_key: SECRET_KEY
    },
    enviroment: {
        enviroment_type: ENVIRONMENT
    },
    service: {
    type: "service_account",
    project_id: process.env.FIREBASE_PROJECT_ID || "",
    private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID || "",
    private_key: (process.env.FIREBASE_PRIVATE_KEY || "").replace(/\\n/g, "\n"),
    client_email: process.env.FIREBASE_CLIENT_EMAIL || "",
    client_id: process.env.FIREBASE_CLIENT_ID || "",
    auth_uri: "https://accounts.google.com/o/oauth2/auth",
    token_uri: "https://oauth2.googleapis.com/token",
    auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
    client_x509_cert_url: process.env.FIREBASE_CLIENT_CERT_URL || "",
    universe_domain: "googleapis.com"
  },
    token: {
        token_expire: TOKEN_EXPIRE
    },
    app_configs: {
        DEFAULT_DOMAIN: DEFAULT_DOMAIN,
        USERNAME: USERNAME,
        PASSWORD: PASSWORD,
    },
    SOCKET:{
        URL:SOCKET_URL,
        TOKEN:SOCKET_TOKEN,
    },
    LOGIN_ATTEMPT:{
       BLOCK_TIME:BLOCK_TIME,
       LOGIN_MAX_ATTEMPTS:LOGIN_MAX_ATTEMPTS,
       TIME_FRAME:TIME_FRAME
    }
}