import express, { Express } from "express";
import mongoose, { mongo } from "mongoose";
import https from "http";
import cors from "cors";
import { config } from "./src/config";
import { Route } from "./src/routes";
import fs from "fs";
import helmet from "helmet";
import  middleware from "./src/middleware/headerRemove";
import bodyParser from "body-parser";
import cron from 'node-cron';
import swaggerUi from 'swagger-ui-express';
import { swaggerSpec } from "./src/utils/swagger";
import { deleteOldMessage } from "./src/controller/v1/cronCtrl";
import { basicAuthMiddleware } from "./src/middleware/basicAuthMiddleware";

const app = express();  
app.use(helmet());
app.use(helmet.contentSecurityPolicy({
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
    }
}));
app.use(helmet.frameguard({ action: 'deny' }));
app.use(helmet.hidePoweredBy());
  

const server = https.createServer(app)
app.use(bodyParser.json({ limit: '100mb'}))
app.use(bodyParser.urlencoded({ limit: '100mb', extended: true,parameterLimit:500000}))
app.use(cors());
/** Error Hanldling  **/
app.use('/v1/api-docs',basicAuthMiddleware, swaggerUi.serve, swaggerUi.setup(swaggerSpec));
app.use("/", middleware,Route)

mongoose.connect(config.mongo.uri, {
    dbName: config.db.dbname,
    serverSelectionTimeoutMS:5000
}).then(() => console.log("mongo db conneccted")).catch((error) => console.log("db not connected", error))
   

cron.schedule("*/1 * * * *", () => {
    if (config.enviroment.enviroment_type === "production") {
      console.log("cron called")
      // deleteOldMessage();
      //SendEmailAndSmsToUsers();
    }
  });

  // mongoose.syncIndexes();

server.listen(config.server.port, function () {
    console.log("server running on", config.server.port)
})




